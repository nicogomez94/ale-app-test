import React, { useState, useMemo } from 'react';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { getTheme } from './theme';
import { Layout } from './components/Layout';
import { LoginPage } from './pages/LoginPage';
import { Dashboard } from './pages/DashboardPage';
import { PolicyForm } from './pages/PolicyForm';
import { ReferralPage } from './pages/ReferralPage';
import { PaymentPage } from './pages/PaymentPage';
import { CalendarPage } from './pages/CalendarPage';
import { ClientsPage } from './pages/ClientsPage';
import { CommissionsPage } from './pages/CommissionsPage';
import { ProfilePage } from './pages/ProfilePage';
import { CompaniesPage } from './pages/CompaniesPage';
import { InsuranceCompaniesPage } from './pages/InsuranceCompaniesPage';
import { BillingPage } from './pages/BillingPage';
import { LifeAndRetirementPage } from './pages/LifeAndRetirementPage';
import { QuotesPage } from './pages/QuotesPage';
import { ClaimsPage } from './pages/ClaimsPage';
import { PublicQuotePage } from './pages/PublicQuotePage';
import { SuggestionsPage } from './pages/SuggestionsPage';
import { ChatLauncherPage, ScriptsLibraryPage } from './pages/ToolsPage';
import { QuickNotesPage } from './pages/QuickNotesPage';
import { format, addMonths, parseISO, addDays, differenceInMonths, differenceInYears, addYears } from 'date-fns';

import { MOCK_POLICIES, MOCK_INSURERS } from './data/mockData';
import { InsuranceCompany } from './types';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [policies, setPolicies] = useState<any[]>(MOCK_POLICIES);
  const [insurers, setInsurers] = useState<InsuranceCompany[]>(MOCK_INSURERS);
  const [clients, setClients] = useState<any[]>([
    { id: '1', nombre: 'Juan Pérez', dni: '30123456', telefono: '1122334455', email: 'juan@example.com', direccion: 'Av. Corrientes 1234', cp: '1000', provincia: 'Buenos Aires', localidad: 'CABA' },
    { id: '2', nombre: 'María García', dni: '25987654', telefono: '1199887766', email: 'maria@example.com', direccion: 'Calle Falsa 123', cp: '2000', provincia: 'Santa Fe', localidad: 'Rosario' },
    { id: '3', nombre: 'Carlos López', dni: '35112233', telefono: '1155443322', email: 'carlos@example.com', direccion: 'Rivadavia 500', cp: '3000', provincia: 'Córdoba', localidad: 'Córdoba' },
  ]);
  const [notes, setNotes] = useState<any[]>(() => {
    const saved = localStorage.getItem('pas_alert_notes');
    return saved ? JSON.parse(saved) : [];
  });
  const [user, setUser] = useState<any>({
    nombre: 'Alejandro Díaz',
    email: 'alejandro.rh.diaz@gmail.com',
    plan: 'gratis',
    avatar: '',
    matricula: '12345',
    nombreComercial: 'PAS ALERT'
  });

  const theme = useMemo(() => createTheme(getTheme(isDarkMode ? 'dark' : 'light')), [isDarkMode]);

  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
  };

  const handleToggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };

  const handleUpdateProfile = (data: any) => {
    setUser({ ...user, ...data });
  };

  const handleTogglePaid = (policyId: string) => {
    setPolicies(prev => {
      const policy = prev.find(p => p.id === policyId);
      if (!policy) return prev;

      const isMarkingAsPaid = !policy.pagada;
      const updatedPolicies = prev.map(p => {
        if (p.id === policyId) {
          const updatedP = { 
            ...p, 
            pagada: isMarkingAsPaid,
            fechaPago: isMarkingAsPaid ? format(new Date(), 'yyyy-MM-dd') : undefined
          };
          if (p.tipo === 'Retiro') {
            const aporte = p.aporteMensual || 0;
            updatedP.fondoAcumulado = isMarkingAsPaid 
              ? (p.fondoAcumulado || 0) + aporte 
              : (p.fondoAcumulado || 0) - aporte;
          }
          return updatedP;
        }
        return p;
      });

      const gId = policy.groupId || policy.id;
      const cuotaStr = policy.cuota || '1/1';
      const currentCuotaParts = cuotaStr.split('/');
      const currentCuotaNum = parseInt(currentCuotaParts[0]);
      const totalCuotasNum = parseInt(currentCuotaParts[1] || '1');
      const nextCuotaNum = currentCuotaNum + 1;
      
      // If it's a monthly policy (vigencia === 'Mensual'), we increment both numbers
      const isMonthlyRecurring = policy.vigencia === 'Mensual';
      const nextTotalCuotas = isMonthlyRecurring ? nextCuotaNum : totalCuotasNum;

      if (isMarkingAsPaid && (nextCuotaNum <= totalCuotasNum || isMonthlyRecurring)) {
        const nextCuotaExists = prev.some(p => p.groupId === gId && p.cuota?.startsWith(`${nextCuotaNum}/`));

        if (!nextCuotaExists) {
          const nextId = Math.random().toString(36).substr(2, 9);
          const nextStartDate = policy.vencimiento;
          const nextEndDate = calculateNextEndDate(nextStartDate);
          
          const nextPolicy = {
            ...policy,
            id: nextId,
            groupId: gId,
            pagada: false,
            fechaInicio: nextStartDate,
            vencimiento: nextEndDate,
            cuota: `${nextCuotaNum}/${nextTotalCuotas}`,
            poliza: policy.poliza || '',
            // For Retiro, the next policy starts with the current fund + current contribution
            fondoAcumulado: policy.tipo === 'Retiro' ? (policy.fondoAcumulado || 0) + (policy.aporteMensual || 0) : policy.fondoAcumulado
          };
          
          if (!policy.groupId) {
            return updatedPolicies.map(p => p.id === policyId ? { ...p, groupId: gId } : p).concat(nextPolicy);
          }
          
          return updatedPolicies.concat(nextPolicy);
        }
        return updatedPolicies;
      } else if (!isMarkingAsPaid) {
        // If unmarking as paid, remove the next quota if it's not paid
        const finalPolicies = updatedPolicies.filter(p => {
          const isNextCuota = p.groupId === gId && p.cuota?.startsWith(`${nextCuotaNum}/`);
          return !(isNextCuota && !p.pagada);
        });

        return finalPolicies;
      }

      return updatedPolicies;
    });
  };

  const handleUpdatePaymentDate = (policyId: string, date: string) => {
    setPolicies(prev => prev.map(p => p.id === policyId ? { ...p, fechaPago: date } : p));
  };

  const handleUpdateNotes = (newNotes: any[]) => {
    setNotes(newNotes);
    localStorage.setItem('pas_alert_notes', JSON.stringify(newNotes));
  };

  const calculateNextEndDate = (startDate: string) => {
    const nStart = parseISO(startDate);
    // Default to 30 days as requested
    return format(addDays(nStart, 30), 'yyyy-MM-dd');
  };

  const handleUpdatePolicy = (updatedPolicy: any) => {
    setPolicies(prev => {
      const oldPolicy = prev.find(p => p.id === updatedPolicy.id);
      if (!oldPolicy) return prev;

      let newPolicies = prev.map(p => p.id === updatedPolicy.id ? updatedPolicy : p);
      
      // If vencimiento changed, cascade updates to subsequent policies in the group
      if (updatedPolicy.vencimiento !== oldPolicy.vencimiento) {
        const gId = updatedPolicy.groupId || updatedPolicy.id;
        const currentCuotaNum = parseInt(updatedPolicy.cuota?.split('/')[0] || '1');
        
        // Get all policies in the group and sort them by cuota number
        const groupPolicies = [...newPolicies]
          .filter(p => p.groupId === gId)
          .sort((a, b) => {
            const aNum = parseInt(a.cuota?.split('/')[0] || '0');
            const bNum = parseInt(b.cuota?.split('/')[0] || '0');
            return aNum - bNum;
          });

        let lastVencimiento = updatedPolicy.vencimiento;

        groupPolicies.forEach(p => {
          const pCuotaNum = parseInt(p.cuota?.split('/')[0] || '0');
          if (pCuotaNum > currentCuotaNum) {
            const pIndex = newPolicies.findIndex(np => np.id === p.id);
            if (pIndex !== -1) {
              const targetP = newPolicies[pIndex];
              
              const newStart = lastVencimiento;
              // For subsequent policies, we go back to the 30-day default
              const newEnd = calculateNextEndDate(newStart);
              
              newPolicies[pIndex] = {
                ...targetP,
                fechaInicio: newStart,
                vencimiento: newEnd
              };
              lastVencimiento = newEnd;
            }
          }
        });
      }
      return newPolicies;
    });
  };

  const handleDeletePolicy = (policyId: string) => {
    if (window.confirm('¿Estás seguro de que deseas eliminar esta póliza?')) {
      setPolicies(prev => prev.filter(p => p.id !== policyId));
    }
  };

  if (!isAuthenticated) {
    return (
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <LoginPage onLogin={handleLogin} />
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <Routes>
          {/* Public Routes */}
          <Route path="/cotizar/:userId/:type" element={<PublicQuotePage />} />
          
          {/* Protected Routes */}
          <Route path="*" element={
            <Layout 
              user={user} 
              onLogout={handleLogout} 
              isDarkMode={isDarkMode} 
              onToggleDarkMode={handleToggleDarkMode}
              policies={policies}
              notes={notes}
            >
              <Routes>
                <Route path="/" element={<Dashboard user={user} policies={policies} onTogglePaid={handleTogglePaid} onUpdatePaymentDate={handleUpdatePaymentDate} onDeletePolicy={handleDeletePolicy} onUpdatePolicy={handleUpdatePolicy} clients={clients} setClients={setClients} />} />
                <Route path="/clientes" element={<ClientsPage clients={clients} setClients={setClients} policies={policies} onTogglePaid={handleTogglePaid} onDeletePolicy={handleDeletePolicy} onUpdatePolicy={handleUpdatePolicy} user={user} />} />
                <Route path="/empresas" element={<CompaniesPage policies={policies} onTogglePaid={handleTogglePaid} onDeletePolicy={handleDeletePolicy} onUpdatePolicy={handleUpdatePolicy} user={user} />} />
                <Route path="/cotizaciones" element={<QuotesPage />} />
                <Route path="/siniestros" element={<ClaimsPage policies={policies} clients={clients} />} />
                <Route path="/aseguradoras" element={<InsuranceCompaniesPage insurers={insurers} setInsurers={setInsurers} />} />
                <Route path="/facturacion" element={<BillingPage insurers={insurers} setInsurers={setInsurers} />} />
                <Route path="/vida-retiro" element={<LifeAndRetirementPage policies={policies} setPolicies={setPolicies} clients={clients} setClients={setClients} onTogglePaid={handleTogglePaid} onUpdatePaymentDate={handleUpdatePaymentDate} onUpdatePolicy={handleUpdatePolicy} />} />
                <Route path="/polizas" element={<PolicyForm policies={policies} setPolicies={setPolicies} clients={clients} setClients={setClients} />} />
                <Route path="/comisiones" element={<CommissionsPage insurers={insurers} />} />
                <Route path="/referidos" element={<ReferralPage />} />
                <Route path="/pagos" element={<PaymentPage />} />
                <Route path="/herramientas/calendario" element={<CalendarPage notes={notes} setNotes={handleUpdateNotes} />} />
                <Route path="/herramientas/notas" element={<QuickNotesPage notes={notes} setNotes={handleUpdateNotes} />} />
                <Route path="/herramientas/lanzador" element={<ChatLauncherPage user={user} />} />
                <Route path="/sugerencias" element={<SuggestionsPage />} />
                <Route path="/perfil" element={<ProfilePage user={user} onUpdate={handleUpdateProfile} />} />
                <Route path="*" element={<Navigate to="/" />} />
              </Routes>
            </Layout>
          } />
        </Routes>
      </Router>
    </ThemeProvider>
  );
}
