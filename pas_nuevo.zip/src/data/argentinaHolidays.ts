export interface Holiday {
  date: string;
  name: string;
  type: 'fijo' | 'trasladable' | 'puente';
}

// Algoritmo de Gauss para calcular la Pascua
const getEaster = (year: number): Date => {
  const a = year % 19;
  const b = Math.floor(year / 100);
  const c = year % 100;
  const d = Math.floor(b / 4);
  const e = b % 4;
  const f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4);
  const k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31);
  const day = ((h + l - 7 * m + 114) % 31) + 1;
  return new Date(year, month - 1, day);
};

const formatDate = (date: Date): string => {
  const d = date.getDate().toString().padStart(2, '0');
  const m = (date.getMonth() + 1).toString().padStart(2, '0');
  const y = date.getFullYear();
  return `${y}-${m}-${d}`;
};

const getMovableDate = (year: number, month: number, day: number): Date => {
  const date = new Date(year, month - 1, day);
  const dayOfWeek = date.getDay(); // 0: Dom, 1: Lun, 2: Mar, 3: Mié, 4: Jue, 5: Vie, 6: Sáb

  if (dayOfWeek === 2 || dayOfWeek === 3) {
    // Martes o Miércoles -> Lunes anterior
    const diff = dayOfWeek === 2 ? 1 : 2;
    return new Date(year, month - 1, day - diff);
  } else if (dayOfWeek === 4 || dayOfWeek === 5) {
    // Jueves o Viernes -> Lunes siguiente
    const diff = dayOfWeek === 4 ? 4 : 3;
    return new Date(year, month - 1, day + diff);
  }
  return date;
};

export const getArgentinaHolidays = (year: number): Holiday[] => {
  const holidays: Holiday[] = [
    { date: `${year}-01-01`, name: 'Año Nuevo', type: 'fijo' },
    { date: `${year}-03-24`, name: 'Día Nacional de la Memoria por la Verdad y la Justicia', type: 'fijo' },
    { date: `${year}-04-02`, name: 'Día del Veterano y de los Caídos en la Guerra de Malvinas', type: 'fijo' },
    { date: `${year}-05-01`, name: 'Día del Trabajador', type: 'fijo' },
    { date: `${year}-05-25`, name: 'Día de la Revolución de Mayo', type: 'fijo' },
    { date: `${year}-06-20`, name: 'Paso a la Inmortalidad del Gral. Manuel Belgrano', type: 'fijo' },
    { date: `${year}-07-09`, name: 'Día de la Independencia', type: 'fijo' },
    { date: `${year}-12-08`, name: 'Inmaculada Concepción de María', type: 'fijo' },
    { date: `${year}-12-25`, name: 'Navidad', type: 'fijo' },
  ];

  // Pascua y relacionados
  const easter = getEaster(year);
  const goodFriday = new Date(easter);
  goodFriday.setDate(easter.getDate() - 2);
  const carnivalMonday = new Date(easter);
  carnivalMonday.setDate(easter.getDate() - 48);
  const carnivalTuesday = new Date(easter);
  carnivalTuesday.setDate(easter.getDate() - 47);

  holidays.push({ date: formatDate(goodFriday), name: 'Viernes Santo', type: 'fijo' });
  holidays.push({ date: formatDate(carnivalMonday), name: 'Carnaval', type: 'fijo' });
  holidays.push({ date: formatDate(carnivalTuesday), name: 'Carnaval', type: 'fijo' });

  // Trasladables
  holidays.push({ date: formatDate(getMovableDate(year, 6, 17)), name: 'Paso a la Inmortalidad del Gral. Güemes', type: 'trasladable' });
  holidays.push({ date: formatDate(getMovableDate(year, 8, 17)), name: 'Paso a la Inmortalidad del Gral. San Martín', type: 'trasladable' });
  holidays.push({ date: formatDate(getMovableDate(year, 10, 12)), name: 'Día del Respeto a la Diversidad Cultural', type: 'trasladable' });
  holidays.push({ date: formatDate(getMovableDate(year, 11, 20)), name: 'Día de la Soberanía Nacional', type: 'trasladable' });

  return holidays;
};
