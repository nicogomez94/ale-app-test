import { differenceInDays, parseISO } from 'date-fns';
import { InsuranceCompany, CommissionInvoice } from '../types';

export interface Policy {
  id: string;
  cliente: string;
  aseguradora: string;
  vencimiento: string;
  poliza: string;
  estado: string;
  tipo: 'Individual' | 'Empresa' | 'Vida' | 'Retiro';
  rubro?: string;
  medioPago?: 'Cupon' | 'Tarjeta de credito' | 'Debito por CBU';
  pagada?: boolean;
  fechaPago?: string;
  cuit?: string;
  subtipo?: string;
  sumaAsegurada?: number;
  prima?: number;
  moneda?: string;
  comisionPorcentaje?: number;
  email?: string;
  telefono?: string;
  cp?: string;
  edad?: number;
  fechaInicio?: string;
  beneficiarios?: boolean;
  cuota?: string;
  groupId?: string;
  prioridad?: string;
  aporteMensual?: number;
  fondoAcumulado?: number;
  edadRetiro?: number;
  ultimoAporte?: string;
  ultimaGestion?: {
    tipo: 'Whatsapp' | 'Mail';
    fecha: string;
    whatsappCount: number;
    mailCount: number;
  };
}

export const MOCK_POLICIES: Policy[] = [
  { id: '1', cliente: 'Juan Pérez', aseguradora: 'Sancor Seguros', vencimiento: '2026-03-01', poliza: '4452', estado: 'Vencida', tipo: 'Individual', medioPago: 'Cupon', pagada: true, ultimaGestion: { tipo: 'Whatsapp', fecha: '2026-04-03', whatsappCount: 2, mailCount: 0 } },
  { id: '2', cliente: 'María García', aseguradora: 'Federación Patronal', vencimiento: '2026-03-05', poliza: '9921', estado: 'Vence pronto', tipo: 'Individual', medioPago: 'Tarjeta de credito', pagada: false, ultimaGestion: { tipo: 'Mail', fecha: '2026-04-03', whatsappCount: 0, mailCount: 1 } },
  { id: '3', cliente: 'Carlos López', aseguradora: 'La Segunda', vencimiento: '2026-04-15', poliza: '1122', estado: 'Activa', tipo: 'Individual', medioPago: 'Debito por CBU', pagada: true, ultimaGestion: { tipo: 'Whatsapp', fecha: '2026-04-01', whatsappCount: 1, mailCount: 1 } },
  { id: '4', cliente: 'Ana Martínez', aseguradora: 'Zurich', vencimiento: '2026-03-04', poliza: '8877', estado: 'Vence pronto', tipo: 'Individual', medioPago: 'Cupon', pagada: false, ultimaGestion: { tipo: 'Mail', fecha: '2026-04-02', whatsappCount: 0, mailCount: 2 } },
  { id: '5', cliente: 'Pedro Sánchez', aseguradora: 'Mercantil Andina', vencimiento: '2026-02-28', poliza: '3344', estado: 'Vencida', tipo: 'Individual', medioPago: 'Tarjeta de credito', pagada: true, ultimaGestion: { tipo: 'Whatsapp', fecha: '2026-04-03', whatsappCount: 3, mailCount: 0 } },
  { id: '6', cliente: 'Tech Solutions S.A.', aseguradora: 'Prevención ART', vencimiento: '2026-03-03', poliza: 'ART-101', estado: 'Vence pronto', tipo: 'Empresa', rubro: 'Tecnología', medioPago: 'Debito por CBU', pagada: true, ultimaGestion: { tipo: 'Mail', fecha: '2026-04-03', whatsappCount: 1, mailCount: 1 } },
  { id: '7', cliente: 'Logística Express', aseguradora: 'Experta ART', vencimiento: '2026-03-07', poliza: 'ART-202', estado: 'Activa', tipo: 'Empresa', rubro: 'Transporte', medioPago: 'Cupon', pagada: false, ultimaGestion: { tipo: 'Whatsapp', fecha: '2026-04-02', whatsappCount: 1, mailCount: 0 } },
  { id: '8', cliente: 'Consorcio Edificio Sol', aseguradora: 'Sancor Seguros', vencimiento: '2026-03-02', poliza: 'CON-505', estado: 'Vence pronto', tipo: 'Empresa', rubro: 'Inmobiliario', medioPago: 'Tarjeta de credito', pagada: true, ultimaGestion: { tipo: 'Mail', fecha: '2026-04-01', whatsappCount: 0, mailCount: 1 } },
  { id: '9', cliente: 'Roberto Gómez', aseguradora: 'Zurich', vencimiento: '2026-03-06', poliza: 'VID-999', estado: 'Activa', tipo: 'Vida', medioPago: 'Debito por CBU', pagada: true, ultimaGestion: { tipo: 'Whatsapp', fecha: '2026-04-03', whatsappCount: 2, mailCount: 1 }, cuit: '20-12345678-9', subtipo: 'Individual', sumaAsegurada: 5000000, prima: 1500, moneda: 'ARS', comisionPorcentaje: 15, email: 'roberto.gomez@gmail.com', telefono: '1144556677', cp: '1425', edad: 35, fechaInicio: '2025-03-06', beneficiarios: true, prioridad: 'Baja' },
  { id: '10', cliente: 'Elena Ruiz', aseguradora: 'Sancor Seguros', vencimiento: '2026-03-04', poliza: 'RET-777', estado: 'Vence pronto', tipo: 'Retiro', medioPago: 'Cupon', pagada: false, ultimaGestion: { tipo: 'Mail', fecha: '2026-04-03', whatsappCount: 0, mailCount: 1 }, cuit: '27-98765432-1', email: 'elena.ruiz@outlook.com', telefono: '1122334455', cp: '1629', aporteMensual: 2500, fondoAcumulado: 450000 },
  { id: '11', cliente: 'Ricardo Darín', aseguradora: 'Zurich', vencimiento: '2026-04-04', poliza: 'VID-101', estado: 'Activa', tipo: 'Vida', medioPago: 'Cupon', pagada: true, groupId: 'group-1', cuota: '1/3', fechaInicio: '2026-03-04', prima: 2000, comisionPorcentaje: 10, edad: 65, subtipo: 'Individual' },
  { id: '12', cliente: 'Ricardo Darín', aseguradora: 'Zurich', vencimiento: '2026-05-04', poliza: '', estado: 'Activa', tipo: 'Vida', medioPago: 'Cupon', pagada: false, groupId: 'group-1', cuota: '2/3', fechaInicio: '2026-04-05', prima: 2000, comisionPorcentaje: 10, edad: 65, subtipo: 'Individual' },
  { id: '13', cliente: 'Ricardo Darín', aseguradora: 'Zurich', vencimiento: '2026-06-04', poliza: '', estado: 'Activa', tipo: 'Vida', medioPago: 'Cupon', pagada: false, groupId: 'group-1', cuota: '3/3', fechaInicio: '2026-05-05', prima: 2000, comisionPorcentaje: 10, edad: 65, subtipo: 'Individual' },
];

export const MOCK_INSURERS: InsuranceCompany[] = [
  {
    id: '1',
    razonSocial: 'Federación Patronal Seguros',
    domicilioComercial: 'Av. 51 N° 770, La Plata, Buenos Aires',
    cuit: '30-50000473-4',
    condicionIva: 'Responsable Inscripto',
    mail: 'info@fedpat.com.ar',
    telefono: '0800-222-3522',
    urlWeb: 'https://www.fedpat.com.ar',
    facturacionComisiones: [
      { 
        id: 'i3', 
        periodo: 'Marzo 2026', 
        aseguradoraId: '1',
        numeroFactura: '0002-00000456', 
        fechaEmision: '2026-03-31',
        montoEsperado: 2500,
        montoFacturado: 2500,
        montoCobrado: 2500,
        moneda: 'USD', 
        estado: 'Cobrada',
        vencimiento: '2026-04-15',
        pagos: [
          { id: 'p1', fecha: '2026-04-10', monto: 2500, medioPago: 'Transferencia' }
        ],
        polizasIds: ['1', '2'],
        diferenciaDetectada: false
      }
    ]
  },
  {
    id: '2',
    razonSocial: 'Sancor Seguros',
    domicilioComercial: 'Ruta 34 km 257, Sunchales, Santa Fe',
    cuit: '30-50004946-0',
    condicionIva: 'Responsable Inscripto',
    mail: 'contacto@sancorseguros.com',
    telefono: '0800-444-2850',
    urlWeb: 'https://www.sancorseguros.com.ar',
    facturacionComisiones: [
      { 
        id: 'i1', 
        periodo: 'Abril 2026', 
        aseguradoraId: '2',
        numeroFactura: '0001-00000123', 
        fechaEmision: '2026-04-01',
        montoEsperado: 150000,
        montoFacturado: 150000,
        montoCobrado: 150000,
        moneda: 'ARS', 
        estado: 'Cobrada',
        vencimiento: '2026-04-15',
        pagos: [
          { id: 'p2', fecha: '2026-04-05', monto: 150000, medioPago: 'Efectivo' }
        ],
        polizasIds: ['3'],
        diferenciaDetectada: false
      },
      { 
        id: 'i2', 
        periodo: 'Mayo 2026', 
        aseguradoraId: '2',
        numeroFactura: '', 
        fechaEmision: '2026-05-01',
        montoEsperado: 120000,
        montoFacturado: 0,
        montoCobrado: 0,
        moneda: 'ARS', 
        estado: 'Pendiente',
        vencimiento: '2026-05-15',
        pagos: [],
        polizasIds: ['4'],
        diferenciaDetectada: false
      },
      { 
        id: 'i4', 
        periodo: 'Junio 2026', 
        aseguradoraId: '2',
        numeroFactura: '0001-00000789', 
        fechaEmision: '2026-06-01',
        montoEsperado: 200000,
        montoFacturado: 200000,
        montoCobrado: 180000,
        moneda: 'ARS', 
        estado: 'Parcial',
        vencimiento: '2026-06-15',
        pagos: [
          { id: 'p3', fecha: '2026-06-10', monto: 180000, medioPago: 'Transferencia' }
        ],
        polizasIds: ['5'],
        diferenciaDetectada: true,
        notas: 'Diferencia en liquidación de rubro Automotores'
      }
    ]
  },
  {
    id: '3',
    razonSocial: 'La Segunda Seguros',
    domicilioComercial: 'Brigadier Juan Manuel de Rosas 957, Rosario, Santa Fe',
    cuit: '30-50000324-1',
    condicionIva: 'Responsable Inscripto',
    mail: 'atencion@lasegunda.com.ar',
    telefono: '0800-444-0504',
    urlWeb: 'https://www.lasegunda.com.ar'
  },
  {
    id: '4',
    razonSocial: 'Mercantil Andina',
    domicilioComercial: 'Necochea 183, Mendoza',
    cuit: '30-50003639-3',
    condicionIva: 'Responsable Inscripto',
    mail: 'contacto@mercantilandina.com.ar',
    telefono: '0800-888-4488',
    urlWeb: 'https://www.mercantilandina.com.ar'
  },
  {
    id: '5',
    razonSocial: 'Zurich Argentina',
    domicilioComercial: 'Cerrito 1250, CABA',
    cuit: '30-50004124-9',
    condicionIva: 'Responsable Inscripto',
    mail: 'clientes@zurich.com.ar',
    telefono: '0800-333-987424',
    urlWeb: 'https://www.zurich.com.ar'
  },
  { id: '6', razonSocial: 'Allianz Argentina', cuit: '30-50003645-8', condicionIva: 'Responsable Inscripto', mail: 'info@allianz.com.ar', telefono: '0810-222-2243', urlWeb: 'https://www.allianz.com.ar', domicilioComercial: 'Av. Corrientes 299, CABA' },
  { id: '7', razonSocial: 'Mapfre Argentina', cuit: '30-50000753-9', condicionIva: 'Responsable Inscripto', mail: 'atencion@mapfre.com.ar', telefono: '0810-666-4422', urlWeb: 'https://www.mapfre.com.ar', domicilioComercial: 'Maipú 225, CABA' },
  { id: '8', razonSocial: 'Provincia Seguros', cuit: '30-66320562-1', condicionIva: 'Responsable Inscripto', mail: 'contacto@provinciaseguros.com.ar', telefono: '0810-222-2444', urlWeb: 'https://www.provinciaseguros.com.ar', domicilioComercial: 'Carlos Pellegrini 91, CABA' },
  { id: '9', razonSocial: 'Galicia Seguros', cuit: '30-50005433-2', condicionIva: 'Responsable Inscripto', mail: 'atencion@galiciaseguros.com.ar', telefono: '0800-555-9999', urlWeb: 'https://www.galiciaseguros.com.ar', domicilioComercial: 'Maipú 225, CABA' },
  { id: '10', razonSocial: 'BBVA Seguros', cuit: '30-50005433-2', condicionIva: 'Responsable Inscripto', mail: 'contacto@bbvaseguros.com.ar', telefono: '0800-999-2282', urlWeb: 'https://www.bbvaseguros.com.ar', domicilioComercial: 'Av. Córdoba 111, CABA' },
  { id: '11', razonSocial: 'HSBC Seguros', cuit: '30-66320562-1', condicionIva: 'Responsable Inscripto', mail: 'contacto@hsbc.com.ar', telefono: '0810-333-4722', urlWeb: 'https://www.hsbc.com.ar', domicilioComercial: 'Florida 201, CABA' },
  { id: '12', razonSocial: 'SMG Seguros', cuit: '30-68731043-4', condicionIva: 'Responsable Inscripto', mail: 'contacto@smgseguros.com.ar', telefono: '0810-333-3764', urlWeb: 'https://www.smgseguros.com.ar', domicilioComercial: 'Av. Corrientes 1865, CABA' },
  { id: '13', razonSocial: 'La Caja Seguros', cuit: '30-66320562-1', condicionIva: 'Responsable Inscripto', mail: 'contacto@lacaja.com.ar', telefono: '0810-555-2252', urlWeb: 'https://www.lacaja.com.ar', domicilioComercial: 'Fitz Roy 957, CABA' },
  { id: '14', razonSocial: 'Seguros Rivadavia', cuit: '30-50000473-4', condicionIva: 'Responsable Inscripto', mail: 'contacto@segurosrivadavia.com', telefono: '0810-999-3200', urlWeb: 'https://www.segurosrivadavia.com', domicilioComercial: 'Av. 7 N° 755, La Plata' },
  { id: '15', razonSocial: 'Triunfo Seguros', cuit: '30-50003639-3', condicionIva: 'Responsable Inscripto', mail: 'contacto@triunfoseguros.com', telefono: '0810-333-3833', urlWeb: 'https://www.triunfoseguros.com', domicilioComercial: 'Av. España 1002, Mendoza' },
  { id: '16', razonSocial: 'ATM Seguros', cuit: '30-50004124-9', condicionIva: 'Responsable Inscripto', mail: 'contacto@atmseguros.com.ar', telefono: '0810-333-3286', urlWeb: 'https://www.atmseguros.com.ar', domicilioComercial: 'Florida 833, CABA' },
  { id: '17', razonSocial: 'San Cristóbal Seguros', cuit: '30-50003645-8', condicionIva: 'Responsable Inscripto', mail: 'contacto@sancristobal.com.ar', telefono: '0810-222-8887', urlWeb: 'https://www.sancristobal.com.ar', domicilioComercial: 'Italia 646, Rosario' },
  { id: '18', razonSocial: 'Berkley Argentina', cuit: '30-50000753-9', condicionIva: 'Responsable Inscripto', mail: 'contacto@berkley.com.ar', telefono: '0810-555-3333', urlWeb: 'https://www.berkley.com.ar', domicilioComercial: 'Carlos Pellegrini 1023, CABA' },
  { id: '19', razonSocial: 'Chubb Argentina', cuit: '30-66320562-1', condicionIva: 'Responsable Inscripto', mail: 'contacto@chubb.com', telefono: '0800-444-2482', urlWeb: 'https://www.chubb.com/ar', domicilioComercial: 'Av. Leandro N. Alem 855, CABA' },
  { id: '20', razonSocial: 'HDI Seguros', cuit: '30-50005433-2', condicionIva: 'Responsable Inscripto', mail: 'contacto@hdi.com.ar', telefono: '0800-333-4444', urlWeb: 'https://www.hdi.com.ar', domicilioComercial: 'Tte. Gral. J. D. Perón 650, CABA' },
  { id: '21', razonSocial: 'Intégrity Seguros', cuit: '30-50005433-2', condicionIva: 'Responsable Inscripto', mail: 'contacto@integrityseguros.com.ar', telefono: '0810-333-3456', urlWeb: 'https://www.integrityseguros.com.ar', domicilioComercial: 'Av. Paseo Colón 357, CABA' },
  { id: '22', razonSocial: 'Orbis Seguros', cuit: '30-66320562-1', condicionIva: 'Responsable Inscripto', mail: 'contacto@orbis.com.ar', telefono: '0810-666-7247', urlWeb: 'https://www.orbis.com.ar', domicilioComercial: 'Bauness 2040, CABA' },
  { id: '23', razonSocial: 'Nación Seguros', cuit: '30-68731043-4', condicionIva: 'Responsable Inscripto', mail: 'contacto@nacionseguros.com.ar', telefono: '0800-888-9900', urlWeb: 'https://www.nacionseguros.com.ar', domicilioComercial: 'San Martín 913, CABA' },
  { id: '24', razonSocial: 'Río Uruguay Seguros', cuit: '30-66320562-1', condicionIva: 'Responsable Inscripto', mail: 'contacto@rus.com.ar', telefono: '0810-888-7080', urlWeb: 'https://www.rus.com.ar', domicilioComercial: 'Congreso de Tucumán 21, Concepción del Uruguay' },
  { id: '25', razonSocial: 'Escudo Seguros', cuit: '30-50000473-4', condicionIva: 'Responsable Inscripto', mail: 'contacto@escudoseguros.com.ar', telefono: '0810-666-3728', urlWeb: 'https://www.escudoseguros.com.ar', domicilioComercial: 'Av. Corrientes 330, CABA' },
  { id: '26', razonSocial: 'Testimonio Seguros', cuit: '30-50003639-3', condicionIva: 'Responsable Inscripto', mail: 'contacto@testimonio.com.ar', telefono: '0810-333-8378', urlWeb: 'https://www.testimonio.com.ar', domicilioComercial: 'Av. Belgrano 615, CABA' },
  { id: '27', razonSocial: 'Paraná Seguros', cuit: '30-50004124-9', condicionIva: 'Responsable Inscripto', mail: 'contacto@paranaseguros.com.ar', telefono: '0810-222-7272', urlWeb: 'https://www.paranaseguros.com.ar', domicilioComercial: 'Maipú 215, CABA' },
  { id: '28', razonSocial: 'Liderar Seguros', cuit: '30-50003645-8', condicionIva: 'Responsable Inscripto', mail: 'contacto@liderarseguros.com.ar', telefono: '0810-222-5433', urlWeb: 'https://www.liderarseguros.com.ar', domicilioComercial: 'Reconquista 585, CABA' },
  { id: '29', razonSocial: 'Boston Seguros', cuit: '30-50000753-9', condicionIva: 'Responsable Inscripto', mail: 'contacto@boston.com.ar', telefono: '0810-555-2678', urlWeb: 'https://www.boston.com.ar', domicilioComercial: 'Suipacha 268, CABA' },
  { id: '30', razonSocial: 'Caruso Seguros', cuit: '30-66320562-1', condicionIva: 'Responsable Inscripto', mail: 'contacto@caruso.com.ar', telefono: '0810-222-2787', urlWeb: 'https://www.caruso.com.ar', domicilioComercial: 'Av. Colón 785, Córdoba' },
  { id: '31', razonSocial: 'Hamburgo Seguros', cuit: '30-50005433-2', condicionIva: 'Responsable Inscripto', mail: 'contacto@hamburgo.com.ar', telefono: '0810-888-4262', urlWeb: 'https://www.hamburgo.com.ar', domicilioComercial: 'Independencia 56, Santiago del Estero' },
  { id: '32', razonSocial: 'Victoria Seguros', cuit: '30-50005433-2', condicionIva: 'Responsable Inscripto', mail: 'contacto@victoria.com.ar', telefono: '0810-333-8428', urlWeb: 'https://www.victoria.com.ar', domicilioComercial: 'Av. Paseo Colón 357, CABA' },
  { id: '33', razonSocial: 'Zurich Life', cuit: '30-66320562-1', condicionIva: 'Responsable Inscripto', mail: 'vida@zurich.com.ar', telefono: '0800-333-9874', urlWeb: 'https://www.zurich.com.ar', domicilioComercial: 'Cerrito 1250, CABA' },
  { id: '34', razonSocial: 'MetLife Argentina', cuit: '30-68731043-4', condicionIva: 'Responsable Inscripto', mail: 'atencion@metlife.com.ar', telefono: '0800-222-6385', urlWeb: 'https://www.metlife.com.ar', domicilioComercial: 'Av. Tte. Gral. J. D. Perón 646, CABA' },
  { id: '35', razonSocial: 'Prudential Argentina', cuit: '30-66320562-1', condicionIva: 'Responsable Inscripto', mail: 'atencion@prudential.com.ar', telefono: '0800-222-7783', urlWeb: 'https://www.prudential.com.ar', domicilioComercial: 'Av. del Libertador 2442, Olivos' },
  { id: '36', razonSocial: 'Orígenes Seguros de Retiro', cuit: '30-50000473-4', condicionIva: 'Responsable Inscripto', mail: 'contacto@origenes.com.ar', telefono: '0810-666-6744', urlWeb: 'https://www.origenes.com.ar', domicilioComercial: 'Av. Corrientes 1174, CABA' },
  { id: '37', razonSocial: 'HSBC Seguros de Vida', cuit: '30-50003639-3', condicionIva: 'Responsable Inscripto', mail: 'vida@hsbc.com.ar', telefono: '0810-333-4722', urlWeb: 'https://www.hsbc.com.ar', domicilioComercial: 'Florida 201, CABA' },
  { id: '38', razonSocial: 'Galicia Seguros de Vida', cuit: '30-50004124-9', condicionIva: 'Responsable Inscripto', mail: 'vida@galiciaseguros.com.ar', telefono: '0800-555-9999', urlWeb: 'https://www.galiciaseguros.com.ar', domicilioComercial: 'Maipú 225, CABA' },
  { id: '39', razonSocial: 'Nación Seguros de Retiro', cuit: '30-50003645-8', condicionIva: 'Responsable Inscripto', mail: 'retiro@nacionseguros.com.ar', telefono: '0800-888-9900', urlWeb: 'https://www.nacionseguros.com.ar', domicilioComercial: 'San Martín 913, CABA' },
  { id: '40', razonSocial: 'San Cristóbal Retiro', cuit: '30-50000753-9', condicionIva: 'Responsable Inscripto', mail: 'retiro@sancristobal.com.ar', telefono: '0810-222-8887', urlWeb: 'https://www.sancristobal.com.ar', domicilioComercial: 'Italia 646, Rosario' },
  { id: '41', razonSocial: 'SMG Life', cuit: '30-66320562-1', condicionIva: 'Responsable Inscripto', mail: 'atencion@smglife.com.ar', telefono: '0810-333-3764', urlWeb: 'https://www.smglife.com.ar', domicilioComercial: 'Av. Corrientes 1865, CABA' },
  { id: '42', razonSocial: 'Prevención ART', cuit: '30-50005433-2', condicionIva: 'Responsable Inscripto', mail: 'contacto@prevencionart.com.ar', telefono: '0800-444-2782', urlWeb: 'https://www.prevencionart.com.ar', domicilioComercial: 'Ruta 34 km 257, Sunchales' },
  { id: '43', razonSocial: 'Provincia ART', cuit: '30-50005433-2', condicionIva: 'Responsable Inscripto', mail: 'contacto@provinciaart.com.ar', telefono: '0800-333-1278', urlWeb: 'https://www.provinciaart.com.ar', domicilioComercial: 'Carlos Pellegrini 91, CABA' },
  { id: '44', razonSocial: 'Experta ART', cuit: '30-66320562-1', condicionIva: 'Responsable Inscripto', mail: 'atencion@experta.com.ar', telefono: '0800-777-7278', urlWeb: 'https://www.experta.com.ar', domicilioComercial: 'Av. Córdoba 111, CABA' },
  { id: '45', razonSocial: 'La Segunda ART', cuit: '30-68731043-4', condicionIva: 'Responsable Inscripto', mail: 'atencion@lasegunda.com.ar', telefono: '0800-444-0504', urlWeb: 'https://www.lasegunda.com.ar', domicilioComercial: 'Brigadier Juan Manuel de Rosas 957, Rosario' },
  { id: '46', razonSocial: 'Galeno ART', cuit: '30-66320562-1', condicionIva: 'Responsable Inscripto', mail: 'atencion@galenoart.com.ar', telefono: '0800-333-4253', urlWeb: 'https://www.galenoart.com.ar', domicilioComercial: 'Av. Corrientes 1865, CABA' },
  { id: '47', razonSocial: 'Swiss Medical ART', cuit: '30-50000473-4', condicionIva: 'Responsable Inscripto', mail: 'atencion@swissmedical.com.ar', telefono: '0810-333-3764', urlWeb: 'https://www.swissmedical.com.ar', domicilioComercial: 'Av. Corrientes 1865, CABA' },
  { id: '48', razonSocial: 'Asociart ART', cuit: '30-50003639-3', condicionIva: 'Responsable Inscripto', mail: 'atencion@asociart.com.ar', telefono: '0800-888-2782', urlWeb: 'https://www.asociart.com.ar', domicilioComercial: 'Av. Leandro N. Alem 621, CABA' },
  { id: '49', razonSocial: 'Berkley ART', cuit: '30-50004124-9', condicionIva: 'Responsable Inscripto', mail: 'atencion@berkley.com.ar', telefono: '0810-555-3333', urlWeb: 'https://www.berkley.com.ar', domicilioComercial: 'Carlos Pellegrini 1023, CABA' },
  { id: '50', razonSocial: 'Omint ART', cuit: '30-50003645-8', condicionIva: 'Responsable Inscripto', mail: 'atencion@omintart.com.ar', telefono: '0800-555-6646', urlWeb: 'https://www.omintart.com.ar', domicilioComercial: 'Av. de Mayo 645, CABA' }
];

export const getExpiringPoliciesCount = (policies: Policy[]) => {
  const today = new Date();
  return policies.filter(p => {
    const daysLeft = differenceInDays(parseISO(p.vencimiento), today);
    return daysLeft >= 0 && daysLeft <= 5;
  }).length;
};
