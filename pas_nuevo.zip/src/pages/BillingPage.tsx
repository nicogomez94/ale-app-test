import React, { useState } from 'react';
import { 
  Search, 
  CheckCircle2, 
  Circle, 
  FileText, 
  DollarSign,
  Filter,
  Plus,
  Edit,
  Trash2
} from 'lucide-react';
import { 
  Box, 
  Typography, 
  Card, 
  CardContent, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow, 
  Paper, 
  Chip, 
  IconButton, 
  Button,
  TextField,
  InputAdornment,
  Grid,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  MenuItem,
  FormControl,
  InputLabel,
  Select
} from '@mui/material';
import { InsuranceCompany, CommissionInvoice } from '../types';

interface BillingPageProps {
  insurers: InsuranceCompany[];
  setInsurers: React.Dispatch<React.SetStateAction<InsuranceCompany[]>>;
}

export const BillingPage: React.FC<BillingPageProps> = ({ insurers, setInsurers }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [openInvoiceDialog, setOpenInvoiceDialog] = useState(false);
  const [editingInvoice, setEditingInvoice] = useState<CommissionInvoice | null>(null);
  const [selectedInsurerId, setSelectedInsurerId] = useState('');
  const [invoiceData, setInvoiceData] = useState<Partial<CommissionInvoice>>({
    periodo: '',
    estado: 'Pendiente',
    numeroFactura: '',
    montoFacturado: 0,
    moneda: 'ARS'
  });

  const allInvoices = insurers.flatMap(insurer => 
    (insurer.facturacionComisiones || []).map(invoice => ({
      ...invoice,
      insurerName: insurer.razonSocial,
      insurerId: insurer.id
    }))
  ).sort((a, b) => new Date(b.fechaEmision).getTime() - new Date(a.fechaEmision).getTime());

  const filteredInvoices = allInvoices.filter(invoice => 
    invoice.insurerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    invoice.periodo.toLowerCase().includes(searchTerm.toLowerCase()) ||
    invoice.numeroFactura.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleOpenInvoiceDialog = (insurerId: string = '', invoice?: CommissionInvoice) => {
    setSelectedInsurerId(insurerId);
    if (invoice) {
      setEditingInvoice(invoice);
      setInvoiceData(invoice);
    } else {
      setEditingInvoice(null);
      setInvoiceData({
        periodo: '',
        estado: 'Pendiente',
        numeroFactura: '',
        montoFacturado: undefined as any,
        moneda: 'ARS'
      });
    }
    setOpenInvoiceDialog(true);
  };

  const handleSaveInvoice = () => {
    if (!selectedInsurerId) return;

    setInsurers(prev => prev.map(insurer => {
      if (insurer.id === selectedInsurerId) {
        const invoices = insurer.facturacionComisiones || [];
        if (editingInvoice) {
          return {
            ...insurer,
            facturacionComisiones: invoices.map(i => i.id === editingInvoice.id ? { ...i, ...invoiceData } as CommissionInvoice : i)
          };
        } else {
          const newInvoice: CommissionInvoice = {
            ...invoiceData,
            id: Math.random().toString(36).substr(2, 9),
            fechaEmision: new Date().toISOString().split('T')[0],
            montoEsperado: invoiceData.montoFacturado || 0,
            montoCobrado: 0,
            vencimiento: new Date().toISOString().split('T')[0],
            pagos: [],
            polizasIds: [],
            aseguradoraId: selectedInsurerId,
            diferenciaDetectada: false
          } as CommissionInvoice;
          return {
            ...insurer,
            facturacionComisiones: [...invoices, newInvoice]
          };
        }
      }
      return insurer;
    }));
    setOpenInvoiceDialog(false);
  };

  const handleDeleteInvoice = (insurerId: string, invoiceId: string) => {
    if (window.confirm('¿Estás seguro de que deseas eliminar esta factura?')) {
      setInsurers(prev => prev.map(insurer => {
        if (insurer.id === insurerId) {
          return {
            ...insurer,
            facturacionComisiones: (insurer.facturacionComisiones || []).filter(i => i.id !== invoiceId)
          };
        }
        return insurer;
      }));
    }
  };

  const handleToggleCobrada = (insurerId: string, invoiceId: string) => {
    setInsurers(prev => prev.map(insurer => {
      if (insurer.id === insurerId) {
        return {
          ...insurer,
          facturacionComisiones: (insurer.facturacionComisiones || []).map(i => 
            i.id === invoiceId ? { ...i, estado: i.estado === 'Cobrada' ? 'Facturada' : 'Cobrada', montoCobrado: i.estado === 'Cobrada' ? 0 : i.montoFacturado } : i
          )
        };
      }
      return insurer;
    }));
  };

  const handleToggleFacturada = (insurerId: string, invoiceId: string) => {
    setInsurers(prev => prev.map(insurer => {
      if (insurer.id === insurerId) {
        return {
          ...insurer,
          facturacionComisiones: (insurer.facturacionComisiones || []).map(i => 
            i.id === invoiceId ? { ...i, estado: i.estado === 'Facturada' ? 'Pendiente' : 'Facturada' } : i
          )
        };
      }
      return insurer;
    }));
  };

  const stats = {
    invoiceCount: filteredInvoices.length,
    totalArs: filteredInvoices.filter(i => i.moneda === 'ARS').reduce((acc, curr) => acc + curr.montoFacturado, 0),
    totalUsd: filteredInvoices.filter(i => i.moneda === 'USD').reduce((acc, curr) => acc + curr.montoFacturado, 0),
  };

  return (
    <Box>
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 800, color: 'primary.main' }}>Facturación de Comisiones</Typography>
          <Typography variant="body1" color="text.secondary">Control centralizado de facturas y cobros de todas las aseguradoras</Typography>
        </Box>
        <Button 
          variant="contained" 
          startIcon={<Plus size={20} />}
          onClick={() => handleOpenInvoiceDialog()}
          sx={{ borderRadius: 2, px: 3 }}
        >
          Nueva Factura
        </Button>
      </Box>

      <Card sx={{ mb: 4 }}>
        <CardContent>
          <TextField
            fullWidth
            placeholder="Buscar por aseguradora, periodo o nro de factura..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search size={20} />
                </InputAdornment>
              ),
            }}
          />
        </CardContent>
      </Card>

      <TableContainer component={Paper} sx={{ borderRadius: 3, boxShadow: '0 4px 20px rgba(0,0,0,0.05)' }}>
        <Table>
          <TableHead sx={{ bgcolor: 'grey.50' }}>
            <TableRow>
              <TableCell sx={{ fontWeight: 700 }}>Aseguradora</TableCell>
              <TableCell sx={{ fontWeight: 700 }}>Periodo</TableCell>
              <TableCell sx={{ fontWeight: 700 }}>N° Factura</TableCell>
              <TableCell sx={{ fontWeight: 700 }}>Monto</TableCell>
              <TableCell sx={{ fontWeight: 700, textAlign: 'center' }}>Facturada</TableCell>
              <TableCell sx={{ fontWeight: 700, textAlign: 'center' }}>Cobrada</TableCell>
              <TableCell sx={{ fontWeight: 700, textAlign: 'right' }}>Acciones</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredInvoices.map((invoice) => (
              <TableRow key={invoice.id} hover>
                <TableCell sx={{ fontWeight: 600 }}>{invoice.insurerName}</TableCell>
                <TableCell>{invoice.periodo}</TableCell>
                <TableCell>{invoice.numeroFactura || '-'}</TableCell>
                <TableCell sx={{ fontWeight: 700 }}>
                  {invoice.moneda === 'ARS' ? '$' : 'u$s'} {invoice.montoFacturado.toLocaleString()}
                </TableCell>
                <TableCell sx={{ textAlign: 'center' }}>
                  <IconButton 
                    size="small" 
                    onClick={() => handleToggleFacturada(invoice.insurerId, invoice.id)}
                    color={(invoice as any).estado !== 'Pendiente' ? 'success' : 'default'}
                  >
                    {(invoice as any).estado !== 'Pendiente' ? <CheckCircle2 size={20} /> : <Circle size={20} />}
                  </IconButton>
                </TableCell>
                <TableCell sx={{ textAlign: 'center' }}>
                  <IconButton 
                    size="small" 
                    disabled={(invoice as any).estado === 'Pendiente'}
                    onClick={() => handleToggleCobrada(invoice.insurerId, invoice.id)}
                    color={(invoice as any).estado === 'Cobrada' ? 'success' : 'default'}
                  >
                    {(invoice as any).estado === 'Cobrada' ? <CheckCircle2 size={20} /> : <Circle size={20} />}
                  </IconButton>
                </TableCell>
                <TableCell sx={{ textAlign: 'right' }}>
                  <IconButton size="small" onClick={() => handleOpenInvoiceDialog(invoice.insurerId, invoice as any)} color="primary">
                    <Edit size={16} />
                  </IconButton>
                  <IconButton size="small" onClick={() => handleDeleteInvoice(invoice.insurerId, invoice.id)} color="error">
                    <Trash2 size={16} />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
            {filteredInvoices.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} sx={{ textAlign: 'center', py: 8 }}>
                  <Typography color="text.secondary">No se encontraron registros de facturación</Typography>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
      <Dialog open={openInvoiceDialog} onClose={() => setOpenInvoiceDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ fontWeight: 800 }}>
          {editingInvoice ? 'Editar Factura' : 'Nueva Factura de Comisión'}
        </DialogTitle>
        <DialogContent dividers>
          <Grid container spacing={2} sx={{ mt: 0.5 }}>
            <Grid size={{ xs: 12 }}>
              <FormControl fullWidth>
                <InputLabel>Aseguradora</InputLabel>
                <Select
                  value={selectedInsurerId}
                  label="Aseguradora"
                  onChange={(e) => setSelectedInsurerId(e.target.value)}
                  disabled={!!editingInvoice}
                >
                  {insurers.map(insurer => (
                    <MenuItem key={insurer.id} value={insurer.id}>{insurer.razonSocial}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField
                fullWidth
                label="Periodo (ej: Abril 2026 - 1ra Quincena)"
                value={invoiceData.periodo}
                onChange={(e) => setInvoiceData({ ...invoiceData, periodo: e.target.value })}
              />
            </Grid>
            <Grid size={{ xs: 6 }}>
              <TextField
                fullWidth
                label="Monto"
                type="number"
                value={invoiceData.montoFacturado || ''}
                onChange={(e) => setInvoiceData({ ...invoiceData, montoFacturado: parseFloat(e.target.value) })}
              />
            </Grid>
            <Grid size={{ xs: 6 }}>
              <FormControl fullWidth>
                <InputLabel>Moneda</InputLabel>
                <Select
                  value={invoiceData.moneda}
                  label="Moneda"
                  onChange={(e) => setInvoiceData({ ...invoiceData, moneda: e.target.value as any })}
                >
                  <MenuItem value="ARS">ARS ($)</MenuItem>
                  <MenuItem value="USD">USD (u$s)</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField
                fullWidth
                label="Número de Factura"
                value={invoiceData.numeroFactura}
                onChange={(e) => setInvoiceData({ ...invoiceData, numeroFactura: e.target.value })}
                placeholder="0001-00000XXX"
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ p: 2.5 }}>
          <Button onClick={() => setOpenInvoiceDialog(false)} color="inherit">Cancelar</Button>
          <Button 
            onClick={handleSaveInvoice} 
            variant="contained" 
            disabled={!selectedInsurerId || !invoiceData.periodo || !invoiceData.montoFacturado}
          >
            Guardar Factura
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
