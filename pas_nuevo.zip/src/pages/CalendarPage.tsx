import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Card, 
  CardContent, 
  Grid, 
  IconButton, 
  Button, 
  Dialog, 
  DialogTitle, 
  DialogContent, 
  DialogActions, 
  TextField, 
  MenuItem,
  Badge,
  Tooltip,
  Divider
} from '@mui/material';
import { 
  ChevronLeft, 
  ChevronRight, 
  Plus, 
  StickyNote, 
  Bell,
  Trash2,
  Calendar as CalendarIcon
} from 'lucide-react';
import { 
  format, 
  addMonths, 
  subMonths, 
  startOfMonth, 
  endOfMonth, 
  startOfWeek, 
  endOfWeek, 
  isSameMonth, 
  isSameDay, 
  addDays, 
  eachDayOfInterval,
  parseISO
} from 'date-fns';
import { es } from 'date-fns/locale';
import { getArgentinaHolidays } from '../data/argentinaHolidays';

interface Note {
  id: string;
  date: string;
  text: string;
  color: string;
  isRead: boolean;
}

interface CalendarPageProps {
  notes: Note[];
  setNotes: (notes: Note[]) => void;
}

export const CalendarPage: React.FC<CalendarPageProps> = ({ notes, setNotes }) => {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [open, setOpen] = useState(false);
  const [noteText, setNoteText] = useState('');
  const [noteColor, setNoteColor] = useState('#4f46e5');

  const colors = [
    { name: 'Indigo', value: '#4f46e5' },
    { name: 'Esmeralda', value: '#10b981' },
    { name: 'Rosa', value: '#ec4899' },
    { name: 'Ámbar', value: '#f59e0b' },
    { name: 'Cian', value: '#06b6d4' },
    { name: 'Rojo', value: '#ef4444' },
  ];

  const handleDateClick = (day: Date) => {
    setSelectedDate(day);
    
    // Mark all notes for this day as read if it's today
    if (isSameDay(day, new Date())) {
      const dateStr = format(day, 'yyyy-MM-dd');
      const updatedNotes = notes.map(n => 
        n.date === dateStr ? { ...n, isRead: true } : n
      );
      setNotes(updatedNotes);
    }
    
    setNoteText('');
    setNoteColor('#4f46e5');
    setOpen(true);
  };

  const handleSaveNote = () => {
    if (!selectedDate || noteText.trim() === '') return;
    
    const dateStr = format(selectedDate, 'yyyy-MM-dd');
    const newNote: Note = {
      id: Math.random().toString(36).substr(2, 9),
      date: dateStr,
      text: noteText,
      color: noteColor,
      isRead: isSameDay(selectedDate, new Date())
    };

    setNotes([...notes, newNote]);
    setNoteText('');
  };

  const handleDeleteNote = (id: string) => {
    setNotes(notes.filter(n => n.id !== id));
  };

  const renderHeader = () => (
    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
      <Box>
        <Typography variant="h4" sx={{ fontWeight: 900, display: 'flex', alignItems: 'center', gap: 2, color: 'primary.main', letterSpacing: -1.5 }}>
          <CalendarIcon size={40} strokeWidth={2.5} /> Agenda de Negocios
        </Typography>
        <Typography variant="body1" color="text.secondary" sx={{ fontWeight: 600, opacity: 0.8 }}>Planifica tu éxito día tras día.</Typography>
      </Box>
      <Box sx={{ 
        display: 'flex', 
        alignItems: 'center', 
        gap: 1, 
        bgcolor: 'background.paper', 
        p: 1, 
        borderRadius: 4, 
        boxShadow: '0 4px 12px rgba(0,0,0,0.05)',
        border: '1px solid', 
        borderColor: 'divider' 
      }}>
        <IconButton onClick={() => setCurrentMonth(subMonths(currentMonth, 1))} size="small" sx={{ bgcolor: 'grey.50' }}>
          <ChevronLeft size={20} />
        </IconButton>
        <Typography variant="h6" sx={{ fontWeight: 800, minWidth: 160, textAlign: 'center', textTransform: 'capitalize', color: 'primary.dark' }}>
          {format(currentMonth, 'MMMM yyyy', { locale: es })}
        </Typography>
        <IconButton onClick={() => setCurrentMonth(addMonths(currentMonth, 1))} size="small" sx={{ bgcolor: 'grey.50' }}>
          <ChevronRight size={20} />
        </IconButton>
        <Divider orientation="vertical" flexItem sx={{ mx: 1 }} />
        <Button 
          variant="contained" 
          size="small" 
          onClick={() => setCurrentMonth(new Date())}
          sx={{ borderRadius: 2.5, fontWeight: 800, px: 2, boxShadow: 'none' }}
        >
          Hoy
        </Button>
      </Box>
    </Box>
  );

  const renderDays = () => {
    const days = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
    return (
      <Grid container columns={7} sx={{ mb: 0, bgcolor: 'grey.50', borderBottom: '1px solid', borderColor: 'divider' }}>
        {days.map(day => (
          <Grid size={1} key={day} sx={{ textAlign: 'center', py: 2 }}>
            <Typography variant="caption" sx={{ fontWeight: 900, color: 'text.secondary', textTransform: 'uppercase', letterSpacing: 1.5, fontSize: '0.7rem' }}>{day}</Typography>
          </Grid>
        ))}
      </Grid>
    );
  };

  const renderCells = () => {
    const monthStart = startOfMonth(currentMonth);
    const monthEnd = endOfMonth(monthStart);
    const startDate = startOfWeek(monthStart);
    const endDate = endOfWeek(monthEnd);

    const calendarDays = eachDayOfInterval({ start: startDate, end: endDate });
    const today = new Date();
    const argentinaHolidays = getArgentinaHolidays(currentMonth.getFullYear());

    return (
      <Grid container columns={7}>
        {calendarDays.map((day, i) => {
          const dateStr = format(day, 'yyyy-MM-dd');
          const dayNotes = notes.filter(n => n.date === dateStr);
          const dayHoliday = argentinaHolidays.find(h => h.date === dateStr);
          const isToday = isSameDay(day, today);
          const isCurrentMonth = isSameMonth(day, monthStart);
          const hasUnreadNote = isToday && dayNotes.some(n => !n.isRead);

          return (
            <Grid 
              size={1} 
              key={i} 
              onClick={() => handleDateClick(day)}
              sx={{ 
                height: 100, 
                borderRight: '1px solid', 
                borderBottom: '1px solid', 
                borderColor: 'divider',
                p: 1,
                cursor: 'pointer',
                bgcolor: dayHoliday ? '#fff9c4' : isToday ? 'primary.light' : isCurrentMonth ? 'background.paper' : 'grey.50',
                opacity: dayHoliday ? 0.9 : 1,
                transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
                position: 'relative',
                overflow: 'hidden',
                '&:hover': {
                  bgcolor: dayHoliday ? '#fff176' : 'action.hover',
                  zIndex: 2,
                  boxShadow: 'inset 0 0 0 2px #4f46e5',
                  '& .holiday-text': { color: 'black' }
                }
              }}
            >
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 0.5 }}>
                <Typography 
                  variant="body2" 
                  sx={{ 
                    fontWeight: isToday ? 900 : 600,
                    width: 26,
                    height: 26,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderRadius: '8px',
                    bgcolor: isToday ? 'primary.main' : 'transparent',
                    color: isToday ? 'white' : dayHoliday ? 'black' : isCurrentMonth ? 'text.primary' : 'text.disabled',
                    fontSize: '0.85rem'
                  }}
                >
                  {format(day, 'd')}
                </Typography>
                {hasUnreadNote && (
                  <Box sx={{ 
                    width: 8, 
                    height: 8, 
                    borderRadius: '50%', 
                    bgcolor: 'error.main',
                    boxShadow: '0 0 0 2px white',
                    animation: 'pulse 2s infinite'
                  }} />
                )}
              </Box>
              
              {dayHoliday && (
                <Typography 
                  variant="caption" 
                  className="holiday-text"
                  sx={{ 
                    display: 'block',
                    fontWeight: 800,
                    color: 'black',
                    fontSize: '0.6rem',
                    lineHeight: 1.1,
                    mb: 0.5,
                    textTransform: 'uppercase'
                  }}
                >
                  🇦🇷 {dayHoliday.name}
                </Typography>
              )}
              
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
                {dayNotes.slice(0, 3).map((note) => (
                  <Box 
                    key={note.id} 
                    sx={{ 
                      px: 0.75, 
                      py: 0.25, 
                      bgcolor: `${note.color}15`, 
                      borderLeft: `3px solid ${note.color}`,
                      borderRadius: '2px',
                      overflow: 'hidden'
                    }}
                  >
                    <Typography 
                      variant="caption" 
                      sx={{ 
                        display: 'block',
                        whiteSpace: 'nowrap',
                        textOverflow: 'ellipsis',
                        overflow: 'hidden',
                        fontSize: '0.65rem',
                        fontWeight: 700,
                        color: note.color
                      }}
                    >
                      {note.text}
                    </Typography>
                  </Box>
                ))}
                {dayNotes.length > 3 && (
                  <Typography variant="caption" sx={{ fontWeight: 700, color: 'text.secondary', pl: 0.5 }}>
                    + {dayNotes.length - 3} más
                  </Typography>
                )}
              </Box>
            </Grid>
          );
        })}
      </Grid>
    );
  };

  const selectedDateNotes = selectedDate ? notes.filter(n => n.date === format(selectedDate, 'yyyy-MM-dd')) : [];
  const selectedDateHoliday = selectedDate ? getArgentinaHolidays(selectedDate.getFullYear()).find(h => h.date === format(selectedDate, 'yyyy-MM-dd')) : null;

  return (
    <Box sx={{ width: '100%', mx: 'auto', p: 4, bgcolor: '#f8fafc', borderRadius: 6, minHeight: 'calc(100vh - 100px)' }}>
      <style>
        {`
          @keyframes pulse {
            0% { transform: scale(1); opacity: 1; box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.4); }
            70% { transform: scale(1.2); opacity: 0.5; box-shadow: 0 0 0 10px rgba(239, 68, 68, 0); }
            100% { transform: scale(1); opacity: 1; box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); }
          }
        `}
      </style>
      
      {renderHeader()}
      
      <Card sx={{ 
        borderRadius: 6, 
        overflow: 'hidden', 
        border: '1px solid', 
        borderColor: 'divider', 
        boxShadow: '0 20px 50px rgba(0,0,0,0.08)',
        bgcolor: 'background.paper'
      }}>
        <CardContent sx={{ p: 0 }}>
          {renderDays()}
          {renderCells()}
        </CardContent>
      </Card>

      <Dialog 
        open={open} 
        onClose={() => setOpen(false)} 
        maxWidth="sm" 
        fullWidth
        PaperProps={{
          sx: { borderRadius: 4, p: 1 }
        }}
      >
        <DialogTitle sx={{ fontWeight: 900, display: 'flex', alignItems: 'center', gap: 1.5, fontSize: '1.5rem', letterSpacing: -0.5 }}>
          <Box sx={{ p: 1, bgcolor: 'primary.light', borderRadius: 2, color: 'primary.main', display: 'flex' }}>
            <StickyNote size={24} />
          </Box>
          {selectedDate && format(selectedDate, "EEEE d 'de' MMMM", { locale: es })}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ mt: 1, display: 'flex', flexDirection: 'column', gap: 3 }}>
            {selectedDateHoliday && (
              <Box sx={{ 
                p: 2, 
                bgcolor: '#fff9c4', 
                borderRadius: 3, 
                border: '1px solid', 
                borderColor: '#f57f17',
                display: 'flex',
                alignItems: 'center',
                gap: 2
              }}>
                <Typography variant="h2" sx={{ fontSize: '1.5rem' }}>🇦🇷</Typography>
                <Box>
                  <Typography variant="subtitle2" sx={{ fontWeight: 800, color: 'black', textTransform: 'uppercase' }}>
                    Feriado Nacional
                  </Typography>
                  <Typography variant="body1" sx={{ fontWeight: 700, color: 'black' }}>
                    {selectedDateHoliday.name}
                  </Typography>
                </Box>
              </Box>
            )}

            {selectedDateNotes.length > 0 && (
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                <Typography variant="subtitle2" sx={{ fontWeight: 800, color: 'text.secondary', textTransform: 'uppercase', letterSpacing: 1 }}>
                  Notas Guardadas
                </Typography>
                {selectedDateNotes.map((note) => (
                  <Card key={note.id} variant="outlined" sx={{ borderRadius: 3, borderLeft: `6px solid ${note.color}` }}>
                    <CardContent sx={{ p: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                      <Typography variant="body2" sx={{ fontWeight: 600, flexGrow: 1 }}>{note.text}</Typography>
                      <IconButton size="small" color="error" onClick={() => handleDeleteNote(note.id)}>
                        <Trash2 size={16} />
                      </IconButton>
                    </CardContent>
                  </Card>
                ))}
              </Box>
            )}

            <Divider />

            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 800, color: 'text.secondary', textTransform: 'uppercase', letterSpacing: 1 }}>
                Nueva Nota
              </Typography>
              <TextField
                fullWidth
                multiline
                rows={3}
                label="¿Qué tienes pendiente?"
                placeholder="Escribe aquí tu recordatorio..."
                value={noteText}
                onChange={(e) => setNoteText(e.target.value)}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: 3 } }}
              />
              
              <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                {colors.map((color) => (
                  <Tooltip key={color.value} title={color.name}>
                    <Box 
                      onClick={() => setNoteColor(color.value)}
                      sx={{ 
                        width: 32, 
                        height: 32, 
                        borderRadius: '10px', 
                        bgcolor: color.value,
                        cursor: 'pointer',
                        border: '3px solid',
                        borderColor: noteColor === color.value ? 'white' : 'transparent',
                        boxShadow: noteColor === color.value ? `0 0 0 2px ${color.value}` : 'none',
                        transition: 'all 0.2s'
                      }} 
                    />
                  </Tooltip>
                ))}
              </Box>
            </Box>
          </Box>
        </DialogContent>
        <DialogActions sx={{ p: 3, gap: 1 }}>
          <Button 
            onClick={() => setOpen(false)} 
            sx={{ fontWeight: 700, borderRadius: 2 }}
          >
            Cerrar
          </Button>
          <Button 
            variant="contained" 
            onClick={handleSaveNote} 
            disabled={noteText.trim() === ''}
            startIcon={<Plus size={18} />}
            sx={{ borderRadius: 2, fontWeight: 700, px: 3, boxShadow: 'none' }}
          >
            Agregar Nota
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
