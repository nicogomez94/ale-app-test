import React, { useState, useEffect, useMemo } from 'react';
import { 
  Box, 
  Typography, 
  Card, 
  CardContent, 
  Button, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow, 
  Paper, 
  IconButton, 
  TextField, 
  InputAdornment,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  Chip,
  Autocomplete,
  MenuItem,
  Tabs,
  Tab,
  Tooltip,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Avatar,
  LinearProgress,
  Collapse,
  Badge
} from '@mui/material';
import { 
  Plus, 
  Search, 
  Edit2, 
  Trash2, 
  AlertTriangle, 
  Clock, 
  CheckCircle2, 
  FileText,
  Calendar,
  User,
  Shield,
  MessageCircle,
  Mail,
  Download,
  X,
  ChevronRight,
  History,
  DollarSign,
  FileUp,
  MapPin,
  Car,
  Home,
  Briefcase,
  Heart,
  Phone,
  MoreVertical,
  Filter,
  ArrowUpRight,
  ArrowDownRight,
  Activity,
  Eye,
  Send,
  Paperclip,
  CheckCircle,
  AlertCircle,
  Info
} from 'lucide-react';
import { format, parseISO, differenceInDays } from 'date-fns';
import * as XLSX from 'xlsx';
import { Claim, ClaimStatus, ClaimPriority, ClaimNote, ClaimDocument } from '../types';
import { CLAIM_STATUSES, CLAIM_PRIORITIES, CLAIM_TYPES, ASEGURADORAS } from '../constants';

const STATUS_COLORS: Record<ClaimStatus, string> = {
  'Denunciado': '#3b82f6', // Blue
  'En gestión': '#f59e0b', // Amber
  'En inspección': '#8b5cf6', // Purple
  'En análisis': '#6366f1', // Indigo
  'Aprobado': '#10b981', // Green
  'Rechazado': '#ef4444', // Red
  'Pagado': '#059669' // Dark Green
};

const PRIORITY_COLORS: Record<ClaimPriority, string> = {
  'Alta': '#ef4444',
  'Media': '#f59e0b',
  'Baja': '#3b82f6'
};

export const ClaimsPage: React.FC<{ policies: any[], clients: any[] }> = ({ policies, clients }) => {
  const [claims, setClaims] = useState<Claim[]>(() => {
    const saved = localStorage.getItem('pas_alert_claims_v2');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('Todos');
  const [priorityFilter, setPriorityFilter] = useState<string>('Todas');
  const [open, setOpen] = useState(false);
  const [viewOpen, setViewOpen] = useState(false);
  const [selectedClaim, setSelectedClaim] = useState<Claim | null>(null);
  const [editingClaim, setEditingClaim] = useState<Claim | null>(null);
  
  const [formValues, setFormValues] = useState<Partial<Claim>>({
    claimNumber: '',
    policyNumber: '',
    insuranceCompany: '',
    insuranceType: 'Automotor',
    clientName: '',
    clientDni: '',
    accidentDate: format(new Date(), 'yyyy-MM-dd'),
    accidentTime: format(new Date(), 'HH:mm'),
    location: '',
    description: '',
    dynamicFields: {},
    status: 'Denunciado',
    priority: 'Baja',
    denunciationDate: format(new Date(), 'yyyy-MM-dd'),
    lastContactCompany: '',
    lastContactClient: '',
    responsible: '',
    claimedAmount: 0,
    deductible: 0,
    approvedAmount: 0,
    paidAmount: 0,
    notes: [],
    documents: []
  });

  const [newNote, setNewNote] = useState('');

  useEffect(() => {
    localStorage.setItem('pas_alert_claims_v2', JSON.stringify(claims));
  }, [claims]);

  // Priority Logic
  const calculatePriority = (claim: Partial<Claim>): ClaimPriority => {
    const amount = claim.claimedAmount || 0;
    const daysSinceLastUpdate = claim.updatedAt ? differenceInDays(new Date(), (claim.updatedAt as any).toDate ? (claim.updatedAt as any).toDate() : new Date(claim.updatedAt as any)) : 0;
    
    if (amount > 500000 || daysSinceLastUpdate > 10) return 'Alta';
    if (amount > 100000 || daysSinceLastUpdate > 5) return 'Media';
    return 'Baja';
  };

  const handleOpen = (claim?: Claim) => {
    if (claim) {
      setEditingClaim(claim);
      setFormValues(claim);
    } else {
      setEditingClaim(null);
      setFormValues({
        claimNumber: '',
        policyNumber: '',
        insuranceCompany: '',
        insuranceType: 'Automotor',
        clientName: '',
        clientDni: '',
        accidentDate: format(new Date(), 'yyyy-MM-dd'),
        accidentTime: format(new Date(), 'HH:mm'),
        location: '',
        description: '',
        dynamicFields: {},
        status: 'Denunciado',
        priority: 'Baja',
        denunciationDate: format(new Date(), 'yyyy-MM-dd'),
        lastContactCompany: '',
        lastContactClient: '',
        responsible: '',
        claimedAmount: 0,
        deductible: 0,
        approvedAmount: 0,
        paidAmount: 0,
        notes: [],
        documents: []
      });
    }
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setEditingClaim(null);
  };

  const handleSave = () => {
    const priority = calculatePriority(formValues);
    const claimData: Claim = {
      ...(formValues as Claim),
      id: editingClaim?.id || Math.random().toString(36).substr(2, 9),
      priority,
      updatedAt: new Date() as any,
      createdAt: editingClaim?.createdAt || new Date() as any,
      userId: 'current-user'
    };

    if (editingClaim) {
      setClaims(claims.map(c => c.id === editingClaim.id ? claimData : c));
    } else {
      setClaims([claimData, ...claims]);
    }
    handleClose();
  };

  const handleDelete = (id: string) => {
    if (window.confirm('¿Estás seguro de eliminar este siniestro?')) {
      setClaims(claims.filter(c => c.id !== id));
    }
  };

  const handleAddNote = () => {
    if (!newNote.trim() || !selectedClaim) return;
    
    const note: ClaimNote = {
      id: Math.random().toString(36).substr(2, 9),
      date: new Date().toISOString(),
      text: newNote,
      author: 'Productor'
    };
    
    const updatedClaim = {
      ...selectedClaim,
      notes: [note, ...selectedClaim.notes],
      updatedAt: new Date() as any
    };
    
    setClaims(claims.map(c => c.id === selectedClaim.id ? updatedClaim : c));
    setSelectedClaim(updatedClaim);
    setNewNote('');
  };

  const handleAddDocument = () => {
    if (!selectedClaim) return;
    const newDoc: ClaimDocument = {
      id: Math.random().toString(36).substr(2, 9),
      name: `Documento_${selectedClaim.documents.length + 1}.pdf`,
      type: 'application/pdf',
      url: '#',
      uploadDate: new Date().toISOString()
    };
    const updatedClaim = {
      ...selectedClaim,
      documents: [...selectedClaim.documents, newDoc],
      updatedAt: new Date() as any
    };
    setClaims(claims.map(c => c.id === selectedClaim.id ? updatedClaim : c));
    setSelectedClaim(updatedClaim);
  };

  const handleContactClient = (claim: Claim, method: 'whatsapp' | 'mail') => {
    const client = clients.find(c => c.dni === claim.clientDni);
    if (!client) return;

    if (method === 'whatsapp') {
      const message = `Hola ${client.nombre}, te contacto por el siniestro ${claim.claimNumber} de tu póliza ${claim.policyNumber}. Estado actual: ${claim.status}.`;
      window.open(`https://wa.me/${client.telefono.replace(/\D/g, '')}?text=${encodeURIComponent(message)}`, '_blank');
    } else {
      const subject = `Seguimiento Siniestro ${claim.claimNumber}`;
      const body = `Hola ${client.nombre},\n\nTe contacto para informarte sobre el estado de tu siniestro ${claim.claimNumber}.\nEstado: ${claim.status}.\n\nSaludos.`;
      window.open(`mailto:${client.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`);
    }

    // Update last contact
    const updatedClaim = {
      ...claim,
      lastContactClient: new Date().toISOString(),
      updatedAt: new Date() as any
    };
    setClaims(claims.map(c => c.id === claim.id ? updatedClaim : c));
    if (selectedClaim?.id === claim.id) setSelectedClaim(updatedClaim);
  };
  const handleExport = () => {
    const ws = XLSX.utils.json_to_sheet(claims.map(c => ({
      'N° Siniestro': c.claimNumber,
      'Póliza': c.policyNumber,
      'Aseguradora': c.insuranceCompany,
      'Tipo': c.insuranceType,
      'Cliente': c.clientName,
      'Fecha Siniestro': c.accidentDate,
      'Estado': c.status,
      'Prioridad': c.priority,
      'Monto Reclamado': c.claimedAmount,
      'Monto Pagado': c.paidAmount
    })));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Siniestros");
    XLSX.writeFile(wb, "Gestion_Siniestros_PAS.xlsx");
  };

  const getClaimAlerts = (claim: Claim) => {
    const alerts = [];
    const daysWithoutMovement = differenceInDays(new Date(), (claim.updatedAt as any).toDate ? (claim.updatedAt as any).toDate() : new Date(claim.updatedAt as any));
    const daysSinceSiniestro = differenceInDays(new Date(), parseISO(claim.accidentDate));

    if (daysWithoutMovement > 7 && !['Pagado', 'Rechazado'].includes(claim.status)) {
      alerts.push({ type: 'warning', text: 'Sin movimiento por más de 7 días' });
    }
    if (claim.documents.length === 0 && !['Pagado', 'Rechazado'].includes(claim.status)) {
      alerts.push({ type: 'error', text: 'Falta documentación' });
    }
    if (claim.status === 'Aprobado' && claim.paidAmount === 0) {
      alerts.push({ type: 'info', text: 'Próximo a resolución / Pago pendiente' });
    }
    if (daysSinceSiniestro > 15 && claim.status === 'Denunciado') {
      alerts.push({ type: 'warning', text: 'Demora en la aseguradora' });
    }
    return alerts;
  };

  const filteredClaims = useMemo(() => {
    return claims.filter(c => {
      const matchesSearch = 
        c.clientName.toLowerCase().includes(searchTerm.toLowerCase()) || 
        c.claimNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.policyNumber.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesStatus = statusFilter === 'Todos' || c.status === statusFilter;
      const matchesPriority = priorityFilter === 'Todas' || c.priority === priorityFilter;
      
      return matchesSearch && matchesStatus && matchesPriority;
    }).sort((a, b) => {
      const pMap = { 'Alta': 0, 'Media': 1, 'Baja': 2 };
      return pMap[a.priority] - pMap[b.priority];
    });
  }, [claims, searchTerm, statusFilter, priorityFilter]);

  // Dashboard Stats
  const stats = useMemo(() => {
    const active = claims.filter(c => !['Pagado', 'Rechazado'].includes(c.status)).length;
    const inManagement = claims.filter(c => c.status === 'En gestión').length;
    const approved = claims.filter(c => c.status === 'Aprobado').length;
    const critical = claims.filter(c => c.priority === 'Alta' && !['Pagado', 'Rechazado'].includes(c.status)).length;
    
    // Average resolution time (simulated)
    const resolved = claims.filter(c => c.status === 'Pagado');
    const avgTime = resolved.length > 0 
      ? Math.round(resolved.reduce((acc, c) => acc + differenceInDays(new Date(c.updatedAt as any), new Date(c.createdAt as any)), 0) / resolved.length)
      : 0;

    return { active, inManagement, approved, critical, avgTime };
  }, [claims]);

  const getInsuranceIcon = (type: string) => {
    switch (type) {
      case 'Automotor': return <Car size={20} />;
      case 'Hogar': return <Home size={20} />;
      case 'Comercio': return <Briefcase size={20} />;
      case 'ART': return <Shield size={20} />;
      case 'Vida': return <Heart size={20} />;
      default: return <FileText size={20} />;
    }
  };

  const renderDynamicFields = () => {
    switch (formValues.insuranceType) {
      case 'Automotor':
        return (
          <>
            <Grid size={{ xs: 12, sm: 4 }}>
              <TextField
                fullWidth
                label="Dominio / Patente"
                value={formValues.dynamicFields?.dominio || ''}
                onChange={(e) => setFormValues({ 
                  ...formValues, 
                  dynamicFields: { ...formValues.dynamicFields, dominio: e.target.value } 
                })}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 8 }}>
              <TextField
                fullWidth
                label="Terceros Involucrados"
                value={formValues.dynamicFields?.terceros || ''}
                onChange={(e) => setFormValues({ 
                  ...formValues, 
                  dynamicFields: { ...formValues.dynamicFields, terceros: e.target.value } 
                })}
                placeholder="Nombre, DNI, Seguro del tercero..."
              />
            </Grid>
          </>
        );
      case 'ART':
        return (
          <>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="Empleado Afectado"
                value={formValues.dynamicFields?.empleado || ''}
                onChange={(e) => setFormValues({ 
                  ...formValues, 
                  dynamicFields: { ...formValues.dynamicFields, empleado: e.target.value } 
                })}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="Tipo de Accidente"
                value={formValues.dynamicFields?.tipoAccidente || ''}
                onChange={(e) => setFormValues({ 
                  ...formValues, 
                  dynamicFields: { ...formValues.dynamicFields, tipoAccidente: e.target.value } 
                })}
                placeholder="In itinere, En planta, etc."
              />
            </Grid>
          </>
        );
      case 'Hogar':
      case 'Comercio':
        return (
          <>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="Tipo de Daño"
                value={formValues.dynamicFields?.tipoDano || ''}
                onChange={(e) => setFormValues({ 
                  ...formValues, 
                  dynamicFields: { ...formValues.dynamicFields, tipoDano: e.target.value } 
                })}
                placeholder="Incendio, Robo, Agua..."
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="Bienes Afectados"
                value={formValues.dynamicFields?.bienes || ''}
                onChange={(e) => setFormValues({ 
                  ...formValues, 
                  dynamicFields: { ...formValues.dynamicFields, bienes: e.target.value } 
                })}
              />
            </Grid>
          </>
        );
      default:
        return null;
    }
  };

  return (
    <Box sx={{ p: { xs: 2, md: 4 }, maxWidth: '1600px', mx: 'auto' }}>
      {/* Header */}
      <Box sx={{ mb: 4, display: 'flex', flexDirection: { xs: 'column', sm: 'row' }, justifyContent: 'space-between', alignItems: { xs: 'flex-start', sm: 'center' }, gap: 2 }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 900, color: '#1e293b', letterSpacing: '-0.02em' }}>
            Centro de Siniestros
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Gestión inteligente, seguimiento activo y control de tiempos.
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <Button 
            variant="outlined" 
            startIcon={<Download size={18} />}
            onClick={handleExport}
            sx={{ borderRadius: '12px', textTransform: 'none', fontWeight: 600 }}
          >
            Exportar
          </Button>
          <Button 
            variant="contained" 
            startIcon={<Plus size={18} />}
            onClick={() => handleOpen()}
            sx={{ 
              borderRadius: '12px', 
              textTransform: 'none', 
              fontWeight: 600,
              bgcolor: '#ef4444',
              '&:hover': { bgcolor: '#dc2626' },
              boxShadow: '0 4px 14px 0 rgba(239, 68, 68, 0.39)'
            }}
          >
            Nuevo Siniestro
          </Button>
        </Box>
      </Box>

      {/* Dashboard Stats */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        {[
          { label: 'Siniestros Activos', value: stats.active, icon: <Activity size={24} />, color: '#3b82f6' },
          { label: 'En Gestión', value: stats.inManagement, icon: <Clock size={24} />, color: '#f59e0b' },
          { label: 'Siniestros Críticos', value: stats.critical, icon: <AlertTriangle size={24} />, color: '#ef4444' },
          { label: 'Tiempo Promedio', value: `${stats.avgTime} días`, icon: <History size={24} />, color: '#8b5cf6' }
        ].map((stat, idx) => (
          <Grid key={idx} size={{ xs: 12, sm: 6, md: 3 }}>
            <Card sx={{ borderRadius: '20px', border: '1px solid #e2e8f0', boxShadow: 'none' }}>
              <CardContent sx={{ p: 3 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                  <Box sx={{ p: 1.5, borderRadius: '12px', bgcolor: `${stat.color}15`, color: stat.color }}>
                    {stat.icon}
                  </Box>
                </Box>
                <Typography variant="h4" sx={{ fontWeight: 800, mb: 0.5 }}>{stat.value}</Typography>
                <Typography variant="body2" color="text.secondary" sx={{ fontWeight: 500 }}>{stat.label}</Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Filters & Table */}
      <Card sx={{ borderRadius: '24px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)', overflow: 'hidden' }}>
        <Box sx={{ p: 3, borderBottom: '1px solid #e2e8f0', display: 'flex', flexDirection: { xs: 'column', md: 'row' }, gap: 2, alignItems: 'center' }}>
          <TextField
            placeholder="Buscar por cliente, siniestro o póliza..."
            size="small"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            sx={{ flexGrow: 1, '& .MuiOutlinedInput-root': { borderRadius: '12px' } }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search size={18} color="#64748b" />
                </InputAdornment>
              ),
            }}
          />
          <Box sx={{ display: 'flex', gap: 2, width: { xs: '100%', md: 'auto' } }}>
            <TextField
              select
              size="small"
              label="Estado"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              sx={{ minWidth: 150, '& .MuiOutlinedInput-root': { borderRadius: '12px' } }}
            >
              <MenuItem value="Todos">Todos los Estados</MenuItem>
              {CLAIM_STATUSES.map(s => <MenuItem key={s} value={s}>{s}</MenuItem>)}
            </TextField>
            <TextField
              select
              size="small"
              label="Prioridad"
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              sx={{ minWidth: 150, '& .MuiOutlinedInput-root': { borderRadius: '12px' } }}
            >
              <MenuItem value="Todas">Todas las Prioridades</MenuItem>
              {CLAIM_PRIORITIES.map(p => <MenuItem key={p} value={p}>{p}</MenuItem>)}
            </TextField>
          </Box>
        </Box>

        <TableContainer>
          <Table>
            <TableHead sx={{ bgcolor: '#f8fafc' }}>
              <TableRow>
                <TableCell sx={{ fontWeight: 700, color: '#475569' }}>Siniestro / Cliente</TableCell>
                <TableCell sx={{ fontWeight: 700, color: '#475569' }}>Tipo / Prioridad</TableCell>
                <TableCell sx={{ fontWeight: 700, color: '#475569' }}>Estado</TableCell>
                <TableCell sx={{ fontWeight: 700, color: '#475569' }}>Tiempos</TableCell>
                <TableCell sx={{ fontWeight: 700, color: '#475569' }}>Económico</TableCell>
                <TableCell sx={{ fontWeight: 700, color: '#475569', textAlign: 'right' }}>Acciones</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredClaims.map((claim) => {
                const daysSinceSiniestro = differenceInDays(new Date(), parseISO(claim.accidentDate));
                const daysSinceDenuncia = differenceInDays(new Date(), parseISO(claim.denunciationDate));
                const daysWithoutMovement = differenceInDays(new Date(), (claim.updatedAt as any).toDate ? (claim.updatedAt as any).toDate() : new Date(claim.updatedAt as any));

                return (
                  <TableRow key={claim.id} hover sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                    <TableCell>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                        <Avatar sx={{ bgcolor: '#f1f5f9', color: '#1e293b', width: 40, height: 40 }}>
                          {getInsuranceIcon(claim.insuranceType)}
                        </Avatar>
                        <Box>
                          <Typography variant="body2" sx={{ fontWeight: 700, color: '#1e293b' }}>
                            {claim.claimNumber || 'S/N'}
                          </Typography>
                          <Typography variant="caption" sx={{ color: '#64748b', display: 'block' }}>
                            {claim.clientName}
                          </Typography>
                          <Typography variant="caption" sx={{ color: '#94a3b8' }}>
                            Póliza: {claim.policyNumber}
                          </Typography>
                        </Box>
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>{claim.insuranceType}</Typography>
                        <Chip 
                          label={claim.priority} 
                          size="small" 
                          sx={{ 
                            bgcolor: `${PRIORITY_COLORS[claim.priority]}15`, 
                            color: PRIORITY_COLORS[claim.priority],
                            fontWeight: 700,
                            fontSize: '0.65rem',
                            height: 20
                          }} 
                        />
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Chip 
                        label={claim.status} 
                        size="small" 
                        sx={{ 
                          bgcolor: `${STATUS_COLORS[claim.status]}15`, 
                          color: STATUS_COLORS[claim.status],
                          fontWeight: 700,
                          borderRadius: '8px'
                        }} 
                      />
                    </TableCell>
                    <TableCell>
                      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
                        <Tooltip title="Días desde el siniestro">
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                            <AlertCircle size={12} color={daysSinceSiniestro > 30 ? '#ef4444' : '#64748b'} />
                            <Typography variant="caption" sx={{ color: '#64748b' }}>{daysSinceSiniestro}d desde hecho</Typography>
                          </Box>
                        </Tooltip>
                        <Tooltip title="Días sin movimiento">
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                            <Clock size={12} color={daysWithoutMovement > 5 ? '#f59e0b' : '#64748b'} />
                            <Typography variant="caption" sx={{ color: '#64748b' }}>{daysWithoutMovement}d sin mov.</Typography>
                          </Box>
                        </Tooltip>
                        {getClaimAlerts(claim).map((alert, idx) => (
                          <Box key={idx} sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                            <Info size={10} color={alert.type === 'error' ? '#ef4444' : alert.type === 'warning' ? '#f59e0b' : '#3b82f6'} />
                            <Typography variant="caption" sx={{ color: alert.type === 'error' ? '#ef4444' : alert.type === 'warning' ? '#f59e0b' : '#3b82f6', fontSize: '0.6rem', fontWeight: 600 }}>
                              {alert.text}
                            </Typography>
                          </Box>
                        ))}
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Box>
                        <Typography variant="body2" sx={{ fontWeight: 700, color: '#059669' }}>
                          ${claim.paidAmount.toLocaleString()}
                        </Typography>
                        <Typography variant="caption" sx={{ color: '#64748b' }}>
                          de ${claim.claimedAmount.toLocaleString()}
                        </Typography>
                      </Box>
                    </TableCell>
                    <TableCell sx={{ textAlign: 'right' }}>
                      <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1 }}>
                        <Tooltip title="Contactar WhatsApp">
                          <IconButton 
                            size="small" 
                            onClick={() => handleContactClient(claim, 'whatsapp')}
                            sx={{ color: '#25d366', bgcolor: '#25d36610' }}
                          >
                            <MessageCircle size={18} />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Ver Detalle / CRM">
                          <IconButton 
                            size="small" 
                            onClick={() => {
                              setSelectedClaim(claim);
                              setViewOpen(true);
                            }}
                            sx={{ color: '#6366f1', bgcolor: '#6366f110' }}
                          >
                            <Eye size={18} />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Editar">
                          <IconButton size="small" onClick={() => handleOpen(claim)} sx={{ color: '#3b82f6', bgcolor: '#3b82f610' }}>
                            <Edit2 size={18} />
                          </IconButton>
                        </Tooltip>
                        <IconButton size="small" onClick={() => handleDelete(claim.id!)} sx={{ color: '#ef4444', bgcolor: '#ef444410' }}>
                          <Trash2 size={18} />
                        </IconButton>
                      </Box>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
      </Card>

      {/* Form Dialog */}
      <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth PaperProps={{ sx: { borderRadius: '24px' } }}>
        <DialogTitle sx={{ fontWeight: 900, px: 4, pt: 4 }}>
          {editingClaim ? 'Editar Siniestro' : 'Registrar Nuevo Siniestro'}
        </DialogTitle>
        <DialogContent sx={{ px: 4 }}>
          <Grid container spacing={3} sx={{ mt: 1 }}>
            {/* Basic Info */}
            <Grid size={{ xs: 12 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 800, color: '#64748b', mb: 1, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Información General
              </Typography>
              <Divider />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Autocomplete
                options={clients}
                getOptionLabel={(option) => `${option.nombre} (${option.dni})`}
                value={clients.find(c => c.dni === formValues.clientDni) || null}
                onChange={(_, newValue) => {
                  setFormValues({ 
                    ...formValues, 
                    clientName: newValue?.nombre || '', 
                    clientDni: newValue?.dni || '',
                    policyNumber: '' // Reset policy when client changes
                  });
                }}
                renderInput={(params) => <TextField {...params} label="Cliente" required />}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Autocomplete
                options={policies.filter(p => p.clienteDni === formValues.clientDni)}
                getOptionLabel={(option) => `${option.numeroPoliza} - ${option.aseguradora}`}
                value={policies.find(p => p.numeroPoliza === formValues.policyNumber) || null}
                onChange={(_, newValue) => {
                  setFormValues({ 
                    ...formValues, 
                    policyNumber: newValue?.numeroPoliza || '',
                    insuranceCompany: newValue?.aseguradora || '',
                    insuranceType: newValue?.rubro?.includes('Auto') ? 'Automotor' : 
                                  newValue?.rubro?.includes('Hogar') ? 'Hogar' : 
                                  newValue?.rubro?.includes('ART') ? 'ART' : 'Otros'
                  });
                }}
                disabled={!formValues.clientDni}
                renderInput={(params) => <TextField {...params} label="Póliza" required />}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 4 }}>
              <TextField
                fullWidth
                label="N° Siniestro Compañía"
                value={formValues.claimNumber}
                onChange={(e) => setFormValues({ ...formValues, claimNumber: e.target.value })}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 4 }}>
              <TextField
                fullWidth
                select
                label="Tipo de Seguro"
                value={formValues.insuranceType}
                onChange={(e) => setFormValues({ ...formValues, insuranceType: e.target.value })}
              >
                {CLAIM_TYPES.map(t => <MenuItem key={t} value={t}>{t}</MenuItem>)}
              </TextField>
            </Grid>
            <Grid size={{ xs: 12, sm: 4 }}>
              <TextField
                fullWidth
                select
                label="Estado"
                value={formValues.status}
                onChange={(e) => setFormValues({ ...formValues, status: e.target.value as ClaimStatus })}
              >
                {CLAIM_STATUSES.map(s => <MenuItem key={s} value={s}>{s}</MenuItem>)}
              </TextField>
            </Grid>

            {/* Incident Details */}
            <Grid size={{ xs: 12 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 800, color: '#64748b', mb: 1, textTransform: 'uppercase', letterSpacing: '0.05em', mt: 2 }}>
                Detalles del Siniestro
              </Typography>
              <Divider />
            </Grid>
            <Grid size={{ xs: 12, sm: 4 }}>
              <TextField
                fullWidth
                type="date"
                label="Fecha del Hecho"
                value={formValues.accidentDate}
                onChange={(e) => setFormValues({ ...formValues, accidentDate: e.target.value })}
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 4 }}>
              <TextField
                fullWidth
                type="time"
                label="Hora del Hecho"
                value={formValues.accidentTime}
                onChange={(e) => setFormValues({ ...formValues, accidentTime: e.target.value })}
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 4 }}>
              <TextField
                fullWidth
                type="date"
                label="Fecha Denuncia"
                value={formValues.denunciationDate}
                onChange={(e) => setFormValues({ ...formValues, denunciationDate: e.target.value })}
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField
                fullWidth
                label="Lugar del Siniestro"
                value={formValues.location}
                onChange={(e) => setFormValues({ ...formValues, location: e.target.value })}
                InputProps={{ startAdornment: <MapPin size={18} style={{ marginRight: 8, color: '#64748b' }} /> }}
              />
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField
                fullWidth
                multiline
                rows={3}
                label="Descripción Detallada"
                value={formValues.description}
                onChange={(e) => setFormValues({ ...formValues, description: e.target.value })}
              />
            </Grid>

            {/* Dynamic Fields */}
            {renderDynamicFields()}

            {/* Economic Info */}
            <Grid size={{ xs: 12 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 800, color: '#64748b', mb: 1, textTransform: 'uppercase', letterSpacing: '0.05em', mt: 2 }}>
                Información Económica
              </Typography>
              <Divider />
            </Grid>
            <Grid size={{ xs: 12, sm: 3 }}>
              <TextField
                fullWidth
                type="number"
                label="Monto Reclamado"
                value={formValues.claimedAmount}
                onChange={(e) => setFormValues({ ...formValues, claimedAmount: Number(e.target.value) })}
                InputProps={{ startAdornment: <DollarSign size={18} /> }}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 3 }}>
              <TextField
                fullWidth
                type="number"
                label="Franquicia"
                value={formValues.deductible}
                onChange={(e) => setFormValues({ ...formValues, deductible: Number(e.target.value) })}
                InputProps={{ startAdornment: <DollarSign size={18} /> }}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 3 }}>
              <TextField
                fullWidth
                type="number"
                label="Monto Aprobado"
                value={formValues.approvedAmount}
                onChange={(e) => setFormValues({ ...formValues, approvedAmount: Number(e.target.value) })}
                InputProps={{ startAdornment: <DollarSign size={18} /> }}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 3 }}>
              <TextField
                fullWidth
                type="number"
                label="Monto Pagado"
                value={formValues.paidAmount}
                onChange={(e) => setFormValues({ ...formValues, paidAmount: Number(e.target.value) })}
                InputProps={{ startAdornment: <DollarSign size={18} /> }}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 4 }}>
              <TextField
                fullWidth
                label="Responsable Asignado"
                value={formValues.responsible}
                onChange={(e) => setFormValues({ ...formValues, responsible: e.target.value })}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 4 }}>
              <TextField
                fullWidth
                type="date"
                label="Último Contacto Cía"
                value={formValues.lastContactCompany ? format(parseISO(formValues.lastContactCompany), 'yyyy-MM-dd') : ''}
                onChange={(e) => setFormValues({ ...formValues, lastContactCompany: e.target.value })}
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 4 }}>
              <TextField
                fullWidth
                type="date"
                label="Último Contacto Cliente"
                value={formValues.lastContactClient ? format(parseISO(formValues.lastContactClient), 'yyyy-MM-dd') : ''}
                onChange={(e) => setFormValues({ ...formValues, lastContactClient: e.target.value })}
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ p: 4 }}>
          <Button onClick={handleClose} sx={{ fontWeight: 600 }}>Cancelar</Button>
          <Button 
            variant="contained" 
            onClick={handleSave}
            sx={{ 
              borderRadius: '12px', 
              px: 4, 
              fontWeight: 700,
              bgcolor: '#1e293b',
              '&:hover': { bgcolor: '#0f172a' }
            }}
          >
            {editingClaim ? 'Guardar Cambios' : 'Registrar Siniestro'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* CRM View Dialog */}
      <Dialog 
        open={viewOpen} 
        onClose={() => setViewOpen(false)} 
        maxWidth="lg" 
        fullWidth 
        PaperProps={{ sx: { borderRadius: '24px', minHeight: '80vh' } }}
      >
        {selectedClaim && (
          <>
            <DialogTitle sx={{ p: 0 }}>
              <Box sx={{ p: 4, bgcolor: '#f8fafc', borderBottom: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <Box sx={{ display: 'flex', gap: 3 }}>
                  <Avatar sx={{ width: 64, height: 64, bgcolor: `${STATUS_COLORS[selectedClaim.status]}20`, color: STATUS_COLORS[selectedClaim.status] }}>
                    {getInsuranceIcon(selectedClaim.insuranceType)}
                  </Avatar>
                  <Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 0.5 }}>
                      <Typography variant="h5" sx={{ fontWeight: 900 }}>Siniestro {selectedClaim.claimNumber || 'S/N'}</Typography>
                      <Chip 
                        label={selectedClaim.status} 
                        size="small" 
                        sx={{ bgcolor: `${STATUS_COLORS[selectedClaim.status]}20`, color: STATUS_COLORS[selectedClaim.status], fontWeight: 800 }} 
                      />
                    </Box>
                    <Typography variant="body1" color="text.secondary" sx={{ fontWeight: 500 }}>
                      {selectedClaim.clientName} • Póliza {selectedClaim.policyNumber}
                    </Typography>
                    <Box sx={{ mt: 1, display: 'flex', gap: 1 }}>
                      <Button 
                        size="small" 
                        variant="outlined" 
                        startIcon={<MessageCircle size={16} />} 
                        onClick={() => handleContactClient(selectedClaim, 'whatsapp')}
                        sx={{ borderRadius: '8px', color: '#25d366', borderColor: '#25d366' }}
                      >
                        WhatsApp
                      </Button>
                      <Button 
                        size="small" 
                        variant="outlined" 
                        startIcon={<Mail size={16} />} 
                        onClick={() => handleContactClient(selectedClaim, 'mail')}
                        sx={{ borderRadius: '8px' }}
                      >
                        Email
                      </Button>
                    </Box>
                  </Box>
                </Box>
                <IconButton onClick={() => setViewOpen(false)}>
                  <X size={24} />
                </IconButton>
              </Box>
            </DialogTitle>
            <DialogContent sx={{ p: 0 }}>
              <Grid container sx={{ height: '100%' }}>
                {/* Left Column: Details */}
                <Grid size={{ xs: 12, md: 8 }} sx={{ p: 4, borderRight: '1px solid #e2e8f0' }}>
                  <Box sx={{ mb: 4 }}>
                    <Typography variant="subtitle2" sx={{ fontWeight: 800, color: '#64748b', mb: 2, textTransform: 'uppercase' }}>Detalles del Hecho</Typography>
                    <Grid container spacing={3}>
                      <Grid size={{ xs: 6, sm: 3 }}>
                        <Typography variant="caption" color="text.secondary">Fecha y Hora</Typography>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>{format(parseISO(selectedClaim.accidentDate), 'dd/MM/yyyy')} {selectedClaim.accidentTime}</Typography>
                      </Grid>
                      <Grid size={{ xs: 6, sm: 3 }}>
                        <Typography variant="caption" color="text.secondary">Lugar</Typography>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>{selectedClaim.location || 'No especificado'}</Typography>
                      </Grid>
                      <Grid size={{ xs: 6, sm: 3 }}>
                        <Typography variant="caption" color="text.secondary">Aseguradora</Typography>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>{selectedClaim.insuranceCompany}</Typography>
                      </Grid>
                      <Grid size={{ xs: 6, sm: 3 }}>
                        <Typography variant="caption" color="text.secondary">Prioridad</Typography>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: PRIORITY_COLORS[selectedClaim.priority] }} />
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>{selectedClaim.priority}</Typography>
                        </Box>
                      </Grid>
                      <Grid size={{ xs: 6, sm: 3 }}>
                        <Typography variant="caption" color="text.secondary">Responsable</Typography>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>{selectedClaim.responsible || 'No asignado'}</Typography>
                      </Grid>
                      <Grid size={{ xs: 6, sm: 3 }}>
                        <Typography variant="caption" color="text.secondary">Últ. Contacto Cía</Typography>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>{selectedClaim.lastContactCompany ? format(parseISO(selectedClaim.lastContactCompany), 'dd/MM/yyyy') : 'Nunca'}</Typography>
                      </Grid>
                      <Grid size={{ xs: 6, sm: 3 }}>
                        <Typography variant="caption" color="text.secondary">Últ. Contacto Cliente</Typography>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>{selectedClaim.lastContactClient ? format(parseISO(selectedClaim.lastContactClient), 'dd/MM/yyyy') : 'Nunca'}</Typography>
                      </Grid>
                      {Object.keys(selectedClaim.dynamicFields).length > 0 && (
                        <Grid size={{ xs: 12 }}>
                          <Box sx={{ p: 2, bgcolor: '#f8fafc', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
                            <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 700, textTransform: 'uppercase', mb: 1, display: 'block' }}>Campos Específicos</Typography>
                            <Grid container spacing={2}>
                              {Object.entries(selectedClaim.dynamicFields).map(([key, value]) => (
                                <Grid key={key} size={{ xs: 6, sm: 4 }}>
                                  <Typography variant="caption" color="text.secondary" sx={{ textTransform: 'capitalize' }}>{key.replace(/([A-Z])/g, ' $1')}</Typography>
                                  <Typography variant="body2" sx={{ fontWeight: 600 }}>{value}</Typography>
                                </Grid>
                              ))}
                            </Grid>
                          </Box>
                        </Grid>
                      )}
                      <Grid size={{ xs: 12 }}>
                        <Typography variant="caption" color="text.secondary">Descripción</Typography>
                        <Typography variant="body2" sx={{ bgcolor: '#f1f5f9', p: 2, borderRadius: '12px', mt: 1 }}>
                          {selectedClaim.description || 'Sin descripción.'}
                        </Typography>
                      </Grid>
                    </Grid>
                  </Box>

                  <Box sx={{ mb: 4 }}>
                    <Typography variant="subtitle2" sx={{ fontWeight: 800, color: '#64748b', mb: 2, textTransform: 'uppercase' }}>Información Económica</Typography>
                    <Grid container spacing={2}>
                      {[
                        { label: 'Reclamado', value: selectedClaim.claimedAmount, color: '#3b82f6' },
                        { label: 'Franquicia', value: selectedClaim.deductible, color: '#64748b' },
                        { label: 'Aprobado', value: selectedClaim.approvedAmount, color: '#8b5cf6' },
                        { label: 'Pagado', value: selectedClaim.paidAmount, color: '#10b981' }
                      ].map((item, idx) => (
                        <Grid key={idx} size={{ xs: 6, sm: 3 }}>
                          <Box sx={{ p: 2, borderRadius: '16px', border: '1px solid #e2e8f0', textAlign: 'center' }}>
                            <Typography variant="caption" color="text.secondary" display="block">{item.label}</Typography>
                            <Typography variant="h6" sx={{ fontWeight: 800, color: item.color }}>${item.value.toLocaleString()}</Typography>
                          </Box>
                        </Grid>
                      ))}
                    </Grid>
                  </Box>

                  <Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                      <Typography variant="subtitle2" sx={{ fontWeight: 800, color: '#64748b', textTransform: 'uppercase' }}>Documentación</Typography>
                      <Button 
                        size="small" 
                        startIcon={<FileUp size={16} />} 
                        sx={{ textTransform: 'none' }}
                        onClick={handleAddDocument}
                      >
                        Subir Archivo
                      </Button>
                    </Box>
                    <Grid container spacing={2}>
                      {selectedClaim.documents.length > 0 ? (
                        selectedClaim.documents.map((doc, idx) => (
                          <Grid key={idx} size={{ xs: 12, sm: 4 }}>
                            <Paper sx={{ p: 2, borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: 'none', display: 'flex', alignItems: 'center', gap: 2 }}>
                              <FileText size={24} color="#6366f1" />
                              <Box sx={{ overflow: 'hidden' }}>
                                <Typography variant="body2" noWrap sx={{ fontWeight: 600 }}>{doc.name}</Typography>
                                <Typography variant="caption" color="text.secondary">{format(parseISO(doc.uploadDate), 'dd/MM/yyyy')}</Typography>
                              </Box>
                            </Paper>
                          </Grid>
                        ))
                      ) : (
                        <Grid size={{ xs: 12 }}>
                          <Typography variant="body2" color="text.secondary" sx={{ fontStyle: 'italic' }}>No hay documentos adjuntos.</Typography>
                        </Grid>
                      )}
                    </Grid>
                  </Box>
                </Grid>

                {/* Right Column: Timeline & Notes */}
                <Grid size={{ xs: 12, md: 4 }} sx={{ p: 4, bgcolor: '#f8fafc' }}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 800, color: '#64748b', mb: 3, textTransform: 'uppercase' }}>Historial y Notas</Typography>
                  
                  <Box sx={{ mb: 3 }}>
                    <TextField
                      fullWidth
                      placeholder="Escribe una nota interna..."
                      multiline
                      rows={2}
                      value={newNote}
                      onChange={(e) => setNewNote(e.target.value)}
                      sx={{ '& .MuiOutlinedInput-root': { borderRadius: '12px', bgcolor: 'white' } }}
                    />
                    <Button 
                      fullWidth 
                      variant="contained" 
                      onClick={handleAddNote}
                      sx={{ mt: 1, borderRadius: '12px', textTransform: 'none', fontWeight: 700, bgcolor: '#1e293b' }}
                    >
                      Agregar Nota
                    </Button>
                  </Box>

                  <Box sx={{ maxHeight: '400px', overflowY: 'auto' }}>
                    <List sx={{ p: 0 }}>
                      {selectedClaim.notes.map((note) => (
                        <ListItem key={note.id} sx={{ px: 0, alignItems: 'flex-start', mb: 2 }}>
                          <ListItemIcon sx={{ minWidth: 40, mt: 0.5 }}>
                            <Avatar sx={{ width: 32, height: 32, fontSize: '0.8rem', bgcolor: '#e2e8f0', color: '#475569' }}>
                              {note.author[0]}
                            </Avatar>
                          </ListItemIcon>
                          <ListItemText
                            primary={
                              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                                <Typography variant="caption" sx={{ fontWeight: 800 }}>{note.author}</Typography>
                                <Typography variant="caption" color="text.secondary">{format(new Date(note.date), 'dd/MM HH:mm')}</Typography>
                              </Box>
                            }
                            secondary={
                              <Typography variant="body2" sx={{ color: '#1e293b', lineHeight: 1.4 }}>
                                {note.text}
                              </Typography>
                            }
                          />
                        </ListItem>
                      ))}
                      <ListItem sx={{ px: 0, alignItems: 'flex-start' }}>
                        <ListItemIcon sx={{ minWidth: 40, mt: 0.5 }}>
                          <Box sx={{ p: 1, borderRadius: '50%', bgcolor: '#10b98120', color: '#10b981' }}>
                            <CheckCircle size={16} />
                          </Box>
                        </ListItemIcon>
                        <ListItemText
                          primary={<Typography variant="caption" sx={{ fontWeight: 800 }}>Siniestro Denunciado</Typography>}
                          secondary={<Typography variant="caption" color="text.secondary">{format(parseISO(selectedClaim.denunciationDate), 'dd/MM/yyyy')}</Typography>}
                        />
                      </ListItem>
                    </List>
                  </Box>
                </Grid>
              </Grid>
            </DialogContent>
          </>
        )}
      </Dialog>
    </Box>
  );
};
