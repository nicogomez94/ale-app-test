import React, { useState } from 'react';
import { 
  Box, 
  Typography, 
  Card, 
  CardContent, 
  Button, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow, 
  Paper, 
  IconButton, 
  TextField, 
  InputAdornment,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  Collapse,
  Tooltip,
  Chip,
  Autocomplete
} from '@mui/material';
import { 
  Plus, 
  Search, 
  Edit2, 
  Trash2, 
  UserPlus, 
  Download,
  Phone,
  Mail,
  MessageCircle,
  Building2,
  User,
  ChevronDown,
  ChevronUp,
  CheckSquare,
  Square,
  AlertCircle,
  Clock,
  FileCheck,
  X
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { useNavigate } from 'react-router-dom';
import { Menu, MenuItem } from '@mui/material';
import { PROVINCIAS_ARGENTINA, TODAS_LAS_ASEGURADORAS } from '../constants';
import { format, differenceInDays, parseISO, isBefore, isAfter, addDays } from 'date-fns';

export const ClientsPage: React.FC<{ 
  clients: any[], 
  setClients: React.Dispatch<React.SetStateAction<any[]>>, 
  policies: any[],
  onTogglePaid: (id: string) => void,
  onDeletePolicy: (id: string) => void,
  onUpdatePolicy: (policy: any) => void,
  user: any
}> = ({ clients, setClients, policies, onTogglePaid, onDeletePolicy, onUpdatePolicy, user }) => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [provinceFilter, setProvinceFilter] = useState('');
  const [localityFilter, setLocalityFilter] = useState('');
  const [open, setOpen] = useState(false);
  const [expandedClient, setExpandedClient] = useState<string | null>(null);
  const [editingClient, setEditingClient] = useState<any>(null);
  const [editingPolicy, setEditingPolicy] = useState<any>(null);
  const [editPolicyOpen, setEditPolicyOpen] = useState(false);
  const [policyFormValues, setPolicyFormValues] = useState({
    cliente: '',
    cuit: '',
    telefono: '',
    rubro: '',
    fechaInicio: '',
    vencimiento: '',
    poliza: '',
    aseguradora: '',
    medioPago: '',
    aporteMensual: '',
    fondoAcumulado: '',
    prima: '',
    comisionPorcentaje: '',
    pagada: false,
    calle: '',
    numero: '',
    cp: '',
    provincia: '',
    localidad: ''
  });
  const [manualVencimiento, setManualVencimiento] = useState(false);

  const formatWithDots = (val: string) => {
    const clean = val.replace(/\D/g, '');
    if (!clean) return '';
    const stripped = clean.replace(/^0+(?!$)/, '');
    return stripped.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  };

  const unformat = (val: string) => {
    if (typeof val !== 'string') return val;
    return val.replace(/\./g, '');
  };

  const formatDNIorCUIT = (value: string) => {
    const digits = value.replace(/\D/g, '');
    if (digits.length <= 8) {
      return digits.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    }
    if (digits.length <= 10) return `${digits.slice(0, 2)}-${digits.slice(2)}`;
    return `${digits.slice(0, 2)}-${digits.slice(2, 10)}-${digits.slice(10)}`;
  };

  const handlePolicyEdit = (policy: any) => {
    setEditingPolicy(policy);
    setManualVencimiento(false);
    
    const client = clients.find(c => c.nombre === policy.cliente);
    
    setPolicyFormValues({
      cliente: policy.cliente || '',
      cuit: policy.cuit || '',
      telefono: policy.telefono || '',
      rubro: policy.rubro || '',
      fechaInicio: policy.fechaInicio || '',
      vencimiento: policy.vencimiento || '',
      poliza: policy.poliza || '',
      aseguradora: policy.aseguradora || '',
      medioPago: policy.medioPago || '',
      aporteMensual: policy.aporteMensual ? policy.aporteMensual.toString() : '',
      fondoAcumulado: policy.fondoAcumulado ? policy.fondoAcumulado.toString() : '',
      prima: policy.prima ? policy.prima.toString() : '',
      comisionPorcentaje: policy.comisionPorcentaje ? policy.comisionPorcentaje.toString() : '',
      pagada: policy.pagada || false,
      calle: client?.direccion || '',
      numero: client?.altura || '',
      cp: client?.cp || policy.cp || '',
      provincia: client?.provincia || '',
      localidad: client?.localidad || ''
    });
    setEditPolicyOpen(true);
  };

  const handlePolicyInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setPolicyFormValues(prev => {
      let finalValue = type === 'checkbox' ? checked : value;
      
      if (typeof finalValue === 'string') {
        if (['cliente', 'rubro', 'aseguradora'].includes(name)) {
          finalValue = capitalizeWords(finalValue);
        }
        if (name === 'cuit') {
          finalValue = formatDNIorCUIT(finalValue);
        }
        if (['prima', 'aporteMensual', 'fondoAcumulado', 'comisionPorcentaje'].includes(name)) {
          finalValue = formatWithDots(finalValue);
        }
      }

      const newValues = { ...prev, [name]: finalValue };
      
      if (name === 'fechaInicio' && !manualVencimiento) {
        newValues.vencimiento = format(addDays(parseISO(value), 30), 'yyyy-MM-dd');
      }
      
      if (name === 'vencimiento') {
        setManualVencimiento(true);
      }
      
      return newValues;
    });
  };

  const handleSavePolicyEdit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    const updatedPolicy = {
      ...editingPolicy,
      cliente: policyFormValues.cliente,
      cuit: policyFormValues.cuit,
      telefono: policyFormValues.telefono,
      rubro: policyFormValues.rubro,
      fechaInicio: policyFormValues.fechaInicio,
      vencimiento: policyFormValues.vencimiento,
      poliza: policyFormValues.poliza,
      aseguradora: policyFormValues.aseguradora,
      medioPago: policyFormValues.medioPago,
      prima: Number(unformat(policyFormValues.prima)),
      comisionPorcentaje: Number(unformat(policyFormValues.comisionPorcentaje)),
      aporteMensual: editingPolicy.tipo === 'Retiro' ? Number(unformat(policyFormValues.aporteMensual)) : editingPolicy.aporteMensual,
      fondoAcumulado: editingPolicy.tipo === 'Retiro' ? Number(unformat(policyFormValues.fondoAcumulado)) : editingPolicy.fondoAcumulado,
      pagada: policyFormValues.pagada
    };

    // Check if client exists, if not add to clients list
    const existingClient = clients.find(c => c.nombre === updatedPolicy.cliente);
    if (!existingClient) {
      const newClient = {
        id: Math.random().toString(36).substr(2, 9),
        nombre: updatedPolicy.cliente,
        dni: updatedPolicy.cuit,
        telefono: updatedPolicy.telefono,
        email: '',
        direccion: policyFormValues.calle || '',
        altura: policyFormValues.numero || '',
        cp: policyFormValues.cp || '',
        provincia: policyFormValues.provincia || '',
        localidad: policyFormValues.localidad || ''
      };
      setClients(prev => [newClient, ...prev]);
    }

    if (updatedPolicy.pagada !== editingPolicy.pagada) {
      onTogglePaid(editingPolicy.id);
    } else {
      onUpdatePolicy(updatedPolicy);
    }
    setEditPolicyOpen(false);
    setEditingPolicy(null);
  };

  const handlePolicyWhatsApp = (policy: any) => {
    const pasName = user?.nombre || 'Tu Productor';
    const message = `Hola ${policy.cliente}, te informamos que tu póliza N° ${policy.poliza} vence el día ${format(parseISO(policy.vencimiento), 'dd/MM/yyyy')}. Por favor, contáctanos para renovarla. Saludos, ${pasName} - PAS Alert.`;
    const url = `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  const handlePolicyMail = (policy: any) => {
    const pasName = user?.nombre || 'Tu Productor';
    const subject = encodeURIComponent(`Vencimiento de Póliza - ${policy.aseguradora}`);
    const body = encodeURIComponent(`Hola ${policy.cliente},\n\nTe informamos que tu póliza N° ${policy.poliza} vence el día ${format(parseISO(policy.vencimiento), 'dd/MM/yyyy')}.\n\nPor favor, contáctanos para renovarla.\n\nSaludos,\n${pasName}\nPAS Alert`);
    window.location.href = `mailto:?subject=${subject}&body=${body}`;
  };

  const [formValues, setFormValues] = useState<any>({
    nombre: '',
    dni: '',
    telefono: '',
    email: '',
    direccion: '',
    altura: '',
    cp: '',
    provincia: '',
    localidad: ''
  });

  const capitalizeWords = (str: string) => {
    return str.toLowerCase().replace(/\b\w/g, (char) => char.toUpperCase());
  };

  const formatCUIT = (value: string) => {
    const digits = value.replace(/\D/g, '').slice(0, 11);
    if (digits.length <= 2) return digits;
    if (digits.length <= 10) return `${digits.slice(0, 2)}-${digits.slice(2)}`;
    return `${digits.slice(0, 2)}-${digits.slice(2, 10)}-${digits.slice(10)}`;
  };

  const handleInputChange = (field: string, value: string, shouldCapitalize = true) => {
    setFormValues(prev => ({
      ...prev,
      [field]: shouldCapitalize ? capitalizeWords(value) : value
    }));
  };

  const handleDNIChange = (value: string) => {
    // If it's 11 digits, format as CUIT, otherwise keep as is (DNI)
    const digits = value.replace(/\D/g, '');
    if (digits.length === 11) {
      setFormValues(prev => ({ ...prev, dni: formatCUIT(value) }));
    } else {
      setFormValues(prev => ({ ...prev, dni: value }));
    }
  };
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

  const handleMenuOpen = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleNewIndividual = () => {
    handleMenuClose();
    handleOpen();
  };

  const handleNewCompany = () => {
    handleMenuClose();
    navigate('/empresas', { state: { openNew: true } });
  };

  const handleOpen = (client?: any) => {
    if (client) {
      setEditingClient(client);
      const parts = client.direccion.split(' ');
      const altura = parts.length > 1 ? parts.pop() : '';
      const calle = parts.join(' ');
      
      setFormValues({
        ...client,
        direccion: calle || client.direccion,
        altura: altura || ''
      });
    } else {
      setEditingClient(null);
      setFormValues({
        nombre: '',
        dni: '',
        telefono: '',
        email: '',
        direccion: '',
        altura: '',
        cp: '',
        provincia: '',
        localidad: ''
      });
    }
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setEditingClient(null);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('¿Estás seguro de eliminar este cliente?')) {
      setClients(clients.filter(c => c.id !== id));
    }
  };

  const handleWhatsApp = (telefono: string) => {
    const url = `https://wa.me/${telefono.replace(/\D/g, '')}`;
    window.open(url, '_blank');
  };

  const handleExport = () => {
    const ws = XLSX.utils.json_to_sheet(clients);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Clientes");
    XLSX.writeFile(wb, "Clientes_PAS_Alert.xlsx");
  };

  const filteredClients = clients.filter(c => 
    (c.nombre.toLowerCase().includes(searchTerm.toLowerCase()) || 
     c.dni.includes(searchTerm)) &&
    (provinceFilter === '' || c.provincia === provinceFilter) &&
    (localityFilter === '' || c.localidad.toLowerCase().includes(localityFilter.toLowerCase()))
  );

  const getPolicyCount = (clientName: string) => {
    return policies.filter(p => p.cliente === clientName).length;
  };

  const handleSave = () => {
    const fullDireccion = `${formValues.direccion} ${formValues.altura}`.trim();
    const clientData = {
      ...formValues,
      direccion: fullDireccion,
      id: editingClient?.id || Math.random().toString(36).substr(2, 9)
    };

    if (editingClient) {
      setClients(clients.map(c => c.id === editingClient.id ? clientData : c));
    } else {
      setClients([clientData, ...clients]);
    }
    handleClose();
  };

  return (
    <Box>
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 800 }}>Gestión de Clientes</Typography>
          <Typography variant="body1" color="text.secondary">Administra tu cartera de clientes individuales.</Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <Button 
            variant="outlined" 
            startIcon={<Download size={20} />}
            onClick={handleExport}
          >
            Exportar Excel
          </Button>
          <Button 
            variant="contained" 
            startIcon={<Plus size={20} />}
            onClick={handleMenuOpen}
            sx={{ borderRadius: 3 }}
          >
            Nuevo...
          </Button>
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleMenuClose}
            transformOrigin={{ horizontal: 'right', vertical: 'top' }}
            anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
          >
            <MenuItem onClick={handleNewIndividual} sx={{ gap: 1.5 }}>
              <User size={18} />
              Nuevo Cliente (Individuo)
            </MenuItem>
            <MenuItem onClick={handleNewCompany} sx={{ gap: 1.5 }}>
              <Building2 size={18} />
              Nueva Empresa
            </MenuItem>
          </Menu>
        </Box>
      </Box>

      <Card sx={{ mb: 4 }}>
        <CardContent>
          <Grid container spacing={2} alignItems="center">
            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                fullWidth
                placeholder="Buscar por nombre o DNI..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <Search size={20} />
                    </InputAdornment>
                  ),
                }}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 3 }}>
              <Autocomplete
                options={PROVINCIAS_ARGENTINA}
                value={provinceFilter || null}
                onChange={(_, newValue) => setProvinceFilter(newValue || '')}
                renderInput={(params) => (
                  <TextField 
                    {...params} 
                    label="Filtrar por Provincia" 
                    placeholder="Todas"
                  />
                )}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 3 }}>
              <TextField
                fullWidth
                label="Filtrar por Localidad"
                placeholder="Ej: Córdoba"
                value={localityFilter}
                onChange={(e) => setLocalityFilter(e.target.value)}
              />
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      <TableContainer component={Paper}>
        <Table>
          <TableHead sx={{ bgcolor: 'primary.main' }}>
            <TableRow>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Nombre</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>DNI</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Teléfono</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Email</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Provincia</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Localidad</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>C.P.</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'right' }}>Acciones</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredClients.map((client) => {
              const clientPolicies = policies.filter(p => p.cliente === client.nombre);
              const isExpanded = expandedClient === client.id;
              
              return (
                <React.Fragment key={client.id}>
                  <TableRow hover sx={{ '& > *': { borderBottom: 'unset' } }}>
                    <TableCell sx={{ fontWeight: 600 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <IconButton
                          size="small"
                          onClick={() => setExpandedClient(isExpanded ? null : client.id)}
                        >
                          {isExpanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                        </IconButton>
                        <Box>
                          <Typography variant="body2" sx={{ fontWeight: 700 }}>{client.nombre}</Typography>
                          <Typography variant="caption" color="primary.main" sx={{ fontWeight: 600 }}>
                            Pólizas: {clientPolicies.length}
                          </Typography>
                        </Box>
                      </Box>
                    </TableCell>
                    <TableCell>{client.dni}</TableCell>
                    <TableCell>{client.telefono}</TableCell>
                    <TableCell>{client.email}</TableCell>
                    <TableCell>{client.provincia}</TableCell>
                    <TableCell>{client.localidad}</TableCell>
                    <TableCell>{client.cp}</TableCell>
                    <TableCell sx={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                      <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 0.5 }}>
                        <Button 
                          size="small" 
                          color="success" 
                          variant="outlined"
                          startIcon={<MessageCircle size={14} />}
                          onClick={() => handleWhatsApp(client.telefono)}
                          sx={{ fontSize: '0.65rem', py: 0.3, px: 1, minWidth: '90px', justifyContent: 'flex-start', fontWeight: 700 }}
                        >
                          WhatsApp
                        </Button>
                        <Button 
                          size="small" 
                          color="primary" 
                          variant="outlined"
                          startIcon={<Edit2 size={14} />}
                          onClick={() => handleOpen(client)}
                          sx={{ fontSize: '0.65rem', py: 0.3, px: 1, minWidth: '90px', justifyContent: 'flex-start', fontWeight: 700 }}
                        >
                          Modificar
                        </Button>
                        <Button 
                          size="small" 
                          color="info" 
                          variant="outlined"
                          startIcon={<Mail size={14} />}
                          onClick={() => window.location.href = `mailto:${client.email}`}
                          sx={{ fontSize: '0.65rem', py: 0.3, px: 1, minWidth: '90px', justifyContent: 'flex-start', fontWeight: 700 }}
                        >
                          Mail
                        </Button>
                        <Button 
                          size="small" 
                          color="error" 
                          variant="outlined"
                          startIcon={<Trash2 size={14} />}
                          onClick={() => handleDelete(client.id)}
                          sx={{ fontSize: '0.65rem', py: 0.3, px: 1, minWidth: '90px', justifyContent: 'flex-start', fontWeight: 700 }}
                        >
                          Eliminar
                        </Button>
                      </Box>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={8}>
                      <Collapse in={isExpanded} timeout="auto" unmountOnExit>
                        <Box sx={{ margin: 2 }}>
                          <Typography variant="subtitle2" gutterBottom component="div" sx={{ fontWeight: 700, color: 'primary.main', mb: 2 }}>
                            Detalle de Pólizas
                          </Typography>
                          {clientPolicies.length > 0 ? (
                            <TableContainer component={Paper} elevation={0} sx={{ border: '1px solid', borderColor: 'divider' }}>
                              <Table size="small">
                                <TableHead sx={{ bgcolor: 'primary.main' }}>
                                  <TableRow>
                                    <TableCell sx={{ color: 'white', fontWeight: 700, whiteSpace: 'nowrap' }}>Póliza / Aseguradora</TableCell>
                                    <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center', whiteSpace: 'nowrap' }}>Inicio</TableCell>
                                    <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center', whiteSpace: 'nowrap' }}>Vencimiento</TableCell>
                                    <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center' }}>Vigencia</TableCell>
                                    <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center' }}>Cuota</TableCell>
                                    {clientPolicies.some(p => p.tipo === 'Vida' || p.tipo === 'Retiro') && (
                                      <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'right' }}>Detalle</TableCell>
                                    )}
                                    <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center' }}>Pagado</TableCell>
                                    <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center' }}>Última Gestión</TableCell>
                                    <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'right' }}>Acciones</TableCell>
                                  </TableRow>
                                </TableHead>
                                <TableBody>
                                  {clientPolicies.map((policy) => {
                                    const daysLeft = differenceInDays(parseISO(policy.vencimiento), new Date());
                                    let color = 'success.main';
                                    if (daysLeft < 0) color = 'error.main';
                                    else if (daysLeft <= 5) color = 'warning.main';

                                    return (
                                      <TableRow key={policy.id} hover>
                                        <TableCell sx={{ fontWeight: 600, whiteSpace: 'nowrap' }}>
                                          <Box>
                                            <Typography variant="body2" sx={{ fontWeight: 700 }}>N° {policy.poliza}</Typography>
                                            <Chip 
                                              label={policy.aseguradora} 
                                              size="small" 
                                              sx={{ 
                                                bgcolor: '#1a237e', 
                                                color: 'white', 
                                                fontWeight: 700, 
                                                fontSize: '0.65rem',
                                                height: 20,
                                                mt: 0.5,
                                                borderRadius: '4px'
                                              }} 
                                            />
                                            {(policy.rubro || policy.tipo) && (
                                              <Typography variant="caption" display="block" color="text.secondary" sx={{ fontWeight: 700, textTransform: 'uppercase' }}>
                                                {policy.rubro || policy.tipo}
                                              </Typography>
                                            )}
                                          </Box>
                                        </TableCell>
                                        <TableCell sx={{ textAlign: 'center', whiteSpace: 'nowrap' }}>{policy.fechaInicio ? format(parseISO(policy.fechaInicio), 'dd/MM/yyyy') : '-'}</TableCell>
                                        <TableCell sx={{ textAlign: 'center', whiteSpace: 'nowrap' }}>{format(parseISO(policy.vencimiento), 'dd/MM/yyyy')}</TableCell>
                                        <TableCell>
                                          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5, alignItems: 'center', minWidth: 100 }}>
                                            <Chip 
                                              label={policy.pagada ? 'Pagado' : (daysLeft < 0 ? 'Vencida' : (daysLeft <= 5 ? 'Vence pronto' : 'Vigente'))} 
                                              size="small" 
                                              color={policy.pagada ? 'success' : (daysLeft < 0 ? 'error' : (daysLeft <= 5 ? 'warning' : 'success'))} 
                                              variant="filled" 
                                              sx={{ fontWeight: 700, fontSize: '0.7rem', height: 20 }}
                                            />
                                            {!policy.pagada && (
                                              <Typography variant="caption" sx={{ fontWeight: 800, color, textAlign: 'center', whiteSpace: 'nowrap' }}>
                                                {daysLeft === 0 ? 'Hoy' : `${daysLeft} días`}
                                              </Typography>
                                            )}
                                          </Box>
                                        </TableCell>
                                        <TableCell sx={{ textAlign: 'center' }}>
                                          <Typography variant="body2" sx={{ fontWeight: 700, color: 'primary.main' }}>
                                            {policy.cuota || '1/1'}
                                          </Typography>
                                          <Typography variant="caption" sx={{ display: 'block', color: 'text.secondary', fontWeight: 500 }}>
                                            {policy.medioPago || '-'}
                                          </Typography>
                                        </TableCell>
                                        {clientPolicies.some(p => p.tipo === 'Vida' || p.tipo === 'Retiro') && (
                                          <TableCell sx={{ textAlign: 'right' }}>
                                            {(policy.tipo === 'Vida' || policy.tipo === 'Retiro') ? (
                                              <>
                                                <Typography variant="body2" sx={{ fontWeight: 700, color: policy.tipo === 'Retiro' ? 'success.main' : 'inherit' }}>
                                                  {policy.tipo === 'Vida' ? `Suma: $ ${policy.sumaAsegurada?.toLocaleString()}` : `Fondo: $ ${policy.fondoAcumulado?.toLocaleString()}`}
                                                </Typography>
                                                <Typography variant="caption" sx={{ display: 'block', color: 'text.secondary', fontWeight: 500 }}>
                                                  {policy.tipo === 'Vida' ? `Prima: $ ${policy.prima?.toLocaleString()}` : `Aporte: $ ${policy.aporteMensual?.toLocaleString()}`}
                                                </Typography>
                                              </>
                                            ) : '-'}
                                          </TableCell>
                                        )}
                                        <TableCell>
                                          <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 0.5, justifyContent: 'center' }}>
                                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                              <IconButton 
                                                onClick={() => onTogglePaid(policy.id)}
                                                sx={{ 
                                                  color: policy.pagada ? 'success.main' : 'text.disabled',
                                                  p: 0.5
                                                }}
                                              >
                                                {policy.pagada ? <CheckSquare size={24} /> : <Square size={24} />}
                                              </IconButton>
                                              <Typography 
                                                variant="body2" 
                                                sx={{ 
                                                  fontWeight: 700, 
                                                  color: policy.pagada ? 'success.main' : 'text.disabled',
                                                  minWidth: 25
                                                }}
                                              >
                                                {policy.pagada ? 'SI' : 'NO'}
                                              </Typography>
                                            </Box>
                                            {policy.pagada && (
                                              <TextField
                                                type="date"
                                                size="small"
                                                value={policy.fechaPago || ''}
                                                onChange={(e) => onUpdatePolicy({ ...policy, fechaPago: e.target.value })}
                                                sx={{ 
                                                  width: 110,
                                                  '& .MuiInputBase-input': { 
                                                    fontSize: '0.65rem', 
                                                    p: '2px 4px',
                                                    textAlign: 'center'
                                                  } 
                                                }}
                                              />
                                            )}
                                          </Box>
                                        </TableCell>
                                        <TableCell>
                                          {policy.ultimaGestion ? (
                                            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5, alignItems: 'center' }}>
                                              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                {policy.ultimaGestion.tipo === 'Whatsapp' ? (
                                                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                                                    <MessageCircle size={16} color="#25D366" fill="#25D366" fillOpacity={0.2} />
                                                    <Typography variant="body2" sx={{ fontWeight: 700, color: '#25D366', whiteSpace: 'nowrap' }}>
                                                      Whatsapp ({policy.ultimaGestion.whatsappCount})
                                                    </Typography>
                                                  </Box>
                                                ) : (
                                                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                                                    <Mail size={16} color="#0288d1" fill="#0288d1" fillOpacity={0.2} />
                                                    <Typography variant="body2" sx={{ fontWeight: 700, color: '#0288d1', whiteSpace: 'nowrap' }}>
                                                      Mail ({policy.ultimaGestion.mailCount})
                                                    </Typography>
                                                  </Box>
                                                )}
                                              </Box>
                                              <Typography variant="caption" sx={{ color: 'text.secondary', fontWeight: 500, whiteSpace: 'nowrap' }}>
                                                {format(parseISO(policy.ultimaGestion.fecha), 'dd/MM/yyyy')}
                                              </Typography>
                                            </Box>
                                          ) : (
                                            <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center' }}>-</Typography>
                                          )}
                                        </TableCell>
                                        <TableCell sx={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                                          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 0.5 }}>
                                            <Button 
                                              size="small" 
                                              color="success" 
                                              variant="outlined"
                                              startIcon={<MessageCircle size={14} />}
                                              onClick={() => handlePolicyWhatsApp(policy)}
                                              sx={{ fontSize: '0.65rem', py: 0.3, px: 1, minWidth: '90px', justifyContent: 'flex-start', fontWeight: 700 }}
                                            >
                                              WhatsApp
                                            </Button>
                                            <Button 
                                              size="small" 
                                              color="primary" 
                                              variant="outlined"
                                              startIcon={<Edit2 size={14} />}
                                              onClick={() => handlePolicyEdit(policy)}
                                              sx={{ fontSize: '0.65rem', py: 0.3, px: 1, minWidth: '90px', justifyContent: 'flex-start', fontWeight: 700 }}
                                            >
                                              Modificar
                                            </Button>
                                            <Button 
                                              size="small" 
                                              color="info" 
                                              variant="outlined"
                                              startIcon={<Mail size={14} />}
                                              onClick={() => handlePolicyMail(policy)}
                                              sx={{ fontSize: '0.65rem', py: 0.3, px: 1, minWidth: '90px', justifyContent: 'flex-start', fontWeight: 700 }}
                                            >
                                              Mail
                                            </Button>
                                            <Button 
                                              size="small" 
                                              color="error" 
                                              variant="outlined"
                                              startIcon={<Trash2 size={14} />}
                                              onClick={() => onDeletePolicy(policy.id)}
                                              sx={{ fontSize: '0.65rem', py: 0.3, px: 1, minWidth: '90px', justifyContent: 'flex-start', fontWeight: 700 }}
                                            >
                                              Eliminar
                                            </Button>
                                          </Box>
                                        </TableCell>
                                      </TableRow>
                                    );
                                  })}
                                </TableBody>
                              </Table>
                            </TableContainer>
                          ) : (
                            <Typography variant="body2" color="text.secondary">
                              No hay pólizas registradas para este cliente.
                            </Typography>
                          )}
                        </Box>
                      </Collapse>
                    </TableCell>
                  </TableRow>
                </React.Fragment>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ fontWeight: 700 }}>
          {editingClient ? 'Editar Cliente' : 'Nuevo Cliente'}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid size={{ xs: 12 }}>
              <TextField 
                fullWidth 
                label="Nombre Completo" 
                value={formValues.nombre}
                onChange={(e) => handleInputChange('nombre', e.target.value)}
              />
            </Grid>
            <Grid size={{ xs: 6 }}>
              <TextField 
                fullWidth 
                label="DNI / CUIT" 
                value={formValues.dni}
                onChange={(e) => handleDNIChange(e.target.value)}
              />
            </Grid>
            <Grid size={{ xs: 6 }}>
              <TextField 
                fullWidth 
                label="Teléfono" 
                value={formValues.telefono}
                onChange={(e) => handleInputChange('telefono', e.target.value, false)}
              />
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField 
                fullWidth 
                label="Email" 
                value={formValues.email}
                onChange={(e) => handleInputChange('email', e.target.value, false)}
              />
            </Grid>
            <Grid size={{ xs: 6 }}>
              <TextField 
                fullWidth 
                label="Calle" 
                value={formValues.direccion}
                onChange={(e) => handleInputChange('direccion', e.target.value)}
              />
            </Grid>
            <Grid size={{ xs: 2 }}>
              <TextField 
                fullWidth 
                label="N°" 
                value={formValues.altura}
                onChange={(e) => handleInputChange('altura', e.target.value, false)}
              />
            </Grid>
            <Grid size={{ xs: 4 }}>
              <TextField 
                fullWidth 
                label="C.P." 
                value={formValues.cp}
                onChange={(e) => handleInputChange('cp', e.target.value, false)}
              />
            </Grid>
            <Grid size={{ xs: 6 }}>
              <TextField 
                fullWidth 
                select 
                label="Provincia" 
                value={formValues.provincia}
                onChange={(e) => handleInputChange('provincia', e.target.value, false)}
              >
                {PROVINCIAS_ARGENTINA.map((prov) => (
                  <MenuItem key={prov} value={prov}>
                    {prov}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid size={{ xs: 6 }}>
              <TextField 
                fullWidth 
                label="Localidad" 
                value={formValues.localidad}
                onChange={(e) => handleInputChange('localidad', e.target.value)}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ p: 3 }}>
          <Button onClick={handleClose}>Cancelar</Button>
          <Button variant="contained" onClick={handleSave}>Guardar Cliente</Button>
        </DialogActions>
      </Dialog>

      <Dialog open={editPolicyOpen} onClose={() => setEditPolicyOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ fontWeight: 800 }}>Editar Póliza</DialogTitle>
        <form onSubmit={handleSavePolicyEdit}>
          <DialogContent>
            <Grid container spacing={2}>
              <Grid size={{ xs: 12, sm: 6 }}>
                <Autocomplete
                  freeSolo
                  options={clients.map(c => c.nombre)}
                  value={policyFormValues.cliente}
                  onChange={(_, value) => {
                    const selectedClient = clients.find(c => c.nombre === value);
                    if (selectedClient) {
                      setPolicyFormValues(prev => ({
                        ...prev,
                        cliente: selectedClient.nombre,
                        cuit: selectedClient.dni,
                        telefono: selectedClient.telefono,
                        calle: selectedClient.direccion || '',
                        numero: selectedClient.altura || '',
                        cp: selectedClient.cp || '',
                        provincia: selectedClient.provincia || '',
                        localidad: selectedClient.localidad || ''
                      }));
                    } else {
                      setPolicyFormValues(prev => ({ ...prev, cliente: value || '' }));
                    }
                  }}
                  onInputChange={(_, value) => setPolicyFormValues(prev => ({ ...prev, cliente: value }))}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      fullWidth
                      label="Cliente"
                      name="cliente"
                    />
                  )}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 3 }}>
                <TextField
                  fullWidth
                  label="DNI/CUIT"
                  name="cuit"
                  value={policyFormValues.cuit}
                  onChange={handlePolicyInputChange}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 3 }}>
                <TextField
                  fullWidth
                  label="Teléfono"
                  name="telefono"
                  value={policyFormValues.telefono}
                  onChange={handlePolicyInputChange}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <TextField
                  fullWidth
                  label="Calle"
                  name="calle"
                  value={policyFormValues.calle}
                  onChange={handlePolicyInputChange}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 2 }}>
                <TextField
                  fullWidth
                  label="N°"
                  name="numero"
                  value={policyFormValues.numero}
                  onChange={handlePolicyInputChange}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 4 }}>
                <TextField
                  fullWidth
                  label="C.P."
                  name="cp"
                  value={policyFormValues.cp}
                  onChange={handlePolicyInputChange}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <Autocomplete
                  options={PROVINCIAS_ARGENTINA}
                  value={policyFormValues.provincia}
                  onChange={(_, value) => setPolicyFormValues(prev => ({ ...prev, provincia: value || '' }))}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      fullWidth
                      label="Provincia"
                      name="provincia"
                    />
                  )}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <TextField
                  fullWidth
                  label="Localidad"
                  name="localidad"
                  value={policyFormValues.localidad}
                  onChange={handlePolicyInputChange}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <TextField
                  fullWidth
                  label="Rubro"
                  name="rubro"
                  value={policyFormValues.rubro}
                  onChange={handlePolicyInputChange}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <Autocomplete
                  freeSolo
                  options={TODAS_LAS_ASEGURADORAS}
                  value={policyFormValues.aseguradora}
                  onChange={(_, value) => setPolicyFormValues(prev => ({ ...prev, aseguradora: capitalizeWords(value || '') }))}
                  onInputChange={(_, value) => setPolicyFormValues(prev => ({ ...prev, aseguradora: capitalizeWords(value || '') }))}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      fullWidth
                      label="Aseguradora"
                      name="aseguradora"
                    />
                  )}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <TextField
                  fullWidth
                  label="Número de Póliza"
                  name="poliza"
                  value={policyFormValues.poliza}
                  onChange={handlePolicyInputChange}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <TextField
                  fullWidth
                  label="Fecha de Inicio"
                  name="fechaInicio"
                  type="date"
                  value={policyFormValues.fechaInicio}
                  onChange={handlePolicyInputChange}
                  InputLabelProps={{ shrink: true }}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <TextField
                  fullWidth
                  label="Fecha de Vencimiento"
                  name="vencimiento"
                  type="date"
                  value={policyFormValues.vencimiento}
                  onChange={handlePolicyInputChange}
                  InputLabelProps={{ shrink: true }}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <TextField
                  fullWidth
                  label="Medio de Pago"
                  name="medioPago"
                  value={policyFormValues.medioPago}
                  onChange={handlePolicyInputChange}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 3 }}>
                <TextField
                  fullWidth
                  label="Prima"
                  name="prima"
                  value={policyFormValues.prima}
                  onChange={handlePolicyInputChange}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 3 }}>
                <TextField
                  fullWidth
                  label="Comisión %"
                  name="comisionPorcentaje"
                  value={policyFormValues.comisionPorcentaje}
                  onChange={handlePolicyInputChange}
                />
              </Grid>
              <Grid size={{ xs: 12 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <IconButton 
                    onClick={() => setPolicyFormValues(prev => ({ ...prev, pagada: !prev.pagada }))}
                    sx={{ color: policyFormValues.pagada ? 'success.main' : 'text.disabled' }}
                  >
                    {policyFormValues.pagada ? <CheckSquare size={24} /> : <Square size={24} />}
                  </IconButton>
                  <Typography variant="body1" sx={{ fontWeight: 600 }}>
                    Marcar como Pagada
                  </Typography>
                </Box>
              </Grid>
              {editingPolicy?.tipo === 'Retiro' && (
                <>
                  <Grid size={{ xs: 12, sm: 6 }}>
                    <TextField
                      fullWidth
                      label="Aporte Mensual"
                      name="aporteMensual"
                      value={policyFormValues.aporteMensual}
                      onChange={handlePolicyInputChange}
                    />
                  </Grid>
                  <Grid size={{ xs: 12, sm: 6 }}>
                    <TextField
                      fullWidth
                      label="Fondo Acumulado"
                      name="fondoAcumulado"
                      value={policyFormValues.fondoAcumulado}
                      onChange={handlePolicyInputChange}
                    />
                  </Grid>
                </>
              )}
            </Grid>
          </DialogContent>
          <DialogActions sx={{ p: 3 }}>
            <Button onClick={() => setEditPolicyOpen(false)}>Cancelar</Button>
            <Button type="submit" variant="contained">Guardar Cambios</Button>
          </DialogActions>
        </form>
      </Dialog>
    </Box>
  );
};
