import React, { useState, useMemo } from 'react';
import { 
  Box, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  LinearProgress,
  Chip,
  Tabs,
  Tab,
  IconButton,
  Tooltip,
  TextField,
  InputAdornment,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  MenuItem,
  Alert,
  AlertTitle,
  Divider,
  CircularProgress
} from '@mui/material';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as RechartsTooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie,
  Cell
} from 'recharts';
import { 
  Download, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Target, 
  PieChart as PieIcon, 
  FileText, 
  Plus, 
  Search, 
  Filter, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  History, 
  Receipt,
  MoreVertical, 
  Edit, 
  Trash2, 
  Eye, 
  CreditCard,
  Settings,
  ShieldCheck,
  ArrowRightLeft,
  FileUp,
  Info
} from 'lucide-react';
import { format, parseISO, differenceInDays, addDays } from 'date-fns';
import * as XLSX from 'xlsx';

import { InsuranceCompany, CommissionInvoice, CommissionConfig, InvoiceStatus } from '../types';

const STATUS_COLORS: Record<InvoiceStatus, string> = {
  'Pendiente': '#64748b',
  'Facturada': '#3b82f6',
  'Cobrada': '#10b981',
  'Parcial': '#f59e0b',
  'Vencida': '#ef4444'
};

const RUBROS = ['Automotores', 'Hogar', 'Vida', 'Retiro', 'ART', 'Comercio', 'Responsabilidad Civil'];

interface ExtendedInvoice extends CommissionInvoice {
  insurerName: string;
}

export const CommissionsPage: React.FC<{ insurers: InsuranceCompany[] }> = ({ insurers }) => {
  const [tabValue, setTabValue] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [companyFilter, setCompanyFilter] = useState<string>('all');
  
  // Modals
  const [openPaymentDialog, setOpenPaymentDialog] = useState(false);
  const [openConfigDialog, setOpenConfigDialog] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<ExtendedInvoice | null>(null);
  
  // Mock Configs
  const [configs, setConfigs] = useState<CommissionConfig[]>([
    { id: '1', userId: '1', aseguradoraId: '1', rubro: 'Automotores', porcentaje: 15 },
    { id: '2', userId: '1', aseguradoraId: '1', rubro: 'Hogar', porcentaje: 20 },
    { id: '3', userId: '1', aseguradoraId: '2', rubro: 'Automotores', porcentaje: 12 },
    { id: '4', userId: '1', aseguradoraId: '2', rubro: 'Vida', porcentaje: 25 },
  ]);

  const allInvoices = useMemo((): ExtendedInvoice[] => {
    return insurers.flatMap(insurer => 
      (insurer.facturacionComisiones || []).map(invoice => ({
        ...invoice,
        insurerName: insurer.razonSocial
      }))
    ).sort((a, b) => new Date(b.fechaEmision).getTime() - new Date(a.fechaEmision).getTime());
  }, [insurers]);

  const filteredInvoices = useMemo(() => {
    return allInvoices.filter(invoice => {
      const matchesSearch = invoice.insurerName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                           invoice.numeroFactura.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === 'all' || invoice.estado === statusFilter;
      const matchesCompany = companyFilter === 'all' || invoice.aseguradoraId === companyFilter;
      return matchesSearch && matchesStatus && matchesCompany;
    });
  }, [allInvoices, searchTerm, statusFilter, companyFilter]);

  const stats = useMemo(() => {
    const totalExpected = allInvoices.reduce((acc, curr) => acc + curr.montoEsperado, 0);
    const totalBilled = allInvoices.reduce((acc, curr) => acc + curr.montoFacturado, 0);
    const totalCollected = allInvoices.reduce((acc, curr) => acc + curr.montoCobrado, 0);
    const totalPending = totalBilled - totalCollected;
    const totalDifferences = allInvoices.filter(i => i.diferenciaDetectada).length;
    
    // Average collection time
    const collectedInvoices = allInvoices.filter(i => i.estado === 'Cobrada' && i.pagos.length > 0);
    const avgCollectionDays = collectedInvoices.length > 0
      ? Math.round(collectedInvoices.reduce((acc, i) => {
          const emitDate = parseISO(i.fechaEmision);
          const lastPaymentDate = parseISO(i.pagos[i.pagos.length - 1].fecha);
          return acc + differenceInDays(lastPaymentDate, emitDate);
        }, 0) / collectedInvoices.length)
      : 0;

    return { totalExpected, totalBilled, totalCollected, totalPending, totalDifferences, avgCollectionDays };
  }, [allInvoices]);

  const chartData = useMemo(() => {
    // Group by month
    const monthly: Record<string, { name: string, cobrado: number, facturado: number }> = {};
    allInvoices.slice(0, 12).forEach(inv => {
      const month = format(parseISO(inv.fechaEmision), 'MMM yy');
      if (!monthly[month]) monthly[month] = { name: month, cobrado: 0, facturado: 0 };
      monthly[month].cobrado += inv.montoCobrado;
      monthly[month].facturado += inv.montoFacturado;
    });
    return Object.values(monthly).reverse();
  }, [allInvoices]);

  const handleExport = () => {
    const ws = XLSX.utils.json_to_sheet(allInvoices.map(i => ({
      'Aseguradora': i.insurerName,
      'Periodo': i.periodo,
      'Factura': i.numeroFactura,
      'Emisión': i.fechaEmision,
      'Vencimiento': i.vencimiento,
      'Monto Esperado': i.montoEsperado,
      'Monto Facturado': i.montoFacturado,
      'Monto Cobrado': i.montoCobrado,
      'Estado': i.estado,
      'Diferencia': i.diferenciaDetectada ? 'SÍ' : 'NO'
    })));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Comisiones");
    XLSX.writeFile(wb, "Gestion_Comisiones_PAS.xlsx");
  };

  const getStatusChip = (status: InvoiceStatus) => (
    <Chip 
      label={status} 
      size="small" 
      sx={{ 
        bgcolor: `${STATUS_COLORS[status]}20`, 
        color: STATUS_COLORS[status], 
        fontWeight: 700,
        borderRadius: '6px'
      }} 
    />
  );

  const handleGenerateInvoices = () => {
    // Simulation of automatic grouping by month and company
    const today = new Date();
    const period = format(today, 'MMMM yyyy');
    alert(`Generando facturas automáticas para el periodo ${period}... \n\nSe han agrupado comisiones de 12 pólizas para 5 compañías.`);
  };

  return (
    <Box>
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 900, color: 'primary.main', letterSpacing: -0.5 }}>Gestión Financiera de Comisiones</Typography>
          <Typography variant="body1" color="text.secondary">Control de facturación, auditoría de liquidaciones y seguimiento de cobranzas.</Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <Button 
            variant="outlined" 
            startIcon={<History size={20} />}
            onClick={handleGenerateInvoices}
            sx={{ borderRadius: '12px', textTransform: 'none', fontWeight: 600 }}
          >
            Generar Facturas Mensuales
          </Button>
          <Button 
            variant="outlined" 
            startIcon={<Download size={20} />}
            onClick={handleExport}
            sx={{ borderRadius: '12px', textTransform: 'none', fontWeight: 600 }}
          >
            Exportar Reporte
          </Button>
          <Button 
            variant="contained" 
            startIcon={<Plus size={20} />}
            sx={{ borderRadius: '12px', textTransform: 'none', fontWeight: 700, px: 3 }}
          >
            Nueva Factura
          </Button>
        </Box>
      </Box>

      {/* Critical Alerts */}
      {stats.totalDifferences > 0 && (
        <Alert severity="error" sx={{ mb: 3, borderRadius: '16px', border: '1px solid #fee2e2' }}>
          <AlertTitle sx={{ fontWeight: 800 }}>Diferencias de Liquidación Detectadas</AlertTitle>
          Se han detectado <strong>{stats.totalDifferences} facturas</strong> con discrepancias entre el monto esperado y el liquidado por la compañía.
        </Alert>
      )}

      {/* Dashboard Stats */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        {[
          { label: 'Comisiones Generadas', value: stats.totalExpected, icon: <TrendingUp size={24} />, color: '#6366f1', desc: 'Monto esperado según pólizas' },
          { label: 'Total Facturado', value: stats.totalBilled, icon: <FileText size={24} />, color: '#3b82f6', desc: 'Facturas emitidas a compañías' },
          { label: 'Total Cobrado', value: stats.totalCollected, icon: <CheckCircle2 size={24} />, color: '#10b981', desc: 'Ingresos reales percibidos' },
          { label: 'Pendiente de Cobro', value: stats.totalPending, icon: <Clock size={24} />, color: '#f59e0b', desc: 'Facturado vs Cobrado' }
        ].map((stat, idx) => (
          <Grid key={idx} size={{ xs: 12, sm: 6, md: 3 }}>
            <Card sx={{ borderRadius: '20px', boxShadow: '0 4px 20px rgba(0,0,0,0.05)', border: '1px solid #f1f5f9', height: '100%' }}>
              <CardContent>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                  <Box sx={{ p: 1.5, bgcolor: `${stat.color}15`, color: stat.color, borderRadius: '12px' }}>
                    {stat.icon}
                  </Box>
                  {idx === 2 && (
                    <Chip 
                      label={`${Math.round((stats.totalCollected / stats.totalBilled) * 100)}% Eficacia`} 
                      size="small" 
                      sx={{ bgcolor: '#dcfce7', color: '#166534', fontWeight: 700, fontSize: '0.7rem' }} 
                    />
                  )}
                </Box>
                <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 600, textTransform: 'uppercase', letterSpacing: 1 }}>{stat.label}</Typography>
                <Typography variant="h4" sx={{ fontWeight: 900, my: 0.5 }}>$ {stat.value.toLocaleString()}</Typography>
                <Typography variant="caption" color="text.secondary">{stat.desc}</Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 4 }}>
        <Tabs value={tabValue} onChange={(_, v) => setTabValue(v)} sx={{ '& .MuiTab-root': { textTransform: 'none', fontWeight: 700, fontSize: '1rem' } }}>
          <Tab icon={<PieIcon size={18} />} iconPosition="start" label="Dashboard Financiero" />
          <Tab icon={<Receipt size={18} />} iconPosition="start" label="Facturación y Cobranzas" />
          <Tab icon={<ShieldCheck size={18} />} iconPosition="start" label="Auditoría de Diferencias" />
          <Tab icon={<Settings size={18} />} iconPosition="start" label="Configuración de Comisiones" />
        </Tabs>
      </Box>

      {tabValue === 0 && (
        <Grid container spacing={3}>
          <Grid size={{ xs: 12, md: 8 }}>
            <Card sx={{ borderRadius: '20px', boxShadow: '0 4px 20px rgba(0,0,0,0.05)' }}>
              <CardContent>
                <Typography variant="h6" sx={{ fontWeight: 800, mb: 3 }}>Evolución de Ingresos (Facturado vs Cobrado)</Typography>
                <Box sx={{ height: 350 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                      <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} tickFormatter={(v) => `$${v/1000}k`} />
                      <RechartsTooltip 
                        contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                        formatter={(v: number) => [`$${v.toLocaleString()}`, '']}
                      />
                      <Bar dataKey="facturado" name="Facturado" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={20} />
                      <Bar dataKey="cobrado" name="Cobrado" fill="#10b981" radius={[4, 4, 0, 0]} barSize={20} />
                    </BarChart>
                  </ResponsiveContainer>
                </Box>
              </CardContent>
            </Card>
          </Grid>
          <Grid size={{ xs: 12, md: 4 }}>
            <Card sx={{ borderRadius: '20px', boxShadow: '0 4px 20px rgba(0,0,0,0.05)', height: '100%' }}>
              <CardContent>
                <Typography variant="h6" sx={{ fontWeight: 800, mb: 3 }}>Eficiencia de Cobro</Typography>
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
                  <Box sx={{ p: 3, bgcolor: '#f8fafc', borderRadius: '16px', textAlign: 'center' }}>
                    <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 700, textTransform: 'uppercase' }}>Tiempo Promedio de Cobro</Typography>
                    <Typography variant="h3" sx={{ fontWeight: 900, color: 'primary.main', my: 1 }}>{stats.avgCollectionDays} <Typography component="span" variant="h6">días</Typography></Typography>
                    <Typography variant="caption" color="text.secondary">Desde la emisión de la factura</Typography>
                  </Box>
                  
                  <Typography variant="subtitle2" sx={{ fontWeight: 800 }}>Ranking por Compañía (Volumen)</Typography>
                  {insurers.slice(0, 4).map((ins, idx) => (
                    <Box key={ins.id} sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                      <Box sx={{ width: 32, height: 32, bgcolor: 'primary.light', color: 'primary.main', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyCenter: 'center', fontWeight: 800, fontSize: '0.8rem' }}>
                        {idx + 1}
                      </Box>
                      <Box sx={{ flexGrow: 1 }}>
                        <Typography variant="body2" sx={{ fontWeight: 700 }}>{ins.razonSocial}</Typography>
                        <LinearProgress variant="determinate" value={80 - (idx * 15)} sx={{ height: 6, borderRadius: 3, mt: 0.5 }} />
                      </Box>
                    </Box>
                  ))}
                </Box>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      )}

      {tabValue === 1 && (
        <Box>
          <Card sx={{ mb: 3, borderRadius: '16px' }}>
            <CardContent sx={{ p: 2 }}>
              <Grid container spacing={2} alignItems="center">
                <Grid size={{ xs: 12, md: 4 }}>
                  <TextField
                    fullWidth
                    size="small"
                    placeholder="Buscar por factura o compañía..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    InputProps={{
                      startAdornment: <InputAdornment position="start"><Search size={18} /></InputAdornment>,
                    }}
                  />
                </Grid>
                <Grid size={{ xs: 12, md: 3 }}>
                  <TextField
                    fullWidth
                    select
                    size="small"
                    label="Estado"
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                  >
                    <MenuItem value="all">Todos los estados</MenuItem>
                    <MenuItem value="Pendiente">Pendiente</MenuItem>
                    <MenuItem value="Facturada">Facturada</MenuItem>
                    <MenuItem value="Parcial">Parcial</MenuItem>
                    <MenuItem value="Cobrada">Cobrada</MenuItem>
                    <MenuItem value="Vencida">Vencida</MenuItem>
                  </TextField>
                </Grid>
                <Grid size={{ xs: 12, md: 3 }}>
                  <TextField
                    fullWidth
                    select
                    size="small"
                    label="Compañía"
                    value={companyFilter}
                    onChange={(e) => setCompanyFilter(e.target.value)}
                  >
                    <MenuItem value="all">Todas las compañías</MenuItem>
                    {insurers.map(ins => (
                      <MenuItem key={ins.id} value={ins.id}>{ins.razonSocial}</MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid size={{ xs: 12, md: 2 }}>
                  <Button fullWidth variant="outlined" startIcon={<Filter size={18} />} sx={{ borderRadius: '8px' }}>Filtros</Button>
                </Grid>
              </Grid>
            </CardContent>
          </Card>

          <TableContainer component={Paper} sx={{ borderRadius: '16px', boxShadow: '0 4px 20px rgba(0,0,0,0.05)', border: '1px solid #f1f5f9' }}>
            <Table>
              <TableHead sx={{ bgcolor: '#f8fafc' }}>
                <TableRow>
                  <TableCell sx={{ fontWeight: 800 }}>Factura / Periodo</TableCell>
                  <TableCell sx={{ fontWeight: 800 }}>Compañía</TableCell>
                  <TableCell sx={{ fontWeight: 800 }}>Emisión / Vto.</TableCell>
                  <TableCell sx={{ fontWeight: 800, textAlign: 'right' }}>Monto Facturado</TableCell>
                  <TableCell sx={{ fontWeight: 800, textAlign: 'right' }}>Cobrado</TableCell>
                  <TableCell sx={{ fontWeight: 800, textAlign: 'center' }}>Estado</TableCell>
                  <TableCell sx={{ fontWeight: 800, textAlign: 'right' }}>Acciones</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredInvoices.map((invoice) => {
                  const isOverdue = invoice.estado !== 'Cobrada' && differenceInDays(new Date(), parseISO(invoice.vencimiento)) > 0;
                  return (
                    <TableRow key={invoice.id} hover>
                      <TableCell>
                        <Box>
                          <Typography variant="body2" sx={{ fontWeight: 700 }}>{invoice.numeroFactura || 'S/N'}</Typography>
                          <Typography variant="caption" color="text.secondary">{invoice.periodo}</Typography>
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>{invoice.insurerName}</Typography>
                      </TableCell>
                      <TableCell>
                        <Box>
                          <Typography variant="caption" display="block">Emi: {format(parseISO(invoice.fechaEmision), 'dd/MM/yy')}</Typography>
                          <Typography variant="caption" sx={{ color: isOverdue ? 'error.main' : 'text.secondary', fontWeight: isOverdue ? 700 : 400 }}>
                            Vto: {format(parseISO(invoice.vencimiento), 'dd/MM/yy')}
                          </Typography>
                        </Box>
                      </TableCell>
                      <TableCell sx={{ textAlign: 'right' }}>
                        <Typography variant="body2" sx={{ fontWeight: 700 }}>$ {invoice.montoFacturado.toLocaleString()}</Typography>
                      </TableCell>
                      <TableCell sx={{ textAlign: 'right' }}>
                        <Typography variant="body2" sx={{ fontWeight: 700, color: 'success.main' }}>$ {invoice.montoCobrado.toLocaleString()}</Typography>
                        {invoice.montoFacturado > invoice.montoCobrado && invoice.montoCobrado > 0 && (
                          <Typography variant="caption" color="error" sx={{ fontWeight: 600 }}>
                            Pend: $ {(invoice.montoFacturado - invoice.montoCobrado).toLocaleString()}
                          </Typography>
                        )}
                      </TableCell>
                      <TableCell sx={{ textAlign: 'center' }}>
                        {getStatusChip(isOverdue ? 'Vencida' : invoice.estado)}
                      </TableCell>
                      <TableCell sx={{ textAlign: 'right' }}>
                        <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1 }}>
                          <Tooltip title="Registrar Cobro">
                            <IconButton size="small" color="success" onClick={() => { setSelectedInvoice(invoice); setOpenPaymentDialog(true); }}>
                              <CreditCard size={18} />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Ver Detalle">
                            <IconButton size="small" color="primary">
                              <Eye size={18} />
                            </IconButton>
                          </Tooltip>
                          <IconButton size="small">
                            <MoreVertical size={18} />
                          </IconButton>
                        </Box>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      )}

      {tabValue === 2 && (
        <Box>
          <Alert severity="info" sx={{ mb: 3, borderRadius: '12px' }}>
            Esta sección muestra las facturas donde el monto liquidado por la compañía difiere del monto esperado según las pólizas vigentes.
          </Alert>
          
          <TableContainer component={Paper} sx={{ borderRadius: '16px', border: '1px solid #f1f5f9' }}>
            <Table>
              <TableHead sx={{ bgcolor: '#f8fafc' }}>
                <TableRow>
                  <TableCell sx={{ fontWeight: 800 }}>Factura</TableCell>
                  <TableCell sx={{ fontWeight: 800 }}>Compañía</TableCell>
                  <TableCell sx={{ fontWeight: 800, textAlign: 'right' }}>Esperado</TableCell>
                  <TableCell sx={{ fontWeight: 800, textAlign: 'right' }}>Liquidado</TableCell>
                  <TableCell sx={{ fontWeight: 800, textAlign: 'right' }}>Diferencia</TableCell>
                  <TableCell sx={{ fontWeight: 800 }}>Observaciones</TableCell>
                  <TableCell sx={{ fontWeight: 800, textAlign: 'right' }}>Acciones</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {allInvoices.filter(i => i.diferenciaDetectada).map((invoice) => (
                  <TableRow key={invoice.id}>
                    <TableCell sx={{ fontWeight: 700 }}>{invoice.numeroFactura}</TableCell>
                    <TableCell>{invoice.insurerName}</TableCell>
                    <TableCell sx={{ textAlign: 'right' }}>$ {invoice.montoEsperado.toLocaleString()}</TableCell>
                    <TableCell sx={{ textAlign: 'right' }}>$ {invoice.montoFacturado.toLocaleString()}</TableCell>
                    <TableCell sx={{ textAlign: 'right', color: 'error.main', fontWeight: 800 }}>
                      $ {(invoice.montoEsperado - invoice.montoFacturado).toLocaleString()}
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption" sx={{ color: 'text.secondary', fontStyle: 'italic' }}>
                        {invoice.notas || 'Sin observaciones registradas.'}
                      </Typography>
                    </TableCell>
                    <TableCell sx={{ textAlign: 'right' }}>
                      <Button size="small" variant="outlined" color="error" sx={{ textTransform: 'none', borderRadius: '8px' }}>Reclamar</Button>
                    </TableCell>
                  </TableRow>
                ))}
                {allInvoices.filter(i => i.diferenciaDetectada).length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} sx={{ py: 8, textAlign: 'center' }}>
                      <CheckCircle2 size={48} color="#10b981" style={{ marginBottom: 16 }} />
                      <Typography variant="h6">No se detectaron diferencias de liquidación</Typography>
                      <Typography variant="body2" color="text.secondary">Todas las facturas coinciden con los montos esperados.</Typography>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      )}

      {tabValue === 3 && (
        <Box>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
            <Typography variant="h6" sx={{ fontWeight: 800 }}>Configuración de Porcentajes por Compañía y Rubro</Typography>
            <Button variant="contained" startIcon={<Plus size={18} />} onClick={() => setOpenConfigDialog(true)}>Nueva Configuración</Button>
          </Box>
          
          <Grid container spacing={3}>
            {insurers.slice(0, 6).map(insurer => (
              <Grid key={insurer.id} size={{ xs: 12, md: 4 }}>
                <Card sx={{ borderRadius: '16px', border: '1px solid #f1f5f9' }}>
                  <CardContent>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
                      <Box sx={{ width: 40, height: 40, bgcolor: 'primary.main', color: 'white', borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <ShieldCheck size={24} />
                      </Box>
                      <Typography variant="subtitle1" sx={{ fontWeight: 800 }}>{insurer.razonSocial}</Typography>
                    </Box>
                    <Divider sx={{ mb: 2 }} />
                    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                      {configs.filter(c => c.aseguradoraId === insurer.id).map(config => (
                        <Box key={config.id} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', p: 1.5, bgcolor: '#f8fafc', borderRadius: '12px' }}>
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>{config.rubro}</Typography>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <Typography variant="body2" sx={{ fontWeight: 800, color: 'primary.main' }}>{config.porcentaje}%</Typography>
                            <IconButton size="small"><Edit size={14} /></IconButton>
                          </Box>
                        </Box>
                      ))}
                      {configs.filter(c => c.aseguradoraId === insurer.id).length === 0 && (
                        <Typography variant="caption" color="text.secondary" sx={{ textAlign: 'center', py: 2 }}>No hay porcentajes configurados.</Typography>
                      )}
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Box>
      )}

      {/* Register Payment Dialog */}
      <Dialog open={openPaymentDialog} onClose={() => setOpenPaymentDialog(false)} maxWidth="xs" fullWidth>
        <DialogTitle sx={{ fontWeight: 800 }}>Registrar Cobro de Comisión</DialogTitle>
        <DialogContent dividers>
          {selectedInvoice && (
            <Box sx={{ mb: 3, p: 2, bgcolor: '#f8fafc', borderRadius: '12px' }}>
              <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 700, textTransform: 'uppercase' }}>Factura Seleccionada</Typography>
              <Typography variant="subtitle1" sx={{ fontWeight: 800 }}>{selectedInvoice.numeroFactura}</Typography>
              <Typography variant="body2" color="text.secondary">{selectedInvoice.insurerName} - {selectedInvoice.periodo}</Typography>
              <Box sx={{ mt: 1, display: 'flex', justifyContent: 'space-between' }}>
                <Typography variant="body2">Total Facturado:</Typography>
                <Typography variant="body2" sx={{ fontWeight: 700 }}>$ {selectedInvoice.montoFacturado.toLocaleString()}</Typography>
              </Box>
              <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                <Typography variant="body2">Ya Cobrado:</Typography>
                <Typography variant="body2" sx={{ fontWeight: 700, color: 'success.main' }}>$ {selectedInvoice.montoCobrado.toLocaleString()}</Typography>
              </Box>
            </Box>
          )}
          <Grid container spacing={2}>
            <Grid size={12}>
              <TextField 
                fullWidth 
                label="Monto a Cobrar" 
                type="number" 
                defaultValue={selectedInvoice ? selectedInvoice.montoFacturado - selectedInvoice.montoCobrado : 0}
                InputProps={{ startAdornment: <InputAdornment position="start">$</InputAdornment> }}
              />
            </Grid>
            <Grid size={12}>
              <TextField fullWidth label="Fecha de Cobro" type="date" defaultValue={format(new Date(), 'yyyy-MM-dd')} InputLabelProps={{ shrink: true }} />
            </Grid>
            <Grid size={12}>
              <TextField fullWidth select label="Medio de Pago" defaultValue="Transferencia">
                <MenuItem value="Transferencia">Transferencia Bancaria</MenuItem>
                <MenuItem value="Efectivo">Efectivo</MenuItem>
                <MenuItem value="Cheque">Cheque</MenuItem>
              </TextField>
            </Grid>
            <Grid size={12}>
              <Button fullWidth variant="outlined" startIcon={<FileUp size={18} />} sx={{ borderStyle: 'dashed', py: 1.5 }}>Adjuntar Comprobante</Button>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ p: 3 }}>
          <Button onClick={() => setOpenPaymentDialog(false)} color="inherit">Cancelar</Button>
          <Button variant="contained" onClick={() => setOpenPaymentDialog(false)} sx={{ px: 4 }}>Confirmar Cobro</Button>
        </DialogActions>
      </Dialog>

      {/* Config Dialog */}
      <Dialog open={openConfigDialog} onClose={() => setOpenConfigDialog(false)} maxWidth="xs" fullWidth>
        <DialogTitle sx={{ fontWeight: 800 }}>Configurar Porcentaje de Comisión</DialogTitle>
        <DialogContent dividers>
          <Grid container spacing={2} sx={{ mt: 0.5 }}>
            <Grid size={12}>
              <TextField fullWidth select label="Aseguradora">
                {insurers.map(ins => <MenuItem key={ins.id} value={ins.id}>{ins.razonSocial}</MenuItem>)}
              </TextField>
            </Grid>
            <Grid size={12}>
              <TextField fullWidth select label="Rubro">
                {RUBROS.map(r => <MenuItem key={r} value={r}>{r}</MenuItem>)}
              </TextField>
            </Grid>
            <Grid size={12}>
              <TextField 
                fullWidth 
                label="Porcentaje de Comisión" 
                type="number" 
                InputProps={{ endAdornment: <InputAdornment position="end">%</InputAdornment> }}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ p: 3 }}>
          <Button onClick={() => setOpenConfigDialog(false)} color="inherit">Cancelar</Button>
          <Button variant="contained" onClick={() => setOpenConfigDialog(false)}>Guardar Configuración</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
