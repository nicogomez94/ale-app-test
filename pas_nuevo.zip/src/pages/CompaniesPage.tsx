import React, { useState } from 'react';
import { 
  Box, 
  Typography, 
  Card, 
  CardContent, 
  Button, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow, 
  Paper, 
  IconButton, 
  TextField, 
  InputAdornment,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  Tabs,
  Tab,
  Chip,
  Collapse,
  MenuItem
} from '@mui/material';
import { 
  Plus, 
  Search, 
  Edit2, 
  Trash2, 
  Building2, 
  Download,
  Phone,
  Mail,
  MessageCircle,
  Users,
  Truck,
  Shield,
  Briefcase,
  Home,
  Store,
  ChevronDown,
  ChevronUp,
  FileText,
  CheckSquare,
  Square
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { useLocation } from 'react-router-dom';
import { PROVINCIAS_ARGENTINA } from '../constants';

export const CompaniesPage: React.FC<{
  policies: any[],
  onTogglePaid: (id: string) => void,
  onDeletePolicy: (id: string) => void,
  onUpdatePolicy: (policy: any) => void,
  user: any
}> = ({ policies, onTogglePaid, onDeletePolicy, onUpdatePolicy, user }) => {
  const location = useLocation();
  const [tab, setTab] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  const [open, setOpen] = useState(false);
  const [expandedRows, setExpandedRows] = useState<string[]>([]);
  const [editingCompany, setEditingCompany] = useState<any>(null);

  const toggleRow = (id: string) => {
    setExpandedRows(prev => 
      prev.includes(id) ? prev.filter(rowId => rowId !== id) : [...prev, id]
    );
  };

  const getPoliciesForCompany = (razonSocial: string) => {
    return policies.filter(p => p.cliente === razonSocial);
  };
  const [formValues, setFormValues] = useState<any>({
    razonSocial: '',
    cuit: '',
    aseguradora: '',
    ramo: '',
    email: '',
    telefono: '',
    direccion: '',
    altura: '',
    cp: '',
    provincia: '',
    localidad: '',
    detalle: '',
    empleados: '',
    vehiculos: ''
  });

  const capitalizeWords = (str: string) => {
    return str.toLowerCase().replace(/\b\w/g, (char) => char.toUpperCase());
  };

  const formatCUIT = (value: string) => {
    const digits = value.replace(/\D/g, '').slice(0, 11);
    if (digits.length <= 2) return digits;
    if (digits.length <= 10) return `${digits.slice(0, 2)}-${digits.slice(2)}`;
    return `${digits.slice(0, 2)}-${digits.slice(2, 10)}-${digits.slice(10)}`;
  };

  const handleInputChange = (field: string, value: string, shouldCapitalize = true) => {
    setFormValues(prev => ({
      ...prev,
      [field]: shouldCapitalize ? capitalizeWords(value) : value
    }));
  };

  const handleCUITChange = (value: string) => {
    setFormValues(prev => ({
      ...prev,
      cuit: formatCUIT(value)
    }));
  };

  React.useEffect(() => {
    if (location.state?.openNew) {
      handleOpen();
      // Clear state to avoid reopening on refresh
      window.history.replaceState({}, document.title);
    }
  }, [location.state]);

  const [companies, setCompanies] = useState([
    { id: '1', razonSocial: 'Tech Solutions S.A.', cuit: '30-12345678-9', empleados: 45, aseguradora: 'Prevención ART', email: 'rrhh@techsolutions.com', telefono: '1144556677', direccion: 'Av. Libertador 1000', cp: '1425', ramo: 'Tecnología', tipo: 'ART', provincia: 'Buenos Aires', localidad: 'CABA' },
    { id: '2', razonSocial: 'Logística Express', cuit: '30-98765432-1', empleados: 120, aseguradora: 'Experta ART', email: 'info@logistica.com', telefono: '1122334455', direccion: 'Ruta 8 Km 50', cp: '1629', ramo: 'Transporte', tipo: 'ART', provincia: 'Buenos Aires', localidad: 'Pilar' },
    { id: '3', razonSocial: 'Distribuidora Norte', cuit: '30-11223344-5', vehiculos: 12, aseguradora: 'Sancor Seguros', email: 'flota@distnorte.com', telefono: '1155667788', direccion: 'Pueyrredón 450', cp: '1032', ramo: 'Distribución', tipo: 'Flotas', provincia: 'Buenos Aires', localidad: 'San Isidro' },
    { id: '4', razonSocial: 'Fábrica Textil S.R.L.', cuit: '30-55667788-2', aseguradora: 'Allianz', email: 'ventas@textil.com', telefono: '1166778899', direccion: 'Warnes 1200', cp: '1414', ramo: 'Textil', tipo: 'TRO', provincia: 'Buenos Aires', localidad: 'CABA' },
    { id: '5', razonSocial: 'Edificio Sol Naciente', cuit: '30-99887766-4', aseguradora: 'Sancor Seguros', email: 'admin@solnaciente.com', telefono: '1133445566', direccion: 'Av. Santa Fe 2500', cp: '1425', ramo: 'Inmobiliario', tipo: 'Consorcio', provincia: 'Buenos Aires', localidad: 'CABA' },
    { id: '6', razonSocial: 'Supermercado Don Juan', cuit: '30-22334455-1', aseguradora: 'La Segunda', email: 'donjuan@gmail.com', telefono: '1177889900', direccion: 'Belgrano 300', cp: '1001', ramo: 'Retail', tipo: 'Integral de Comercio', provincia: 'Buenos Aires', localidad: 'CABA' },
    { id: '7', razonSocial: 'Constructora del Sur', cuit: '30-44556677-8', aseguradora: 'Sancor Seguros', email: 'obras@consur.com', telefono: '1188990011', direccion: 'Av. Juan B. Justo 500', cp: '1425', ramo: 'Construcción', tipo: 'Caucion', provincia: 'Buenos Aires', localidad: 'CABA', detalle: 'Garantía de Obra' },
  ]);

  const tabs = [
    { label: 'ART', icon: <Shield size={18} />, value: 'ART' },
    { label: 'Flotas', icon: <Truck size={18} />, value: 'Flotas' },
    { label: 'TRO', icon: <Briefcase size={18} />, value: 'TRO' },
    { label: 'Consorcio', icon: <Home size={18} />, value: 'Consorcio' },
    { label: 'Integral de Comercio', icon: <Store size={18} />, value: 'Integral de Comercio' },
    { label: 'Caución', icon: <FileText size={18} />, value: 'Caucion' },
  ];

  const handleOpen = (company?: any) => {
    if (company) {
      setEditingCompany(company);
      const parts = company.direccion.split(' ');
      const altura = parts.length > 1 ? parts.pop() : '';
      const calle = parts.join(' ');
      
      setFormValues({
        ...company,
        direccion: calle || company.direccion,
        altura: altura || ''
      });
    } else {
      setEditingCompany(null);
      setFormValues({
        razonSocial: '',
        cuit: '',
        aseguradora: '',
        ramo: '',
        email: '',
        telefono: '',
        direccion: '',
        altura: '',
        cp: '',
        provincia: '',
        localidad: '',
        detalle: '',
        empleados: '',
        vehiculos: ''
      });
    }
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setEditingCompany(null);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('¿Estás seguro de eliminar esta empresa?')) {
      setCompanies(companies.filter(c => c.id !== id));
    }
  };

  const handleWhatsApp = (telefono: string) => {
    const url = `https://wa.me/${telefono.replace(/\D/g, '')}`;
    window.open(url, '_blank');
  };

  const handleExport = () => {
    const currentType = tabs[tab].value;
    const data = companies.filter(c => c.tipo === currentType);
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, currentType);
    XLSX.writeFile(wb, `Empresas_${currentType}_PAS_Alert.xlsx`);
  };

  const currentType = tabs[tab].value;
  const filteredCompanies = companies.filter(c => 
    c.tipo === currentType && (
      c.razonSocial.toLowerCase().includes(searchTerm.toLowerCase()) || 
      c.cuit.includes(searchTerm)
    )
  );

  const handleSave = () => {
    const fullDireccion = `${formValues.direccion} ${formValues.altura}`.trim();
    const companyData = {
      ...formValues,
      direccion: fullDireccion,
      id: editingCompany?.id || Math.random().toString(36).substr(2, 9)
    };

    if (editingCompany) {
      setCompanies(companies.map(c => c.id === editingCompany.id ? companyData : c));
    } else {
      setCompanies([companyData, ...companies]);
    }
    handleClose();
  };

  return (
    <Box>
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 800 }}>Gestión de Empresas</Typography>
          <Typography variant="body1" color="text.secondary">Administra ART, Flotas, TRO, Consorcios, Integrales y Caución.</Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <Button 
            variant="outlined" 
            startIcon={<Download size={20} />}
            onClick={handleExport}
          >
            Exportar Excel
          </Button>
          <Button 
            variant="contained" 
            startIcon={<Plus size={20} />}
            onClick={() => handleOpen()}
            sx={{ borderRadius: 3 }}
          >
            Nueva Empresa
          </Button>
        </Box>
      </Box>

      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs 
          value={tab} 
          onChange={(_, newValue) => setTab(newValue)} 
          variant="scrollable"
          scrollButtons="auto"
          aria-label="tabs empresas"
        >
          {tabs.map((t, index) => (
            <Tab key={index} icon={t.icon} iconPosition="start" label={t.label} />
          ))}
        </Tabs>
      </Box>

      <Card sx={{ mb: 4 }}>
        <CardContent>
          <TextField
            fullWidth
            placeholder="Buscar por razón social o CUIT..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search size={20} />
                </InputAdornment>
              ),
            }}
          />
        </CardContent>
      </Card>

      <TableContainer component={Paper}>
        <Table>
          <TableHead sx={{ bgcolor: 'secondary.main' }}>
            <TableRow>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Razón Social</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Rubro / Actividad</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>CUIT</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>
                {currentType === 'ART' ? 'Empleados' : currentType === 'Flotas' ? 'Vehículos' : 'Detalle'}
              </TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Email</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Provincia</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Localidad</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>C.P.</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'right' }}>Acciones</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredCompanies.map((company) => {
              const companyPolicies = getPoliciesForCompany(company.razonSocial);
              const isExpanded = expandedRows.includes(company.id);
              
              return (
                <React.Fragment key={company.id}>
                  <TableRow hover>
                    <TableCell sx={{ fontWeight: 600 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <IconButton size="small" onClick={() => toggleRow(company.id)}>
                          {isExpanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                        </IconButton>
                        <Box>
                          <Typography variant="body2" sx={{ fontWeight: 700 }}>{company.razonSocial}</Typography>
                          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', fontWeight: 600 }}>
                            {companyPolicies.length} {companyPolicies.length === 1 ? 'Póliza' : 'Pólizas'}
                          </Typography>
                          <Chip 
                            label={company.aseguradora} 
                            size="small" 
                            sx={{ 
                              bgcolor: '#1a237e', 
                              color: 'white', 
                              fontWeight: 700, 
                              fontSize: '0.65rem',
                              height: 20,
                              mt: 0.5,
                              borderRadius: '4px'
                            }} 
                          />
                        </Box>
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Chip label={company.ramo} size="small" variant="outlined" sx={{ fontWeight: 600 }} />
                    </TableCell>
                    <TableCell>{company.cuit}</TableCell>
                    <TableCell>
                      {currentType === 'ART' || currentType === 'Flotas' ? (
                        (company as any).empleados || (company as any).vehiculos ? (
                          <Chip 
                            label={(company as any).empleados || (company as any).vehiculos} 
                            size="small" 
                            variant="outlined"
                            icon={currentType === 'ART' ? <Users size={14} /> : <Truck size={14} />}
                          />
                        ) : '-'
                      ) : (
                        (company as any).detalle || '-'
                      )}
                    </TableCell>
                    <TableCell>{company.email}</TableCell>
                    <TableCell>{company.provincia}</TableCell>
                    <TableCell>{company.localidad}</TableCell>
                    <TableCell>{company.cp}</TableCell>
                    <TableCell sx={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                      <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 0.5 }}>
                        <Button 
                          size="small" 
                          color="success" 
                          variant="outlined"
                          startIcon={<MessageCircle size={14} />}
                          onClick={() => handleWhatsApp(company.telefono)}
                          sx={{ fontSize: '0.65rem', py: 0.3, px: 1, minWidth: '90px', justifyContent: 'flex-start', fontWeight: 700 }}
                        >
                          WhatsApp
                        </Button>
                        <Button 
                          size="small" 
                          color="primary" 
                          variant="outlined"
                          startIcon={<Edit2 size={14} />}
                          onClick={() => handleOpen(company)}
                          sx={{ fontSize: '0.65rem', py: 0.3, px: 1, minWidth: '90px', justifyContent: 'flex-start', fontWeight: 700 }}
                        >
                          Modificar
                        </Button>
                        <Button 
                          size="small" 
                          color="info" 
                          variant="outlined"
                          startIcon={<Mail size={14} />}
                          onClick={() => window.location.href = `mailto:${company.email}`}
                          sx={{ fontSize: '0.65rem', py: 0.3, px: 1, minWidth: '90px', justifyContent: 'flex-start', fontWeight: 700 }}
                        >
                          Mail
                        </Button>
                        <Button 
                          size="small" 
                          color="error" 
                          variant="outlined"
                          startIcon={<Trash2 size={14} />}
                          onClick={() => handleDelete(company.id)}
                          sx={{ fontSize: '0.65rem', py: 0.3, px: 1, minWidth: '90px', justifyContent: 'flex-start', fontWeight: 700 }}
                        >
                          Eliminar
                        </Button>
                      </Box>
                    </TableCell>
                  </TableRow>
                  
                  <TableRow>
                    <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={9}>
                      <Collapse in={isExpanded} timeout="auto" unmountOnExit>
                        <Box sx={{ margin: 2, bgcolor: 'grey.50', p: 2, borderRadius: 2, border: '1px solid', borderColor: 'divider' }}>
                          <Typography variant="subtitle2" gutterBottom component="div" sx={{ fontWeight: 800, display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                            <FileText size={18} color="#1a237e" /> Detalle de Pólizas
                          </Typography>
                          {companyPolicies.length > 0 ? (
                            <Table size="small">
                              <TableHead sx={{ bgcolor: 'secondary.main' }}>
                                <TableRow>
                                  <TableCell sx={{ color: 'white', fontWeight: 700 }}>Póliza / Aseguradora</TableCell>
                                  <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center' }}>Inicio</TableCell>
                                  <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center' }}>Vencimiento</TableCell>
                                  <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center' }}>Vigencia</TableCell>
                                  <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center' }}>Cuota</TableCell>
                                  <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center' }}>Pagado</TableCell>
                                  <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center' }}>Última Gestión</TableCell>
                                  <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'right' }}>Acciones</TableCell>
                                </TableRow>
                              </TableHead>
                              <TableBody>
                                {companyPolicies.map((policy) => {
                                  return (
                                    <TableRow key={policy.id} hover>
                                      <TableCell sx={{ fontWeight: 600 }}>
                                        <Typography variant="body2" sx={{ fontWeight: 700 }}>N° {policy.poliza || 'S/N'}</Typography>
                                        <Chip 
                                          label={policy.aseguradora} 
                                          size="small" 
                                          sx={{ bgcolor: '#1a237e', color: 'white', fontWeight: 700, fontSize: '0.65rem', height: 20, mt: 0.5 }} 
                                        />
                                        <Typography variant="caption" display="block" color="text.secondary" sx={{ fontWeight: 700 }}>
                                          {policy.rubro || policy.tipo}
                                        </Typography>
                                      </TableCell>
                                      <TableCell sx={{ textAlign: 'center' }}>{policy.fechaInicio || '-'}</TableCell>
                                      <TableCell sx={{ textAlign: 'center' }}>{policy.vencimiento}</TableCell>
                                      <TableCell sx={{ textAlign: 'center' }}>
                                        <Chip 
                                          label={policy.estado === 'Activa' ? 'Vigente' : policy.estado} 
                                          size="small" 
                                          color={policy.estado === 'Activa' ? 'success' : 'error'}
                                          sx={{ fontWeight: 700, fontSize: '0.7rem', height: 20 }}
                                        />
                                      </TableCell>
                                      <TableCell sx={{ textAlign: 'center' }}>
                                        <Typography variant="body2" sx={{ fontWeight: 700, color: 'primary.main' }}>{policy.cuota || '1/1'}</Typography>
                                        <Typography variant="caption" sx={{ display: 'block', color: 'text.secondary' }}>{policy.medioPago || '-'}</Typography>
                                      </TableCell>
                                      <TableCell>
                                        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                                          <IconButton onClick={() => onTogglePaid(policy.id)} color={policy.pagada ? 'success' : 'default'}>
                                            {policy.pagada ? <CheckSquare size={20} /> : <Square size={20} />}
                                          </IconButton>
                                          {policy.pagada && (
                                            <Typography variant="caption">{policy.fechaPago || ''}</Typography>
                                          )}
                                        </Box>
                                      </TableCell>
                                      <TableCell sx={{ textAlign: 'center' }}>
                                        {policy.ultimaGestion ? (
                                          <Typography variant="caption" sx={{ fontWeight: 700 }}>
                                            {policy.ultimaGestion.tipo} ({policy.ultimaGestion.fecha})
                                          </Typography>
                                        ) : '-'}
                                      </TableCell>
                                      <TableCell sx={{ textAlign: 'right' }}>
                                        <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 0.5 }}>
                                          <IconButton size="small" color="primary" onClick={() => {}}>
                                            <Edit2 size={16} />
                                          </IconButton>
                                          <IconButton size="small" color="error" onClick={() => onDeletePolicy(policy.id)}>
                                            <Trash2 size={16} />
                                          </IconButton>
                                        </Box>
                                      </TableCell>
                                    </TableRow>
                                  );
                                })}
                              </TableBody>
                            </Table>
                          ) : (
                            <Typography variant="body2" color="text.secondary" sx={{ fontStyle: 'italic', textAlign: 'center', py: 2 }}>
                              No se encontraron pólizas registradas para esta empresa.
                            </Typography>
                          )}
                        </Box>
                      </Collapse>
                    </TableCell>
                  </TableRow>
                </React.Fragment>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
        <DialogTitle sx={{ fontWeight: 700 }}>
          {editingCompany ? 'Editar Empresa' : `Nueva Empresa (${currentType})`}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid size={{ xs: 12, md: 8 }}>
              <TextField 
                fullWidth 
                label="Razón Social" 
                value={formValues.razonSocial}
                onChange={(e) => handleInputChange('razonSocial', e.target.value)}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 4 }}>
              <TextField 
                fullWidth 
                label="CUIT" 
                value={formValues.cuit}
                onChange={(e) => handleCUITChange(e.target.value)}
              />
            </Grid>
            {(currentType === 'ART' || currentType === 'Flotas') ? (
              <Grid size={{ xs: 6, md: 4 }}>
                <TextField 
                  fullWidth 
                  label={currentType === 'ART' ? "Cantidad de Empleados" : "Cantidad de Vehículos"} 
                  type="number"
                  value={currentType === 'ART' ? formValues.empleados : formValues.vehiculos}
                  onChange={(e) => handleInputChange(currentType === 'ART' ? 'empleados' : 'vehiculos', e.target.value, false)}
                />
              </Grid>
            ) : (
              <Grid size={{ xs: 12, md: 4 }}>
                <TextField 
                  fullWidth 
                  label="Detalle" 
                  placeholder="Ej: Ubicación, características, etc."
                  value={formValues.detalle}
                  onChange={(e) => handleInputChange('detalle', e.target.value)}
                />
              </Grid>
            )}
            <Grid size={{ xs: 6, md: 4 }}>
              <TextField 
                fullWidth 
                label="Aseguradora" 
                value={formValues.aseguradora}
                onChange={(e) => handleInputChange('aseguradora', e.target.value)}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 4 }}>
              <TextField 
                fullWidth 
                label="Rubro / Actividad" 
                value={formValues.ramo}
                onChange={(e) => handleInputChange('ramo', e.target.value)}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <TextField 
                fullWidth 
                label="Email" 
                value={formValues.email}
                onChange={(e) => handleInputChange('email', e.target.value, false)}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <TextField 
                fullWidth 
                label="Teléfono" 
                value={formValues.telefono}
                onChange={(e) => handleInputChange('telefono', e.target.value, false)}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <TextField 
                fullWidth 
                label="Calle" 
                value={formValues.direccion}
                onChange={(e) => handleInputChange('direccion', e.target.value)}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 3 }}>
              <TextField 
                fullWidth 
                label="Número" 
                value={formValues.altura}
                onChange={(e) => handleInputChange('altura', e.target.value, false)}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 3 }}>
              <TextField 
                fullWidth 
                label="Código Postal" 
                value={formValues.cp}
                onChange={(e) => handleInputChange('cp', e.target.value, false)}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <TextField 
                fullWidth 
                select 
                label="Provincia" 
                value={formValues.provincia}
                onChange={(e) => handleInputChange('provincia', e.target.value, false)}
              >
                {PROVINCIAS_ARGENTINA.map((prov) => (
                  <MenuItem key={prov} value={prov}>
                    {prov}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <TextField 
                fullWidth 
                label="Localidad" 
                value={formValues.localidad}
                onChange={(e) => handleInputChange('localidad', e.target.value)}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ p: 3 }}>
          <Button onClick={handleClose}>Cancelar</Button>
          <Button variant="contained" onClick={handleSave}>Guardar Empresa</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
