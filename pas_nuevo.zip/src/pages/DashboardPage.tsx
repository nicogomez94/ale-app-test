import React, { useState } from 'react';
import { 
  Grid, 
  Typography, 
  Card, 
  CardContent, 
  Box, 
  LinearProgress,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  IconButton,
  Alert,
  Tooltip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Autocomplete
} from '@mui/material';
import { 
  FileCheck, 
  AlertCircle, 
  Clock, 
  DollarSign, 
  Users, 
  ArrowUpRight,
  Plus,
  MessageCircle,
  Mail,
  Edit2,
  Trash2,
  X,
  CheckSquare,
  Square,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { format, differenceInDays, parseISO, isBefore, isAfter, addDays } from 'date-fns';
import { useNavigate, useLocation } from 'react-router-dom';
import { PROVINCIAS_ARGENTINA, POLICY_CATEGORIES, ASEGURADORAS } from '../constants';
import { MOCK_POLICIES } from '../data/mockData';

const StatCard = ({ title, value, icon, color, subtitle }: any) => (
  <Card sx={{ height: '100%', position: 'relative', overflow: 'hidden' }}>
    <CardContent>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <Box>
          <Typography variant="overline" color="text.secondary" sx={{ fontWeight: 600, letterSpacing: 1 }}>
            {title}
          </Typography>
          <Typography variant="h4" sx={{ mt: 1, fontWeight: 700 }}>
            {value}
          </Typography>
        </Box>
        <Box sx={{ 
          p: 1.5, 
          borderRadius: 3, 
          bgcolor: `${color}.light`, 
          color: `${color}.main`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}>
          {icon}
        </Box>
      </Box>
      {subtitle && (
        <Typography variant="caption" color="text.secondary" sx={{ mt: 2, display: 'block' }}>
          {subtitle}
        </Typography>
      )}
    </CardContent>
  </Card>
);

const PolicyTable = ({ title, policies, onWhatsApp, onMail, onTogglePaid, onUpdatePaymentDate, onDelete, onEdit, expandedGroups, toggleGroup, headerColor = 'secondary.main' }: any) => (
  <Card sx={{ mb: 4 }}>
    <CardContent>
      <Box sx={{ mb: 3, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h6" sx={{ fontWeight: 700 }}>{title}</Typography>
        <Button size="small" endIcon={<ArrowUpRight size={16} />}>Ver todas</Button>
      </Box>
      <TableContainer component={Paper} elevation={0} sx={{ border: '1px solid', borderColor: 'divider' }}>
        <Table>
          <TableHead sx={{ bgcolor: headerColor }}>
            <TableRow>
              <TableCell sx={{ color: 'white', fontWeight: 700, whiteSpace: 'nowrap' }}>{title.includes('Empresas') ? 'Empresa' : 'Cliente'}</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center', whiteSpace: 'nowrap' }}>Inicio Vigencia</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center', whiteSpace: 'nowrap' }}>Vencimiento</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center' }}>Vigencia</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center' }}>Cuota</TableCell>
              {title.includes('Vida y Retiro') && (
                <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'right' }}>Detalle</TableCell>
              )}
              <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center' }}>Pagado</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center' }}>Última Gestión</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'right' }}>Acciones</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {(() => {
              // Group policies by groupId
              const groups: { [key: string]: any[] } = {};
              policies.forEach((p: any) => {
                const gId = p.groupId || p.id;
                if (!groups[gId]) groups[gId] = [];
                groups[gId].push(p);
              });

              return Object.entries(groups).map(([gId, groupPolicies]) => {
                const sortedGroup = groupPolicies.sort((a, b) => {
                  const cuotaA = parseInt(a.cuota?.split('/')[0] || '1');
                  const cuotaB = parseInt(b.cuota?.split('/')[0] || '1');
                  return cuotaA - cuotaB;
                });

                const today = new Date();
                let vigente = sortedGroup.find(p => {
                  const start = parseISO(p.fechaInicio || p.vencimiento);
                  const end = parseISO(p.vencimiento);
                  return (isBefore(start, today) || start.toDateString() === today.toDateString()) && 
                         (isAfter(end, today) || end.toDateString() === today.toDateString());
                });

                if (!vigente) vigente = sortedGroup.find(p => isAfter(parseISO(p.vencimiento), today));
                if (!vigente) vigente = sortedGroup[sortedGroup.length - 1];

                const isExpanded = expandedGroups.has(gId);
                const policiesToShow = isExpanded ? sortedGroup : [vigente];

                return policiesToShow.map((policy: any, index: number) => {
                  const daysLeft = differenceInDays(parseISO(policy.vencimiento), new Date());
                  let color = 'success.main';
                  if (daysLeft < 0) color = 'error.main';
                  else if (daysLeft <= 5) color = 'warning.main';

                  return (
                    <TableRow 
                      key={policy.id} 
                      hover
                      sx={{ 
                        bgcolor: policy.id === vigente?.id ? 'action.hover' : 'inherit',
                        borderLeft: policy.id === vigente?.id ? '4px solid' : 'none',
                        borderLeftColor: headerColor
                      }}
                    >
                      <TableCell sx={{ fontWeight: 600, whiteSpace: 'nowrap' }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          {index === 0 && sortedGroup.length > 1 && (
                            <IconButton size="small" onClick={() => toggleGroup(gId)}>
                              {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                            </IconButton>
                          )}
                          <Box>
                            <Typography variant="body2" sx={{ fontWeight: 700 }}>{policy.cliente}</Typography>
                            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', fontWeight: 600 }}>
                              Póliza: {policy.poliza || 'S/N'}
                            </Typography>
                            <Chip 
                              label={policy.aseguradora} 
                              size="small" 
                              sx={{ 
                                bgcolor: '#1a237e', 
                                color: 'white', 
                                fontWeight: 700, 
                                fontSize: '0.65rem',
                                height: 20,
                                mt: 0.5,
                                borderRadius: '4px'
                              }} 
                            />
                            {(policy.rubro || policy.tipo) && (
                              <Typography variant="caption" display="block" color="text.secondary" sx={{ fontWeight: 700, textTransform: 'uppercase' }}>
                                {policy.rubro || policy.tipo}
                              </Typography>
                            )}
                          </Box>
                        </Box>
                      </TableCell>
                      <TableCell sx={{ textAlign: 'center', whiteSpace: 'nowrap' }}>
                        {policy.fechaInicio ? format(parseISO(policy.fechaInicio), 'dd/MM/yyyy') : '-'}
                      </TableCell>
                      <TableCell sx={{ textAlign: 'center', whiteSpace: 'nowrap' }}>{format(parseISO(policy.vencimiento), 'dd/MM/yyyy')}</TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5, alignItems: 'center', minWidth: 100 }}>
                          <Chip 
                            label={policy.pagada ? 'PAGADO' : (daysLeft < 0 ? 'Vencida' : daysLeft <= 5 ? 'Vence pronto' : 'Vigente')} 
                            size="small" 
                            variant="filled" 
                            sx={{ 
                              fontWeight: 700, 
                              fontSize: '0.7rem', 
                              height: 20,
                              bgcolor: policy.pagada ? 'success.main' : (daysLeft < 0 ? 'error.main' : daysLeft <= 5 ? '#FFD700' : 'success.main'),
                              color: (daysLeft >= 0 && daysLeft <= 5 && !policy.pagada) ? 'black' : 'white'
                            }}
                          />
                          {!policy.pagada && (
                            <Typography variant="caption" sx={{ fontWeight: 800, color, textAlign: 'center', whiteSpace: 'nowrap' }}>
                              {daysLeft === 0 ? 'Hoy' : `${daysLeft} días`}
                            </Typography>
                          )}
                        </Box>
                      </TableCell>
                      <TableCell sx={{ textAlign: 'center' }}>
                        <Typography variant="body2" sx={{ fontWeight: 700, color: 'primary.main' }}>
                          {policy.cuota || '1/1'}
                        </Typography>
                        <Typography variant="caption" sx={{ display: 'block', color: 'text.secondary', fontWeight: 500 }}>
                          {policy.medioPago || '-'}
                        </Typography>
                      </TableCell>
                      {title.includes('Vida y Retiro') && (
                        <TableCell sx={{ textAlign: 'right' }}>
                          <Typography variant="body2" sx={{ fontWeight: 700, color: policy.tipo === 'Retiro' ? 'success.main' : 'inherit' }}>
                            {policy.tipo === 'Vida' ? `Suma: $ ${policy.sumaAsegurada?.toLocaleString()}` : `Fondo: $ ${policy.fondoAcumulado?.toLocaleString()}`}
                          </Typography>
                          <Typography variant="caption" sx={{ display: 'block', color: 'text.secondary', fontWeight: 500 }}>
                            {policy.tipo === 'Vida' ? `Prima: $ ${policy.prima?.toLocaleString()}` : `Aporte: $ ${policy.aporteMensual?.toLocaleString()}`}
                          </Typography>
                        </TableCell>
                      )}
                      <TableCell>
                        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 0.5, justifyContent: 'center' }}>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <IconButton 
                              onClick={() => onTogglePaid(policy.id)}
                              sx={{ 
                                color: policy.pagada ? 'success.main' : 'text.disabled',
                                p: 0.5
                              }}
                            >
                              {policy.pagada ? <CheckSquare size={24} /> : <Square size={24} />}
                            </IconButton>
                            <Typography 
                              variant="body2" 
                              sx={{ 
                                fontWeight: 700, 
                                color: policy.pagada ? 'success.main' : 'text.disabled',
                                minWidth: 25
                              }}
                            >
                              {policy.pagada ? 'SI' : 'NO'}
                            </Typography>
                          </Box>
                          {policy.pagada && (
                            <TextField
                              type="date"
                              size="small"
                              value={policy.fechaPago || ''}
                              onChange={(e) => onUpdatePaymentDate(policy.id, e.target.value)}
                              sx={{ 
                                '& .MuiInputBase-input': { 
                                  fontSize: '0.7rem', 
                                  p: '2px 4px',
                                  width: '100px'
                                } 
                              }}
                            />
                          )}
                        </Box>
                      </TableCell>
                      <TableCell>
                        {policy.ultimaGestion ? (
                          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5, alignItems: 'center' }}>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                              {policy.ultimaGestion.tipo === 'Whatsapp' ? (
                                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                                  <MessageCircle size={16} color="#25D366" fill="#25D366" fillOpacity={0.2} />
                                  <Typography variant="body2" sx={{ fontWeight: 700, color: '#25D366', whiteSpace: 'nowrap' }}>
                                    Whatsapp ({policy.ultimaGestion.whatsappCount})
                                  </Typography>
                                </Box>
                              ) : (
                                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                                  <Mail size={16} color="#0288d1" fill="#0288d1" fillOpacity={0.2} />
                                  <Typography variant="body2" sx={{ fontWeight: 700, color: '#0288d1', whiteSpace: 'nowrap' }}>
                                    Mail ({policy.ultimaGestion.mailCount})
                                  </Typography>
                                </Box>
                              )}
                            </Box>
                            <Typography variant="caption" sx={{ color: 'text.secondary', fontWeight: 500, whiteSpace: 'nowrap' }}>
                              {format(parseISO(policy.ultimaGestion.fecha), 'dd/MM/yyyy')}
                            </Typography>
                          </Box>
                        ) : (
                          <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center' }}>-</Typography>
                        )}
                      </TableCell>
                      <TableCell sx={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                        <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 0.5 }}>
                          <Button 
                            size="small" 
                            color="success" 
                            variant="outlined"
                            startIcon={<MessageCircle size={14} />}
                            onClick={() => onWhatsApp(policy)}
                            sx={{ fontSize: '0.65rem', py: 0.3, px: 1, minWidth: '90px', justifyContent: 'flex-start', fontWeight: 700 }}
                          >
                            WhatsApp
                          </Button>
                          <Button 
                            size="small" 
                            color="primary" 
                            variant="outlined"
                            startIcon={<Edit2 size={14} />}
                            onClick={() => onEdit(policy)}
                            sx={{ fontSize: '0.65rem', py: 0.3, px: 1, minWidth: '90px', justifyContent: 'flex-start', fontWeight: 700 }}
                          >
                            Modificar
                          </Button>
                          <Button 
                            size="small" 
                            color="info" 
                            variant="outlined"
                            startIcon={<Mail size={14} />}
                            onClick={() => onMail(policy)}
                            sx={{ fontSize: '0.65rem', py: 0.3, px: 1, minWidth: '90px', justifyContent: 'flex-start', fontWeight: 700 }}
                          >
                            Mail
                          </Button>
                          <Button 
                            size="small" 
                            color="error" 
                            variant="outlined"
                            startIcon={<Trash2 size={14} />}
                            onClick={() => onDelete(policy.id)}
                            sx={{ fontSize: '0.65rem', py: 0.3, px: 1, minWidth: '90px', justifyContent: 'flex-start', fontWeight: 700 }}
                          >
                            Eliminar
                          </Button>
                        </Box>
                      </TableCell>
                    </TableRow>
                  );
                });
              });
            })()}
          </TableBody>
        </Table>
      </TableContainer>
    </CardContent>
  </Card>
);

export const Dashboard: React.FC<{ 
  user?: any, 
  policies: any[], 
  onTogglePaid: (id: string) => void, 
  onUpdatePaymentDate: (id: string, date: string) => void,
  onDeletePolicy: (id: string) => void, 
  onUpdatePolicy: (policy: any) => void,
  clients: any[],
  setClients: React.Dispatch<React.SetStateAction<any[]>>
}> = ({ user, policies, onTogglePaid, onUpdatePaymentDate, onDeletePolicy, onUpdatePolicy, clients, setClients }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const filter = searchParams.get('filter');
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set());
  const [editingPolicy, setEditingPolicy] = useState<any>(null);
  const [editOpen, setEditOpen] = useState(false);
  const [formValues, setFormValues] = useState({
    cliente: '',
    cuit: '',
    telefono: '',
    rubro: '',
    fechaInicio: '',
    vencimiento: '',
    poliza: '',
    aseguradora: '',
    medioPago: '',
    aporteMensual: '',
    fondoAcumulado: '',
    prima: '',
    comisionPorcentaje: '',
    pagada: false,
    calle: '',
    numero: '',
    cp: '',
    provincia: '',
    localidad: ''
  });
  const [manualVencimiento, setManualVencimiento] = useState(false);

  const capitalizeWords = (str: string) => {
    return str.toLowerCase().replace(/\b\w/g, (char) => char.toUpperCase());
  };

  const formatDNIorCUIT = (value: string) => {
    const digits = value.replace(/\D/g, '');
    if (digits.length <= 8) {
      return digits.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    }
    if (digits.length <= 10) return `${digits.slice(0, 2)}-${digits.slice(2)}`;
    return `${digits.slice(0, 2)}-${digits.slice(2, 10)}-${digits.slice(10)}`;
  };

  const formatWithDots = (val: string) => {
    const clean = val.replace(/\D/g, '');
    if (!clean) return '';
    const stripped = clean.replace(/^0+(?!$)/, '');
    return stripped.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  };

  const unformat = (val: string) => {
    if (typeof val !== 'string') return val;
    return val.replace(/\./g, '');
  };

  const toggleGroup = (groupId: string) => {
    const newExpanded = new Set(expandedGroups);
    if (newExpanded.has(groupId)) {
      newExpanded.delete(groupId);
    } else {
      newExpanded.add(groupId);
    }
    setExpandedGroups(newExpanded);
  };

  const handleEdit = (policy: any) => {
    setEditingPolicy(policy);
    setManualVencimiento(false);
    
    const client = clients.find(c => c.nombre === policy.cliente);
    
    setFormValues({
      cliente: policy.cliente || '',
      cuit: policy.cuit || '',
      telefono: policy.telefono || '',
      rubro: policy.rubro || '',
      fechaInicio: policy.fechaInicio || '',
      vencimiento: policy.vencimiento || '',
      poliza: policy.poliza || '',
      aseguradora: policy.aseguradora || '',
      medioPago: policy.medioPago || '',
      aporteMensual: policy.aporteMensual ? policy.aporteMensual.toString() : '',
      fondoAcumulado: policy.fondoAcumulado ? policy.fondoAcumulado.toString() : '',
      prima: policy.prima ? policy.prima.toString() : '',
      comisionPorcentaje: policy.comisionPorcentaje ? policy.comisionPorcentaje.toString() : '',
      pagada: policy.pagada || false,
      calle: client?.direccion || '',
      numero: client?.altura || '',
      cp: client?.cp || policy.cp || '',
      provincia: client?.provincia || '',
      localidad: client?.localidad || ''
    });
    setEditOpen(true);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormValues(prev => {
      let finalValue = type === 'checkbox' ? checked : value;
      
      if (typeof finalValue === 'string') {
        if (['cliente', 'rubro', 'aseguradora'].includes(name)) {
          finalValue = capitalizeWords(finalValue);
        }
        if (name === 'cuit') {
          finalValue = formatDNIorCUIT(finalValue);
        }
        if (['prima', 'aporteMensual', 'fondoAcumulado', 'comisionPorcentaje'].includes(name)) {
          finalValue = formatWithDots(finalValue);
        }
      }

      const newValues = { ...prev, [name]: finalValue };
      
      if (name === 'fechaInicio' && !manualVencimiento) {
        newValues.vencimiento = format(addDays(parseISO(value), 30), 'yyyy-MM-dd');
      }
      
      if (name === 'vencimiento') {
        setManualVencimiento(true);
      }
      
      return newValues;
    });
  };

  const handleSaveEdit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    // Determine policy type based on category
    let tipo = editingPolicy.tipo;
    const selectedRubro = formValues.rubro;
    
    const categoryObj = POLICY_CATEGORIES.find(cat => cat.items.includes(selectedRubro));
    const categoryName = categoryObj?.category || '';

    if (categoryName.includes('SEGUROS DE PERSONAS')) {
      tipo = 'Vida';
    } else if (categoryName.includes('SEGUROS DE RETIRO')) {
      tipo = 'Retiro';
    } else if (
      categoryName.includes('SEGUROS EMPRESARIALES') || 
      categoryName.includes('SEGUROS TÉCNICOS') || 
      categoryName.includes('RIESGOS DEL TRABAJO') ||
      categoryName.includes('SEGUROS FINANCIEROS') ||
      selectedRubro === 'Flotas vehiculares'
    ) {
      tipo = 'Empresa';
    } else {
      tipo = 'Individual';
    }

    const updatedPolicy = {
      ...editingPolicy,
      cliente: formValues.cliente,
      cuit: formValues.cuit,
      telefono: formValues.telefono,
      rubro: formValues.rubro,
      fechaInicio: formValues.fechaInicio,
      vencimiento: formValues.vencimiento,
      poliza: formValues.poliza,
      aseguradora: formValues.aseguradora,
      medioPago: formValues.medioPago,
      prima: Number(unformat(formValues.prima)),
      comisionPorcentaje: Number(unformat(formValues.comisionPorcentaje)),
      aporteMensual: tipo === 'Retiro' ? Number(unformat(formValues.aporteMensual)) : editingPolicy.aporteMensual,
      fondoAcumulado: tipo === 'Retiro' ? Number(unformat(formValues.fondoAcumulado)) : editingPolicy.fondoAcumulado,
      pagada: formValues.pagada,
      tipo
    };

    // Check if client exists, if not add to clients list
    const existingClient = clients.find(c => c.nombre === updatedPolicy.cliente);
    if (!existingClient) {
      const newClient = {
        id: Math.random().toString(36).substr(2, 9),
        nombre: updatedPolicy.cliente,
        dni: updatedPolicy.cuit,
        telefono: updatedPolicy.telefono,
        email: '',
        direccion: formValues.calle || '',
        altura: formValues.numero || '',
        cp: formValues.cp || '',
        provincia: formValues.provincia || '',
        localidad: formValues.localidad || ''
      };
      setClients(prev => [newClient, ...prev]);
    }

    if (updatedPolicy.pagada !== editingPolicy.pagada) {
      onTogglePaid(editingPolicy.id);
    } else {
      onUpdatePolicy(updatedPolicy);
    }
    setEditOpen(false);
    setEditingPolicy(null);
  };

  const handleWhatsApp = (policy: any) => {
    const pasName = user?.nombre || 'Tu Productor';
    const message = `Hola ${policy.cliente}, te informamos que tu póliza N° ${policy.poliza} vence el día ${format(parseISO(policy.vencimiento), 'dd/MM/yyyy')}. Por favor, contáctanos para renovarla. Saludos, ${pasName} - PAS Alert.`;
    const url = `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  const handleMail = (policy: any) => {
    const pasName = user?.nombre || 'Tu Productor';
    const subject = encodeURIComponent(`Vencimiento de Póliza - ${policy.aseguradora}`);
    const body = encodeURIComponent(`Hola ${policy.cliente},\n\nTe informamos que tu póliza N° ${policy.poliza} vence el día ${format(parseISO(policy.vencimiento), 'dd/MM/yyyy')}.\n\nPor favor, contáctanos para renovarla.\n\nSaludos,\n${pasName}\nPAS Alert`);
    window.location.href = `mailto:?subject=${subject}&body=${body}`;
  };

  let filteredPolicies = [...policies];
  if (filter === 'expiring') {
    filteredPolicies = filteredPolicies.filter(p => {
      const daysLeft = differenceInDays(parseISO(p.vencimiento), new Date());
      return daysLeft >= 0 && daysLeft <= 5;
    });
  }

  const individualPolicies = filteredPolicies.filter(p => p.tipo === 'Individual');
  const companyPolicies = filteredPolicies.filter(p => p.tipo === 'Empresa');
  const lifeFinancePolicies = filteredPolicies.filter(p => p.tipo === 'Vida' || p.tipo === 'Retiro');

  const stats = [
    { title: 'Pólizas Activas', value: '124', icon: <FileCheck size={24} />, color: 'primary', subtitle: '+12 este mes' },
    { title: 'Vencen en 7 días', value: '8', icon: <Clock size={24} />, color: 'warning', subtitle: 'Requieren atención' },
    { title: 'Pólizas Vencidas', value: '3', icon: <AlertCircle size={24} />, color: 'error', subtitle: 'Acción inmediata' },
    { title: 'Clientes Totales', value: '118', icon: <Users size={24} />, color: 'info', subtitle: 'Cartera activa' },
  ];

  const rubroOptions = POLICY_CATEGORIES.flatMap(cat => cat.items.map(item => ({
    label: item,
    category: cat.category
  })));

  return (
    <Box>
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box>
          <Typography variant="h4" gutterBottom sx={{ fontWeight: 800 }}>
            Panel de Control
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Bienvenido de nuevo. Aquí tienes un resumen de tu actividad.
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 2 }}>
          {filter === 'expiring' && (
            <Button 
              variant="outlined" 
              color="error"
              startIcon={<X size={20} />}
              onClick={() => navigate('/')}
            >
              Quitar Filtro
            </Button>
          )}
          <Button 
            variant="contained" 
            startIcon={<Plus size={20} />}
            onClick={() => navigate('/polizas')}
            sx={{ px: 3, py: 1.5, borderRadius: 3 }}
          >
            Nueva Póliza
          </Button>
        </Box>
      </Box>

      {filter === 'expiring' && (
        <Box sx={{ mb: 3 }}>
          <Alert severity="warning" sx={{ borderRadius: 2 }}>
            Mostrando solo pólizas que vencen en los próximos 5 días.
          </Alert>
        </Box>
      )}

      <Grid container spacing={3} sx={{ mb: 4 }}>
        {stats.map((stat, index) => (
          <Grid size={{ xs: 12, sm: 6, md: 3 }} key={index}>
            <StatCard {...stat} />
          </Grid>
        ))}
      </Grid>

      <Grid container spacing={3}>
        <Grid size={{ xs: 12 }}>
          <PolicyTable 
            title="Gestión de Pólizas de Clientes" 
            policies={individualPolicies} 
            onWhatsApp={handleWhatsApp} 
            onMail={handleMail}
            onTogglePaid={onTogglePaid}
            onUpdatePaymentDate={onUpdatePaymentDate}
            onDelete={onDeletePolicy}
            onEdit={handleEdit}
            expandedGroups={expandedGroups}
            toggleGroup={toggleGroup}
            headerColor="primary.main"
          />
          <PolicyTable 
            title="Gestión de Pólizas de Empresas" 
            policies={companyPolicies} 
            onWhatsApp={handleWhatsApp} 
            onMail={handleMail}
            onTogglePaid={onTogglePaid}
            onUpdatePaymentDate={onUpdatePaymentDate}
            onDelete={onDeletePolicy}
            onEdit={handleEdit}
            expandedGroups={expandedGroups}
            toggleGroup={toggleGroup}
            headerColor="secondary.main"
          />
          <PolicyTable 
            title="Gestión de Pólizas de Vida y Retiro" 
            policies={lifeFinancePolicies} 
            onWhatsApp={handleWhatsApp} 
            onMail={handleMail}
            onTogglePaid={onTogglePaid}
            onUpdatePaymentDate={onUpdatePaymentDate}
            onDelete={onDeletePolicy}
            onEdit={handleEdit}
            expandedGroups={expandedGroups}
            toggleGroup={toggleGroup}
            headerColor="error.main"
          />
        </Grid>
      </Grid>

      <Dialog open={editOpen} onClose={() => setEditOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ fontWeight: 800 }}>Editar Póliza</DialogTitle>
        <form onSubmit={handleSaveEdit}>
          <DialogContent>
            <Grid container spacing={2}>
              <Grid size={{ xs: 12, sm: 6 }}>
                <Autocomplete
                  freeSolo
                  options={clients.map(c => c.nombre)}
                  value={formValues.cliente}
                  onChange={(_, value) => {
                    const selectedClient = clients.find(c => c.nombre === value);
                    if (selectedClient) {
                      setFormValues(prev => ({
                        ...prev,
                        cliente: selectedClient.nombre,
                        cuit: selectedClient.dni,
                        telefono: selectedClient.telefono,
                        calle: selectedClient.direccion || '',
                        numero: selectedClient.altura || '',
                        cp: selectedClient.cp || '',
                        provincia: selectedClient.provincia || '',
                        localidad: selectedClient.localidad || ''
                      }));
                    } else {
                      setFormValues(prev => ({ ...prev, cliente: value || '' }));
                    }
                  }}
                  onInputChange={(_, value) => setFormValues(prev => ({ ...prev, cliente: value }))}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      fullWidth
                      label="Cliente"
                      name="cliente"
                    />
                  )}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 3 }}>
                <TextField
                  fullWidth
                  label="DNI/CUIT"
                  name="cuit"
                  value={formValues.cuit}
                  onChange={handleInputChange}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 3 }}>
                <TextField
                  fullWidth
                  label="Teléfono"
                  name="telefono"
                  value={formValues.telefono}
                  onChange={handleInputChange}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <TextField
                  fullWidth
                  label="Calle"
                  name="calle"
                  value={formValues.calle}
                  onChange={handleInputChange}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 2 }}>
                <TextField
                  fullWidth
                  label="N°"
                  name="numero"
                  value={formValues.numero}
                  onChange={handleInputChange}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 4 }}>
                <TextField
                  fullWidth
                  label="C.P."
                  name="cp"
                  value={formValues.cp}
                  onChange={handleInputChange}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <Autocomplete
                  options={PROVINCIAS_ARGENTINA}
                  value={formValues.provincia}
                  onChange={(_, value) => setFormValues(prev => ({ ...prev, provincia: value || '' }))}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      fullWidth
                      label="Provincia"
                      name="provincia"
                    />
                  )}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <TextField
                  fullWidth
                  label="Localidad"
                  name="localidad"
                  value={formValues.localidad}
                  onChange={handleInputChange}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <Autocomplete
                  freeSolo
                  options={rubroOptions}
                  groupBy={(option) => (typeof option === 'string' ? 'Otros' : option.category)}
                  getOptionLabel={(option) => (typeof option === 'string' ? option : option.label)}
                  value={rubroOptions.find(r => r.label === formValues.rubro) || formValues.rubro}
                  onChange={(_, value) => {
                    const label = typeof value === 'string' ? value : value?.label;
                    setFormValues(prev => ({ ...prev, rubro: label || '' }));
                  }}
                  onInputChange={(_, value) => setFormValues(prev => ({ ...prev, rubro: value || '' }))}
                  renderInput={(params) => (
                    <TextField {...params} label="Rubro" name="rubro" />
                  )}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <Autocomplete
                  freeSolo
                  options={ASEGURADORAS}
                  value={formValues.aseguradora}
                  onChange={(_, value) => setFormValues(prev => ({ ...prev, aseguradora: value || '' }))}
                  onInputChange={(_, value) => setFormValues(prev => ({ ...prev, aseguradora: value || '' }))}
                  renderInput={(params) => (
                    <TextField {...params} label="Aseguradora" name="aseguradora" />
                  )}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <TextField
                  fullWidth
                  label="Número de Póliza"
                  name="poliza"
                  value={formValues.poliza}
                  onChange={handleInputChange}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <TextField
                  fullWidth
                  label="Fecha de Inicio"
                  name="fechaInicio"
                  type="date"
                  value={formValues.fechaInicio}
                  onChange={handleInputChange}
                  InputLabelProps={{ shrink: true }}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <TextField
                  fullWidth
                  label="Fecha de Vencimiento"
                  name="vencimiento"
                  type="date"
                  value={formValues.vencimiento}
                  onChange={handleInputChange}
                  InputLabelProps={{ shrink: true }}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <TextField
                  fullWidth
                  label="Medio de Pago"
                  name="medioPago"
                  value={formValues.medioPago}
                  onChange={handleInputChange}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 3 }}>
                <TextField
                  fullWidth
                  label="Prima"
                  name="prima"
                  value={formValues.prima}
                  onChange={handleInputChange}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 3 }}>
                <TextField
                  fullWidth
                  label="Comisión %"
                  name="comisionPorcentaje"
                  value={formValues.comisionPorcentaje}
                  onChange={handleInputChange}
                />
              </Grid>
              <Grid size={{ xs: 12 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <IconButton 
                    onClick={() => setFormValues(prev => ({ ...prev, pagada: !prev.pagada }))}
                    sx={{ color: formValues.pagada ? 'success.main' : 'text.disabled' }}
                  >
                    {formValues.pagada ? <CheckSquare size={24} /> : <Square size={24} />}
                  </IconButton>
                  <Typography variant="body1" sx={{ fontWeight: 600 }}>
                    Marcar como Pagada
                  </Typography>
                </Box>
              </Grid>
              {editingPolicy?.tipo === 'Retiro' && (
                <>
                  <Grid size={{ xs: 12, sm: 6 }}>
                    <TextField
                      fullWidth
                      label="Aporte Mensual"
                      name="aporteMensual"
                      value={formValues.aporteMensual}
                      onChange={handleInputChange}
                    />
                  </Grid>
                  <Grid size={{ xs: 12, sm: 6 }}>
                    <TextField
                      fullWidth
                      label="Fondo Acumulado"
                      name="fondoAcumulado"
                      value={formValues.fondoAcumulado}
                      onChange={handleInputChange}
                    />
                  </Grid>
                </>
              )}
            </Grid>
          </DialogContent>
          <DialogActions sx={{ p: 3 }}>
            <Button onClick={() => setEditOpen(false)}>Cancelar</Button>
            <Button type="submit" variant="contained">Guardar Cambios</Button>
          </DialogActions>
        </form>
      </Dialog>
    </Box>
  );
};
