import React, { useState } from 'react';
import { 
  Box, 
  Card, 
  CardContent, 
  Typography, 
  Grid, 
  Button, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow, 
  Paper, 
  TextField, 
  InputAdornment,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  MenuItem,
  IconButton,
  Tooltip,
  Chip,
  Checkbox,
  FormControlLabel,
  Divider,
  ListItemText
} from '@mui/material';
import { 
  Search, 
  Plus, 
  Globe, 
  Mail, 
  Phone, 
  Building, 
  ShieldCheck,
  ExternalLink,
  Edit,
  Trash2,
  MapPin,
  FileText,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  Circle,
  DollarSign,
  Receipt,
  Users as UsersIcon,
  Palette
} from 'lucide-react';
import { Collapse, Tabs, Tab, Select, OutlinedInput, Box as MuiBox } from '@mui/material';

import { InsuranceCompany, CommissionInvoice } from '../types';

interface Broker {
  id: string;
  nombre: string;
  color: string;
  aseguradorasIds: string[];
  contacto?: string;
  mail?: string;
}

export const InsuranceCompaniesPage: React.FC<{ insurers: InsuranceCompany[], setInsurers: React.Dispatch<React.SetStateAction<InsuranceCompany[]>> }> = ({ insurers, setInsurers }) => {
  const [tabValue, setTabValue] = useState(0);
  const [brokers, setBrokers] = useState<Broker[]>([
    { id: 'b1', nombre: 'Broker Norte', color: '#1a237e', aseguradorasIds: ['1', '2'], contacto: 'Juan Broker', mail: 'norte@broker.com' },
    { id: 'b2', nombre: 'Organización Sur', color: '#10b981', aseguradorasIds: ['3'], contacto: 'Maria Org', mail: 'sur@org.com' }
  ]);
  const [searchTerm, setSearchTerm] = useState('');
  const [openDialog, setOpenDialog] = useState(false);
  const [openBrokerDialog, setOpenBrokerDialog] = useState(false);
  const [expandedRows, setExpandedRows] = useState<string[]>([]);
  const [editingInsurer, setEditingInsurer] = useState<InsuranceCompany | null>(null);
  const [editingBroker, setEditingBroker] = useState<Broker | null>(null);
  
  const [brokerFormData, setBrokerFormData] = useState<Partial<Broker>>({
    nombre: '',
    color: '#1a237e',
    aseguradorasIds: [],
    contacto: '',
    mail: ''
  });

  const BROKER_COLORS = [
    '#1a237e', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#0ea5e9', '#64748b'
  ];
  const [formData, setFormData] = useState<Partial<InsuranceCompany>>({
    razonSocial: '',
    domicilioComercial: '',
    cuit: '',
    condicionIva: 'Responsable Inscripto',
    mail: '',
    telefono: '',
    urlWeb: '',
    usuario: '',
    password: '',
    codigoCliente: '',
    notas: ''
  });

  const toggleRow = (id: string) => {
    setExpandedRows(prev => 
      prev.includes(id) ? prev.filter(rowId => rowId !== id) : [...prev, id]
    );
  };

  const calculateTotals = () => {
    let totalArs = 0;
    let totalUsd = 0;
    let invoiceCount = 0;

    insurers.forEach(insurer => {
      (insurer.facturacionComisiones || []).forEach(invoice => {
        if (invoice.moneda === 'ARS') totalArs += invoice.montoFacturado;
        else totalUsd += invoice.montoFacturado;
        invoiceCount++;
      });
    });

    return { totalArs, totalUsd, invoiceCount };
  };

  const { totalArs, totalUsd, invoiceCount } = calculateTotals();

  const filteredInsurers = insurers.filter(insurer => 
    insurer.razonSocial.toLowerCase().includes(searchTerm.toLowerCase()) ||
    insurer.cuit.includes(searchTerm)
  );

  const handleOpenDialog = (insurer?: InsuranceCompany) => {
    if (insurer) {
      setEditingInsurer(insurer);
      setFormData(insurer);
    } else {
      setEditingInsurer(null);
      setFormData({
        razonSocial: '',
        domicilioComercial: '',
        cuit: '',
        condicionIva: 'Responsable Inscripto',
        mail: '',
        telefono: '',
        urlWeb: '',
        usuario: '',
        password: '',
        codigoCliente: '',
        notas: ''
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleSave = () => {
    if (editingInsurer) {
      setInsurers(prev => prev.map(i => i.id === editingInsurer.id ? { ...i, ...formData } as InsuranceCompany : i));
    } else {
      const newInsurer: InsuranceCompany = {
        ...formData,
        id: Math.random().toString(36).substr(2, 9)
      } as InsuranceCompany;
      setInsurers(prev => [...prev, newInsurer]);
    }
    handleCloseDialog();
  };

  const handleDelete = (id: string) => {
    if (window.confirm('¿Estás seguro de que deseas eliminar esta aseguradora?')) {
      setInsurers(prev => prev.filter(i => i.id !== id));
    }
  };

  const handleAccessWeb = (url: string) => {
    if (url) {
      const fullUrl = url.startsWith('http') ? url : `https://${url}`;
      window.open(fullUrl, '_blank');
    }
  };

  const handleOpenBrokerDialog = (broker?: Broker) => {
    if (broker) {
      setEditingBroker(broker);
      setBrokerFormData(broker);
    } else {
      setEditingBroker(null);
      setBrokerFormData({
        nombre: '',
        color: BROKER_COLORS[0],
        aseguradorasIds: [],
        contacto: '',
        mail: ''
      });
    }
    setOpenBrokerDialog(true);
  };

  const handleSaveBroker = () => {
    if (editingBroker) {
      setBrokers(prev => prev.map(b => b.id === editingBroker.id ? { ...b, ...brokerFormData } as Broker : b));
    } else {
      const newBroker: Broker = {
        ...brokerFormData,
        id: Math.random().toString(36).substr(2, 9)
      } as Broker;
      setBrokers(prev => [...prev, newBroker]);
    }
    setOpenBrokerDialog(false);
  };

  const handleDeleteBroker = (id: string) => {
    if (window.confirm('¿Estás seguro de que deseas eliminar este broker?')) {
      setBrokers(prev => prev.filter(b => b.id !== id));
    }
  };

  return (
    <Box>
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 800, color: 'primary.main' }}>Compañias y Brokers</Typography>
          <Typography variant="body1" color="text.secondary">Registro de compañías, brokers y comisiones</Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 2 }}>
          {tabValue === 0 ? (
            <Button 
              variant="contained" 
              startIcon={<Plus size={20} />}
              onClick={() => handleOpenDialog()}
              sx={{ borderRadius: 3, px: 3, py: 1.5, fontWeight: 700 }}
            >
              Nueva Aseguradora
            </Button>
          ) : (
            <Button 
              variant="contained" 
              color="secondary"
              startIcon={<Plus size={20} />}
              onClick={() => handleOpenBrokerDialog()}
              sx={{ borderRadius: 3, px: 3, py: 1.5, fontWeight: 700 }}
            >
              Nuevo Broker / Org.
            </Button>
          )}
        </Box>
      </Box>

      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 4 }}>
        <Tabs value={tabValue} onChange={(_, v) => setTabValue(v)}>
          <Tab label="Aseguradoras" sx={{ fontWeight: 700 }} />
          <Tab label="Brokers / Organizadores" sx={{ fontWeight: 700 }} />
        </Tabs>
      </Box>

      {tabValue === 0 ? (
        <>
      <Card sx={{ mb: 4 }}>
        <CardContent>
          <TextField
            fullWidth
            placeholder="Buscar por razón social o CUIT..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search size={20} />
                </InputAdornment>
              ),
            }}
          />
        </CardContent>
      </Card>

      <TableContainer component={Paper} sx={{ borderRadius: 3, boxShadow: '0 4px 20px rgba(0,0,0,0.05)' }}>
        <Table>
          <TableHead sx={{ bgcolor: 'primary.main' }}>
            <TableRow>
              <TableCell sx={{ width: 50 }} />
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Razón Social</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>CUIT</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Condición IVA</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Contacto</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Web</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'right' }}>Acciones</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredInsurers.map((insurer) => (
              <React.Fragment key={insurer.id}>
                <TableRow hover>
                  <TableCell>
                    <IconButton size="small" onClick={() => toggleRow(insurer.id)}>
                      {expandedRows.includes(insurer.id) ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                    </IconButton>
                  </TableCell>
                  <TableCell>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                      <Box sx={{ 
                        width: 40, 
                        height: 40, 
                        bgcolor: 'primary.light', 
                        borderRadius: 2, 
                        display: 'flex', 
                        alignItems: 'center', 
                        justifyContent: 'center',
                        color: 'primary.main'
                      }}>
                        <ShieldCheck size={24} />
                      </Box>
                      <Box>
                        <Typography variant="body2" sx={{ fontWeight: 700 }}>{insurer.razonSocial}</Typography>
                        <Typography variant="caption" color="text.secondary" sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <MapPin size={12} /> {insurer.domicilioComercial}
                        </Typography>
                      </Box>
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2" sx={{ fontWeight: 600 }}>{insurer.cuit}</Typography>
                  </TableCell>
                  <TableCell>
                    <Chip 
                      label={insurer.condicionIva} 
                      size="small" 
                      variant="outlined" 
                      sx={{ fontWeight: 600, borderColor: 'primary.main', color: 'primary.main' }} 
                    />
                  </TableCell>
                  <TableCell>
                    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
                      <Typography variant="caption" sx={{ display: 'flex', alignItems: 'center', gap: 0.5, fontWeight: 500 }}>
                        <Mail size={12} /> {insurer.mail}
                      </Typography>
                      <Typography variant="caption" sx={{ display: 'flex', alignItems: 'center', gap: 0.5, fontWeight: 500 }}>
                        <Phone size={12} /> {insurer.telefono}
                      </Typography>
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Button 
                      size="small" 
                      variant="outlined" 
                      startIcon={<Globe size={14} />}
                      onClick={() => handleAccessWeb(insurer.urlWeb)}
                      sx={{ borderRadius: 2, textTransform: 'none', fontWeight: 600 }}
                    >
                      Acceder Web
                    </Button>
                  </TableCell>
                  <TableCell sx={{ textAlign: 'right' }}>
                    <Tooltip title="Editar">
                      <IconButton size="small" onClick={() => handleOpenDialog(insurer)} color="primary">
                        <Edit size={18} />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Eliminar">
                      <IconButton size="small" onClick={() => handleDelete(insurer.id)} color="error">
                        <Trash2 size={18} />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={7}>
                    <Collapse in={expandedRows.includes(insurer.id)} timeout="auto" unmountOnExit>
                      <Box sx={{ margin: 2, p: 3, bgcolor: 'background.default', borderRadius: 2 }}>
                        <Typography variant="subtitle1" sx={{ fontWeight: 800, color: 'primary.main', mb: 2 }}>
                          Información Detallada - {insurer.razonSocial}
                        </Typography>
                        <Grid container spacing={3}>
                          <Grid size={{ xs: 12, md: 4 }}>
                            <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 700, textTransform: 'uppercase' }}>Datos Fiscales</Typography>
                            <Box sx={{ mt: 1 }}>
                              <Typography variant="body2"><strong>CUIT:</strong> {insurer.cuit}</Typography>
                              <Typography variant="body2"><strong>Condición IVA:</strong> {insurer.condicionIva}</Typography>
                              <Typography variant="body2"><strong>Domicilio:</strong> {insurer.domicilioComercial}</Typography>
                            </Box>
                          </Grid>
                          <Grid size={{ xs: 12, md: 4 }}>
                            <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 700, textTransform: 'uppercase' }}>Contacto</Typography>
                            <Box sx={{ mt: 1 }}>
                              <Typography variant="body2"><strong>Email:</strong> {insurer.mail}</Typography>
                              <Typography variant="body2"><strong>Teléfono:</strong> {insurer.telefono}</Typography>
                              <Typography variant="body2"><strong>Web:</strong> {insurer.urlWeb}</Typography>
                            </Box>
                          </Grid>
                          <Grid size={{ xs: 12, md: 4 }}>
                            <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 700, textTransform: 'uppercase' }}>Acceso y Notas</Typography>
                            <Box sx={{ mt: 1 }}>
                              <Typography variant="body2"><strong>Usuario:</strong> {insurer.usuario || '-'}</Typography>
                              <Typography variant="body2"><strong>Contraseña:</strong> {insurer.password || '-'}</Typography>
                              <Typography variant="body2"><strong>Cód. Cliente:</strong> {insurer.codigoCliente || '-'}</Typography>
                              <Typography variant="body2" sx={{ mt: 1, whiteSpace: 'pre-wrap' }}><strong>Notas:</strong> {insurer.notas || '-'}</Typography>
                            </Box>
                          </Grid>
                        </Grid>
                      </Box>
                    </Collapse>
                  </TableCell>
                </TableRow>
              </React.Fragment>
            ))}
            {filteredInsurers.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} sx={{ py: 8, textAlign: 'center' }}>
                  <Typography variant="body1" color="text.secondary">No se encontraron aseguradoras</Typography>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

        </>
      ) : (
        <Box>
          <Card sx={{ mb: 4 }}>
            <CardContent>
              <TextField
                fullWidth
                placeholder="Buscar broker por nombre..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <Search size={20} />
                    </InputAdornment>
                  ),
                }}
              />
            </CardContent>
          </Card>

          <Grid container spacing={3}>
            {brokers.filter(b => b.nombre.toLowerCase().includes(searchTerm.toLowerCase())).map((broker) => (
              <Grid size={{ xs: 12, md: 6 }} key={broker.id}>
                <Card sx={{ 
                  borderRadius: 3, 
                  borderLeft: `8px solid ${broker.color}`,
                  boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
                  height: '100%'
                }}>
                  <CardContent>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                      <Box>
                        <Typography variant="h6" sx={{ fontWeight: 800, color: broker.color }}>{broker.nombre}</Typography>
                        <Typography variant="caption" color="text.secondary" sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <UsersIcon size={14} /> {broker.contacto || 'Sin contacto'}
                        </Typography>
                        <Typography variant="caption" color="text.secondary" sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <Mail size={14} /> {broker.mail || 'Sin mail'}
                        </Typography>
                      </Box>
                      <Box>
                        <IconButton size="small" onClick={() => handleOpenBrokerDialog(broker)} color="primary">
                          <Edit size={18} />
                        </IconButton>
                        <IconButton size="small" onClick={() => handleDeleteBroker(broker.id)} color="error">
                          <Trash2 size={18} />
                        </IconButton>
                      </Box>
                    </Box>
                    
                    <Divider sx={{ mb: 2 }} />
                    
                    <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1 }}>Aseguradoras Asignadas:</Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                      {broker.aseguradorasIds.map(id => {
                        const insurer = insurers.find(i => i.id === id);
                        return insurer ? (
                          <Chip 
                            key={id} 
                            label={insurer.razonSocial} 
                            size="small" 
                            sx={{ 
                              bgcolor: 'white', 
                              border: `1px solid ${broker.color}`,
                              color: broker.color,
                              fontWeight: 600 
                            }} 
                          />
                        ) : null;
                      })}
                      {broker.aseguradorasIds.length === 0 && (
                        <Typography variant="caption" color="text.secondary">No hay aseguradoras asignadas</Typography>
                      )}
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            ))}
            {brokers.length === 0 && (
              <Grid size={12}>
                <Paper sx={{ p: 4, textAlign: 'center', borderRadius: 3 }}>
                  <Typography color="text.secondary">No hay brokers u organizadores registrados</Typography>
                </Paper>
              </Grid>
            )}
          </Grid>
        </Box>
      )}

      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ fontWeight: 800 }}>
          {editingInsurer ? 'Editar Aseguradora' : 'Nueva Aseguradora'}
        </DialogTitle>
        <DialogContent dividers>
          <Grid container spacing={2} sx={{ mt: 0.5 }}>
            <Grid size={12}>
              <TextField
                fullWidth
                label="Razón Social"
                value={formData.razonSocial}
                onChange={(e) => setFormData({ ...formData, razonSocial: e.target.value })}
                InputProps={{ startAdornment: <InputAdornment position="start"><Building size={18} /></InputAdornment> }}
              />
            </Grid>
            <Grid size={12}>
              <TextField
                fullWidth
                label="Domicilio Comercial"
                value={formData.domicilioComercial}
                onChange={(e) => setFormData({ ...formData, domicilioComercial: e.target.value })}
                InputProps={{ startAdornment: <InputAdornment position="start"><MapPin size={18} /></InputAdornment> }}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="CUIT"
                value={formData.cuit}
                onChange={(e) => setFormData({ ...formData, cuit: e.target.value })}
                InputProps={{ startAdornment: <InputAdornment position="start"><FileText size={18} /></InputAdornment> }}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                select
                label="Condición IVA"
                value={formData.condicionIva}
                onChange={(e) => setFormData({ ...formData, condicionIva: e.target.value as any })}
              >
                <MenuItem value="Responsable Inscripto">Responsable Inscripto</MenuItem>
                <MenuItem value="Monotributo">Monotributo</MenuItem>
                <MenuItem value="Consumidor Final">Consumidor Final</MenuItem>
                <MenuItem value="Exento">Exento</MenuItem>
              </TextField>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="Email"
                value={formData.mail}
                onChange={(e) => setFormData({ ...formData, mail: e.target.value })}
                InputProps={{ startAdornment: <InputAdornment position="start"><Mail size={18} /></InputAdornment> }}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="Teléfono"
                value={formData.telefono}
                onChange={(e) => setFormData({ ...formData, telefono: e.target.value })}
                InputProps={{ startAdornment: <InputAdornment position="start"><Phone size={18} /></InputAdornment> }}
              />
            </Grid>
            <Grid size={12}>
              <TextField
                fullWidth
                label="URL Web / Acceso Directo"
                placeholder="https://www.ejemplo.com"
                value={formData.urlWeb}
                onChange={(e) => setFormData({ ...formData, urlWeb: e.target.value })}
                InputProps={{ startAdornment: <InputAdornment position="start"><Globe size={18} /></InputAdornment> }}
                helperText="URL para acceder directamente al portal de la aseguradora"
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 4 }}>
              <TextField
                fullWidth
                label="Usuario"
                value={formData.usuario}
                onChange={(e) => setFormData({ ...formData, usuario: e.target.value })}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 4 }}>
              <TextField
                fullWidth
                label="Contraseña"
                type="text"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 4 }}>
              <TextField
                fullWidth
                label="Código Cliente"
                value={formData.codigoCliente}
                onChange={(e) => setFormData({ ...formData, codigoCliente: e.target.value })}
              />
            </Grid>
            <Grid size={12}>
              <TextField
                fullWidth
                multiline
                rows={3}
                label="Notas"
                value={formData.notas}
                onChange={(e) => setFormData({ ...formData, notas: e.target.value })}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ p: 3 }}>
          <Button onClick={handleCloseDialog} color="inherit" sx={{ fontWeight: 700 }}>Cancelar</Button>
          <Button onClick={handleSave} variant="contained" sx={{ fontWeight: 700, px: 4 }}>Guardar</Button>
        </DialogActions>
      </Dialog>

      <Dialog open={openBrokerDialog} onClose={() => setOpenBrokerDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ fontWeight: 800 }}>
          {editingBroker ? 'Editar Broker / Organizador' : 'Nuevo Broker / Organizador'}
        </DialogTitle>
        <DialogContent dividers>
          <Grid container spacing={2} sx={{ mt: 0.5 }}>
            <Grid size={12}>
              <TextField
                fullWidth
                label="Nombre del Broker / Org."
                value={brokerFormData.nombre}
                onChange={(e) => setBrokerFormData({ ...brokerFormData, nombre: e.target.value })}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="Persona de Contacto"
                value={brokerFormData.contacto}
                onChange={(e) => setBrokerFormData({ ...brokerFormData, contacto: e.target.value })}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="Email"
                value={brokerFormData.mail}
                onChange={(e) => setBrokerFormData({ ...brokerFormData, mail: e.target.value })}
              />
            </Grid>
            <Grid size={12}>
              <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 700 }}>Color Identificador:</Typography>
              <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                {BROKER_COLORS.map(color => (
                  <Box 
                    key={color}
                    onClick={() => setBrokerFormData({ ...brokerFormData, color })}
                    sx={{ 
                      width: 32, 
                      height: 32, 
                      bgcolor: color, 
                      borderRadius: '50%', 
                      cursor: 'pointer',
                      border: brokerFormData.color === color ? '3px solid #000' : 'none',
                      boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
                    }}
                  />
                ))}
              </Box>
            </Grid>
            <Grid size={12}>
              <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 700 }}>Asignar Aseguradoras:</Typography>
              <Select
                multiple
                fullWidth
                value={brokerFormData.aseguradorasIds}
                onChange={(e) => setBrokerFormData({ ...brokerFormData, aseguradorasIds: e.target.value as string[] })}
                input={<OutlinedInput label="Aseguradoras" />}
                renderValue={(selected) => (
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                    {selected.map((value) => (
                      <Chip key={value} label={insurers.find(i => i.id === value)?.razonSocial} size="small" />
                    ))}
                  </Box>
                )}
              >
                {insurers.map((insurer) => (
                  <MenuItem key={insurer.id} value={insurer.id}>
                    <Checkbox checked={brokerFormData.aseguradorasIds?.indexOf(insurer.id) !== -1} />
                    <ListItemText primary={insurer.razonSocial} />
                  </MenuItem>
                ))}
              </Select>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ p: 3 }}>
          <Button onClick={() => setOpenBrokerDialog(false)} color="inherit" sx={{ fontWeight: 700 }}>Cancelar</Button>
          <Button onClick={handleSaveBroker} variant="contained" color="secondary" sx={{ fontWeight: 700, px: 4 }}>Guardar Broker</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
