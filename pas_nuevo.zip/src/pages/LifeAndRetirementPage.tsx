import React, { useState } from 'react';
import { 
  Box, 
  Typography, 
  Card, 
  CardContent, 
  Button, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow, 
  Paper, 
  IconButton, 
  TextField, 
  InputAdornment,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  Tabs,
  Tab,
  Chip,
  MenuItem,
  Tooltip,
  Autocomplete,
  Collapse
} from '@mui/material';
import { 
  Plus, 
  Search, 
  Edit2, 
  Trash2, 
  HeartPulse, 
  Download,
  Phone,
  Mail,
  MessageCircle,
  Users,
  TrendingUp,
  Shield,
  Coins,
  Clock,
  ChevronDown,
  ChevronUp,
  CheckSquare,
  Square
} from 'lucide-react';
import { format, differenceInDays, parseISO, addDays, isAfter, isBefore, addMonths, addYears, differenceInMonths, differenceInYears } from 'date-fns';
import * as XLSX from 'xlsx';

import { PROVINCIAS_ARGENTINA, POLICY_CATEGORIES, ASEGURADORAS } from '../constants';

export const LifeAndRetirementPage: React.FC<{ 
  policies: any[], 
  setPolicies: React.Dispatch<React.SetStateAction<any[]>>, 
  onTogglePaid: (id: string) => void, 
  onUpdatePaymentDate: (id: string, date: string) => void,
  onUpdatePolicy: (policy: any) => void,
  clients: any[],
  setClients: React.Dispatch<React.SetStateAction<any[]>>
}> = ({ policies, setPolicies, onTogglePaid, onUpdatePaymentDate, onUpdatePolicy, clients, setClients }) => {
  const [tab, setTab] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  const [open, setOpen] = useState(false);
  const [editingPolicy, setEditingPolicy] = useState<any>(null);
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set());
  const [selectedMoneda, setSelectedMoneda] = useState('ARS');
  const [formValues, setFormValues] = useState<any>({
    prima: '',
    sumaAsegurada: '',
    aporteMensual: '',
    fondoAcumulado: '',
    comisionPorcentaje: '',
    fechaInicio: '',
    vencimiento: '',
    pagada: false
  });

  const formatWithDots = (val: string) => {
    const clean = val.replace(/\D/g, '');
    if (!clean) return '';
    // Strip leading zeros unless it's just '0'
    const stripped = clean.replace(/^0+(?!$)/, '');
    return stripped.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  };

  const unformat = (val: string) => {
    return Number(val.replace(/\./g, '') || 0);
  };

  const capitalizeWords = (str: string) => {
    return str.toLowerCase().replace(/\b\w/g, (char) => char.toUpperCase());
  };

  const formatDNIorCUIT = (value: string) => {
    const digits = value.replace(/\D/g, '');
    if (digits.length <= 8) {
      return digits.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    }
    if (digits.length <= 10) return `${digits.slice(0, 2)}-${digits.slice(2)}`;
    return `${digits.slice(0, 2)}-${digits.slice(2, 10)}-${digits.slice(10)}`;
  };

  const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormValues((prev: any) => ({
      ...prev,
      [name]: formatWithDots(value)
    }));
  };

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormValues((prev: any) => {
      const newValues = { ...prev, [name]: type === 'checkbox' ? checked : value };
      
      // If fechaInicio changes and not manual override, update vencimiento to +30 days
      if (name === 'fechaInicio' && !manualVencimiento) {
        newValues.vencimiento = format(addDays(parseISO(value), 30), 'yyyy-MM-dd');
      }
      
      if (name === 'vencimiento') {
        setManualVencimiento(true);
      }
      
      return newValues;
    });
  };

  const toggleGroup = (groupId: string) => {
    const newExpanded = new Set(expandedGroups);
    if (newExpanded.has(groupId)) {
      newExpanded.delete(groupId);
    } else {
      newExpanded.add(groupId);
    }
    setExpandedGroups(newExpanded);
  };

  const tabs = [
    { label: 'Seguros de Vida', icon: <HeartPulse size={18} />, value: 'Vida' },
    { label: 'Seguros de Retiro', icon: <Coins size={18} />, value: 'Retiro' },
  ];

  const [manualVencimiento, setManualVencimiento] = useState(false);

  const handleOpen = (policy?: any) => {
    setEditingPolicy(policy || null);
    setSelectedMoneda(policy?.moneda || 'ARS');
    setManualVencimiento(false);
    setFormValues({
      prima: policy?.prima ? formatWithDots(policy.prima.toString()) : '',
      sumaAsegurada: policy?.sumaAsegurada ? formatWithDots(policy.sumaAsegurada.toString()) : '',
      aporteMensual: policy?.aporteMensual ? formatWithDots(policy.aporteMensual.toString()) : '',
      fondoAcumulado: policy?.fondoAcumulado ? formatWithDots(policy.fondoAcumulado.toString()) : '',
      comisionPorcentaje: policy?.comisionPorcentaje ? formatWithDots(policy.comisionPorcentaje.toString()) : '',
      fechaInicio: policy?.fechaInicio || new Date().toISOString().split('T')[0],
      vencimiento: policy?.vencimiento || format(addDays(new Date(), 30), 'yyyy-MM-dd'),
      pagada: policy?.pagada || false
    });
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setEditingPolicy(null);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('¿Estás seguro de eliminar esta póliza?')) {
      setPolicies(policies.filter(p => p.id !== id));
    }
  };

  const handleWhatsApp = (telefono: string) => {
    const url = `https://wa.me/${telefono.replace(/\D/g, '')}`;
    window.open(url, '_blank');
  };

  const handleEmail = (email: string) => {
    if (email) {
      window.open(`mailto:${email}`, '_blank');
    }
  };

  const handleExport = () => {
    const currentType = tabs[tab].value;
    const data = policies.filter(p => p.tipo === currentType);
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, currentType);
    XLSX.writeFile(wb, `Vida_Retiro_${currentType}_PAS_Alert.xlsx`);
  };

  const getCurrencySymbol = (moneda: string) => {
    switch (moneda) {
      case 'USD': return 'U$D';
      case 'EUR': return '€';
      case 'BRL': return 'R$';
      default: return '$';
    }
  };

  const currentType = tabs[tab].value;
  const filteredPolicies = policies.filter(p => 
    p.tipo === currentType && (
      p.cliente.toLowerCase().includes(searchTerm.toLowerCase()) || 
      p.cuit.includes(searchTerm)
    )
  );

  const handleTogglePaid = (id: string) => {
    onTogglePaid(id);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    const data: any = Object.fromEntries(formData.entries());
    
    // Use unformatted values for calculations and storage
    data.prima = unformat(formValues.prima);
    data.sumaAsegurada = unformat(formValues.sumaAsegurada);
    data.aporteMensual = unformat(formValues.aporteMensual);
    data.fondoAcumulado = unformat(formValues.fondoAcumulado);
    data.comisionPorcentaje = unformat(formValues.comisionPorcentaje);
    data.fechaInicio = formValues.fechaInicio;
    data.vencimiento = formValues.vencimiento;

    const countMap: { [key: string]: number } = {
      'Mensual': 1,
      'Bimestral': 2,
      'Trimestral': 3,
      'Semestral': 6,
      'Anual': 12
    };
    const count = countMap[data.vigencia] || 1;

    const intervalMap: { [key: string]: number } = {
      'Mensual': 30,
      'Bimestral': 60,
      'Trimestral': 90,
      'Semestral': 180,
      'Anual': 365
    };
    const interval = intervalMap[data.vigencia] || 30;

    const groupId = editingPolicy?.groupId || Math.random().toString(36).substr(2, 9);

    // Check if client exists, if not add to clients list
    const existingClient = clients.find(c => c.nombre === data.cliente);
    if (!existingClient) {
      const newClient = {
        id: Math.random().toString(36).substr(2, 9),
        nombre: data.cliente,
        dni: data.cuit,
        telefono: data.telefono,
        email: data.email || '',
        direccion: data.calle || '',
        altura: data.numero || '',
        cp: data.cp || '',
        provincia: data.provincia || '',
        localidad: data.localidad || ''
      };
      setClients(prev => [newClient, ...prev]);
    }

    const createPolicyObject = (baseData: any, id: string, index: number, gId: string, startDate: string, endDate: string) => {
      const p: any = {
        id,
        cliente: baseData.cliente,
        cuit: baseData.cuit,
        aseguradora: baseData.aseguradora,
        poliza: index === 0 ? baseData.poliza : '', // Subsequent policies have no number
        tipo: currentType,
        email: baseData.email,
        telefono: baseData.telefono,
        cp: baseData.cp,
        estado: editingPolicy?.estado || 'Activa',
        pagada: editingPolicy?.pagada || false,
        medioPago: baseData.medioPago,
        cuota: editingPolicy ? editingPolicy.cuota : `${index + 1}/${count}`,
        groupId: gId,
        fechaInicio: startDate,
        vencimiento: endDate,
        vigencia: baseData.vigencia || 'Mensual',
      };

      if (currentType === 'Vida') {
        p.subtipo = baseData.subtipo;
        p.sumaAsegurada = Number(baseData.sumaAsegurada || 0);
        p.prima = Number(baseData.prima || 0);
        p.moneda = baseData.moneda;
        p.fuma = baseData.fuma === 'true';
        p.comisionPorcentaje = Number(baseData.comisionPorcentaje || 0);
        p.edad = Number(baseData.edad || 0);
        p.dias = editingPolicy?.dias || 365;
      } else {
        p.edad = Number(baseData.edad || 0);
        p.edadRetiro = Number(baseData.edadRetiro || 0);
        p.aporteMensual = Number(baseData.aporteMensual || 0);
        p.fondoAcumulado = Number(baseData.fondoAcumulado || 0);
        p.moneda = baseData.moneda;
        p.comisionPorcentaje = Number(baseData.comisionPorcentaje || 0);
        p.ultimoAporte = baseData.ultimoAporte;
      }
      return p;
    };

    if (editingPolicy) {
      const updatedPolicy = createPolicyObject(data, editingPolicy.id, parseInt(editingPolicy.cuota?.split('/')[0] || '1') - 1, groupId, data.fechaInicio, data.vencimiento);
      updatedPolicy.pagada = formValues.pagada;
      
      if (updatedPolicy.pagada !== editingPolicy.pagada) {
        onTogglePaid(editingPolicy.id);
      } else {
        onUpdatePolicy(updatedPolicy);
      }
    } else {
      const id = Math.random().toString(36).substr(2, 9);
      const firstPolicy = createPolicyObject(data, id, 0, groupId, data.fechaInicio, data.vencimiento);
      firstPolicy.cuota = `1/${count}`;
      setPolicies([firstPolicy, ...policies]);
    }
    handleClose();
  };

  const lifeOptions = POLICY_CATEGORIES.find(cat => cat.category.includes('SEGUROS DE PERSONAS'))?.items || [];
  const retirementOptions = POLICY_CATEGORIES.find(cat => cat.category.includes('SEGUROS DE RETIRO'))?.items || [];

  return (
    <Box sx={{ width: '100%', maxWidth: '100%', px: { xs: 1, md: 0 } }}>
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 800 }}>Vida y Retiro</Typography>
          <Typography variant="body1" color="text.secondary">Gestiona pólizas de Vida y Seguros de Retiro.</Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <Button 
            variant="outlined" 
            startIcon={<Download size={20} />}
            onClick={handleExport}
          >
            Exportar Excel
          </Button>
          <Button 
            variant="contained" 
            startIcon={<Plus size={20} />}
            onClick={() => handleOpen()}
            sx={{ borderRadius: 3, bgcolor: 'error.main', '&:hover': { bgcolor: 'error.dark' } }}
          >
            Nueva Póliza
          </Button>
        </Box>
      </Box>

      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs 
          value={tab} 
          onChange={(_, newValue) => setTab(newValue)} 
          aria-label="tabs vida retiro"
        >
          {tabs.map((t, index) => (
            <Tab key={index} icon={t.icon} iconPosition="start" label={t.label} />
          ))}
        </Tabs>
      </Box>

      <Card sx={{ mb: 4 }}>
        <CardContent>
          <TextField
            fullWidth
            placeholder="Buscar por cliente o CUIT..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search size={20} />
                </InputAdornment>
              ),
            }}
          />
        </CardContent>
      </Card>

      <TableContainer component={Paper} sx={{ width: '100%', overflowX: 'auto' }}>
        <Table sx={{ width: '100%' }}>
          <TableHead sx={{ bgcolor: 'error.main' }}>
            <TableRow>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Cliente</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>DNI / CUIT</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Teléfono</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Email</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'right' }}>Acciones</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {(() => {
              const currentType = tabs[tab].value;
              const clientsWithPolicies = clients.filter(client => 
                policies.some(p => p.cliente === client.nombre && p.tipo === currentType)
              ).filter(c => 
                c.nombre.toLowerCase().includes(searchTerm.toLowerCase()) || 
                c.dni.includes(searchTerm)
              );

              return clientsWithPolicies.map((client) => {
                const clientPolicies = policies.filter(p => p.cliente === client.nombre && p.tipo === currentType);
                const isExpanded = expandedGroups.has(client.id);

                return (
                  <React.Fragment key={client.id}>
                    <TableRow hover>
                      <TableCell sx={{ fontWeight: 600 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <IconButton size="small" onClick={() => toggleGroup(client.id)}>
                            {isExpanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                          </IconButton>
                          <Box>
                            <Typography variant="body2" sx={{ fontWeight: 700 }}>{client.nombre}</Typography>
                            <Typography variant="caption" color="error.main" sx={{ fontWeight: 600 }}>
                              Pólizas: {clientPolicies.length}
                            </Typography>
                          </Box>
                        </Box>
                      </TableCell>
                      <TableCell>{client.dni}</TableCell>
                      <TableCell>{client.telefono}</TableCell>
                      <TableCell>{client.email}</TableCell>
                      <TableCell sx={{ textAlign: 'right' }}>
                        <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1 }}>
                          <IconButton size="small" color="success" onClick={() => handleWhatsApp(client.telefono)}>
                            <MessageCircle size={18} />
                          </IconButton>
                          <IconButton size="small" color="info" onClick={() => handleEmail(client.email)}>
                            <Mail size={18} />
                          </IconButton>
                        </Box>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={5}>
                        <Collapse in={isExpanded} timeout="auto" unmountOnExit>
                          <Box sx={{ margin: 2 }}>
                            <TableContainer component={Paper} elevation={0} sx={{ border: '1px solid', borderColor: 'divider' }}>
                              <Table size="small">
                                <TableHead sx={{ bgcolor: 'error.main' }}>
                                  <TableRow>
                                    <TableCell sx={{ color: 'white', fontWeight: 700 }}>Póliza / Aseguradora</TableCell>
                                    <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center' }}>Inicio</TableCell>
                                    <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center' }}>Vencimiento</TableCell>
                                    <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center' }}>Vigencia</TableCell>
                                    <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center' }}>Cuota</TableCell>
                                    <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'right' }}>Detalle</TableCell>
                                    <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'center' }}>Pagado</TableCell>
                                    <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'right' }}>Acciones</TableCell>
                                  </TableRow>
                                </TableHead>
                                <TableBody>
                                  {clientPolicies.map((policy) => {
                                    const daysLeft = differenceInDays(parseISO(policy.vencimiento), new Date());
                                    let color = 'success.main';
                                    if (daysLeft < 0) color = 'error.main';
                                    else if (daysLeft <= 5) color = 'warning.main';

                                    return (
                                      <TableRow key={policy.id} hover>
                                        <TableCell sx={{ fontWeight: 600 }}>
                                          <Typography variant="body2" sx={{ fontWeight: 700 }}>N° {policy.poliza || 'S/N'}</Typography>
                                          <Chip 
                                            label={policy.aseguradora} 
                                            size="small" 
                                            sx={{ bgcolor: '#1a237e', color: 'white', fontWeight: 700, fontSize: '0.65rem', height: 20, mt: 0.5 }} 
                                          />
                                          <Typography variant="caption" display="block" color="text.secondary" sx={{ fontWeight: 700 }}>
                                            {policy.subtipo || policy.tipo}
                                          </Typography>
                                        </TableCell>
                                        <TableCell sx={{ textAlign: 'center' }}>{policy.fechaInicio ? format(parseISO(policy.fechaInicio), 'dd/MM/yyyy') : '-'}</TableCell>
                                        <TableCell sx={{ textAlign: 'center' }}>{format(parseISO(policy.vencimiento), 'dd/MM/yyyy')}</TableCell>
                                        <TableCell>
                                          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5, alignItems: 'center' }}>
                                            <Chip 
                                              label={policy.pagada ? 'PAGADO' : (daysLeft < 0 ? 'Vencida' : daysLeft <= 5 ? 'Vence pronto' : 'Vigente')} 
                                              size="small" 
                                              sx={{ 
                                                fontWeight: 700, 
                                                fontSize: '0.7rem', 
                                                height: 20,
                                                bgcolor: policy.pagada ? 'success.main' : (daysLeft < 0 ? 'error.main' : daysLeft <= 5 ? '#FFD700' : 'success.main'),
                                                color: (daysLeft >= 0 && daysLeft <= 5 && !policy.pagada) ? 'black' : 'white'
                                              }}
                                            />
                                            {!policy.pagada && (
                                              <Typography variant="caption" sx={{ fontWeight: 800, color }}>
                                                {daysLeft < 0 ? `Vencida` : daysLeft === 0 ? 'Hoy' : `${daysLeft} días`}
                                              </Typography>
                                            )}
                                          </Box>
                                        </TableCell>
                                        <TableCell sx={{ textAlign: 'center' }}>
                                          <Typography variant="body2" sx={{ fontWeight: 700, color: 'primary.main' }}>{policy.cuota || '1/1'}</Typography>
                                          <Typography variant="caption" sx={{ display: 'block', color: 'text.secondary' }}>{policy.medioPago || '-'}</Typography>
                                        </TableCell>
                                        <TableCell sx={{ textAlign: 'right' }}>
                                          <Typography variant="body2" sx={{ fontWeight: 700 }}>
                                            {policy.tipo === 'Vida' ? `Suma: $ ${policy.sumaAsegurada?.toLocaleString()}` : `Fondo: $ ${policy.fondoAcumulado?.toLocaleString()}`}
                                          </Typography>
                                          <Typography variant="caption" sx={{ display: 'block', color: 'text.secondary' }}>
                                            {policy.tipo === 'Vida' ? `Prima: $ ${policy.prima?.toLocaleString()}` : `Aporte: $ ${policy.aporteMensual?.toLocaleString()}`}
                                          </Typography>
                                        </TableCell>
                                        <TableCell>
                                          <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                                            <IconButton onClick={() => onTogglePaid(policy.id)} color={policy.pagada ? 'success' : 'default'}>
                                              {policy.pagada ? <CheckSquare size={20} /> : <Square size={20} />}
                                            </IconButton>
                                            {policy.pagada && (
                                              <Typography variant="caption">{policy.fechaPago ? format(parseISO(policy.fechaPago), 'dd/MM') : ''}</Typography>
                                            )}
                                          </Box>
                                        </TableCell>
                                        <TableCell sx={{ textAlign: 'right' }}>
                                          <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 0.5 }}>
                                            <IconButton size="small" color="primary" onClick={() => handleOpen(policy)}>
                                              <Edit2 size={16} />
                                            </IconButton>
                                            <IconButton size="small" color="error" onClick={() => handleDelete(policy.id)}>
                                              <Trash2 size={16} />
                                            </IconButton>
                                          </Box>
                                        </TableCell>
                                      </TableRow>
                                    );
                                  })}
                                </TableBody>
                              </Table>
                            </TableContainer>
                          </Box>
                        </Collapse>
                      </TableCell>
                    </TableRow>
                  </React.Fragment>
                );
              });
            })()}
          </TableBody>
          {(currentType === 'Vida' || currentType === 'Retiro') && (
            <TableHead sx={{ bgcolor: 'grey.200' }}>
              <TableRow>
                <TableCell colSpan={5} sx={{ fontWeight: 800 }}>TOTAL COMISIONES PAGADAS</TableCell>
                <TableCell sx={{ fontWeight: 800, textAlign: 'right' }}>
                  {(() => {
                    const totals: { [key: string]: number } = {};
                    filteredPolicies.forEach(p => {
                      const moneda = p.moneda || 'ARS';
                      // Only sum if the commission is "paid" (not in red)
                      const baseAmount = currentType === 'Vida' ? (p.prima || 0) : (p.aporteMensual || 0);
                      const comision = p.pagada ? (baseAmount * (p.comisionPorcentaje || 0)) / 100 : 0;
                      totals[moneda] = (totals[moneda] || 0) + comision;
                    });
                    return (
                      <Box>
                        {Object.entries(totals).map(([moneda, total]) => (
                          <Typography key={moneda} variant="body2" sx={{ fontWeight: 800, color: 'success.main', whiteSpace: 'nowrap' }}>
                            {getCurrencySymbol(moneda)} {total.toLocaleString()}
                          </Typography>
                        ))}
                      </Box>
                    );
                  })()}
                </TableCell>
                <TableCell colSpan={6}></TableCell>
              </TableRow>
            </TableHead>
          )}
        </Table>
      </TableContainer>

      <Dialog 
        open={open} 
        onClose={handleClose} 
        maxWidth="md" 
        fullWidth
        component="form"
        onSubmit={handleSave}
      >
        <DialogTitle sx={{ fontWeight: 700 }}>
          {editingPolicy ? 'Editar Póliza' : `Nueva Póliza (${currentType})`}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid size={{ xs: 12, md: 6 }}>
              <Autocomplete
                freeSolo
                options={clients.map(c => c.nombre)}
                defaultValue={editingPolicy?.cliente}
                onChange={(_, value) => {
                  const selectedClient = clients.find(c => c.nombre === value);
                  if (selectedClient) {
                    // We need to update the other fields manually since this is a native form
                    const form = document.querySelector('form');
                    if (form) {
                      const cuitInput = form.querySelector('input[name="cuit"]') as HTMLInputElement;
                      const telInput = form.querySelector('input[name="telefono"]') as HTMLInputElement;
                      const emailInput = form.querySelector('input[name="email"]') as HTMLInputElement;
                      const calleInput = form.querySelector('input[name="calle"]') as HTMLInputElement;
                      const numeroInput = form.querySelector('input[name="numero"]') as HTMLInputElement;
                      const cpInput = form.querySelector('input[name="cp"]') as HTMLInputElement;
                      const provinciaInput = form.querySelector('input[name="provincia"]') as HTMLInputElement;
                      const localidadInput = form.querySelector('input[name="localidad"]') as HTMLInputElement;
                      
                      if (cuitInput) cuitInput.value = selectedClient.dni;
                      if (telInput) telInput.value = selectedClient.telefono;
                      if (emailInput) emailInput.value = selectedClient.email || '';
                      if (calleInput) calleInput.value = selectedClient.direccion || '';
                      if (numeroInput) numeroInput.value = selectedClient.altura || '';
                      if (cpInput) cpInput.value = selectedClient.cp || '';
                      if (provinciaInput) provinciaInput.value = selectedClient.provincia || '';
                      if (localidadInput) localidadInput.value = selectedClient.localidad || '';
                    }
                  }
                }}
                renderInput={(params) => (
                  <TextField 
                    {...params}
                    fullWidth 
                    name="cliente" 
                    label="Nombre del Cliente" 
                    required 
                    onChange={(e) => {
                      e.target.value = capitalizeWords(e.target.value);
                    }}
                  />
                )}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 3 }}>
              <TextField fullWidth name="telefono" label="Teléfono (WhatsApp)" defaultValue={editingPolicy?.telefono} placeholder="Ej: 54911..." />
            </Grid>
            <Grid size={{ xs: 12, md: 3 }}>
              <TextField fullWidth name="email" label="Email" defaultValue={editingPolicy?.email} />
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <TextField fullWidth name="calle" label="Calle" />
            </Grid>
            <Grid size={{ xs: 12, md: 2 }}>
              <TextField fullWidth name="numero" label="N°" />
            </Grid>
            <Grid size={{ xs: 12, md: 4 }}>
              <TextField fullWidth name="cp" label="C.P." defaultValue={editingPolicy?.cp} />
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <Autocomplete
                options={PROVINCIAS_ARGENTINA}
                renderInput={(params) => (
                  <TextField {...params} fullWidth name="provincia" label="Provincia" />
                )}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <TextField fullWidth name="localidad" label="Localidad" />
            </Grid>
            <Grid size={{ xs: 12, md: 3 }}>
              <TextField 
                fullWidth 
                name="cuit" 
                label="DNI / CUIT" 
                defaultValue={editingPolicy?.cuit} 
                onChange={(e) => {
                  e.target.value = formatDNIorCUIT(e.target.value);
                }}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 3 }}>
              <TextField fullWidth name="poliza" label="Número de Póliza" defaultValue={editingPolicy?.poliza} />
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <Autocomplete
                freeSolo
                options={ASEGURADORAS}
                defaultValue={editingPolicy?.aseguradora}
                renderInput={(params) => (
                  <TextField 
                    {...params}
                    fullWidth 
                    name="aseguradora" 
                    label="Aseguradora" 
                    onChange={(e) => {
                      e.target.value = capitalizeWords(e.target.value);
                    }}
                  />
                )}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <TextField 
                fullWidth 
                select 
                name="vigencia"
                label={currentType === 'Vida' ? "Vigencia" : "Frecuencia de Aporte"} 
                defaultValue="Mensual"
                disabled={!!editingPolicy}
              >
                <MenuItem value="Mensual">Mensual {currentType === 'Vida' && '(1 cuota)'}</MenuItem>
                <MenuItem value="Bimestral">Bimestral {currentType === 'Vida' && '(2 cuotas)'}</MenuItem>
                <MenuItem value="Trimestral">Trimestral {currentType === 'Vida' && '(3 cuotas)'}</MenuItem>
                <MenuItem value="Semestral">Semestral {currentType === 'Vida' && '(6 cuotas)'}</MenuItem>
                <MenuItem value="Anual">Anual {currentType === 'Vida' && '(12 cuotas)'}</MenuItem>
              </TextField>
            </Grid>
            <Grid size={{ xs: 12, md: 3 }}>
              <TextField 
                fullWidth 
                name={currentType === 'Vida' ? "prima" : "aporteMensual"}
                label={currentType === 'Vida' ? "Prima Mensual" : "Aporte Mensual"} 
                value={currentType === 'Vida' ? formValues.prima : formValues.aporteMensual}
                onChange={handleNumberChange}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      {getCurrencySymbol(selectedMoneda)}
                    </InputAdornment>
                  ),
                }}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 3 }}>
              <TextField 
                fullWidth 
                select 
                name="moneda"
                label="Moneda" 
                value={selectedMoneda}
                onChange={(e) => setSelectedMoneda(e.target.value)}
              >
                <MenuItem value="ARS">Pesos ($)</MenuItem>
                <MenuItem value="USD">Dólares (U$D)</MenuItem>
                <MenuItem value="EUR">Euros (€)</MenuItem>
                <MenuItem value="BRL">Reales (R$)</MenuItem>
              </TextField>
            </Grid>
            <Grid size={{ xs: 12, md: 3 }}>
              <TextField 
                fullWidth 
                name="comisionPorcentaje"
                label="% Comisión" 
                value={formValues.comisionPorcentaje}
                onChange={handleNumberChange}
                InputProps={{
                  endAdornment: <InputAdornment position="end">%</InputAdornment>,
                }}
                helperText={(() => {
                  const base = Number(currentType === 'Vida' ? unformat(formValues.prima) : unformat(formValues.aporteMensual));
                  const perc = Number(unformat(formValues.comisionPorcentaje));
                  const result = (base * perc) / 100;
                  return `Monto Comisión: ${getCurrencySymbol(selectedMoneda)} ${result.toLocaleString()}`;
                })()}
              />
            </Grid>
            {currentType === 'Vida' && (
              <>
                <Grid size={{ xs: 12, md: 6 }}>
                  <TextField 
                    fullWidth 
                    name="sumaAsegurada" 
                    label="Suma Asegurada" 
                    value={formValues.sumaAsegurada}
                    onChange={handleNumberChange}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          {getCurrencySymbol(selectedMoneda)}
                        </InputAdornment>
                      ),
                    }}
                  />
                </Grid>
                <Grid size={{ xs: 12, md: 3 }}>
                  <TextField 
                    fullWidth 
                    select 
                    name="fuma"
                    label="¿Fuma?" 
                    defaultValue={editingPolicy?.fuma ? 'true' : 'false'}
                  >
                    <MenuItem value="false">No Fuma</MenuItem>
                    <MenuItem value="true">Fuma</MenuItem>
                  </TextField>
                </Grid>
                <Grid size={{ xs: 12, md: 4 }}>
                  <TextField fullWidth name="edad" label="Edad" type="number" defaultValue={editingPolicy?.edad} />
                </Grid>
                <Grid size={{ xs: 12, md: 4 }}>
                  <Autocomplete
                    freeSolo
                    options={lifeOptions}
                    defaultValue={editingPolicy?.subtipo}
                    renderInput={(params) => (
                      <TextField {...params} fullWidth name="subtipo" label="Tipo de Vida" placeholder="Individual, Colectivo, Con ahorro" />
                    )}
                  />
                </Grid>
                <Grid size={{ xs: 12, md: 4 }}>
                  <TextField 
                    fullWidth 
                    name="fechaInicio" 
                    label="Fecha de Inicio" 
                    type="date" 
                    InputLabelProps={{ shrink: true }} 
                    value={formValues.fechaInicio} 
                    onChange={handleDateChange}
                  />
                </Grid>
                <Grid size={{ xs: 12, md: 4 }}>
                  <TextField 
                    fullWidth 
                    name="vencimiento" 
                    label="Vencimiento" 
                    type="date" 
                    InputLabelProps={{ shrink: true }} 
                    value={formValues.vencimiento} 
                    onChange={handleDateChange}
                  />
                </Grid>
                <Grid size={{ xs: 12 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <IconButton 
                      onClick={() => setFormValues(prev => ({ ...prev, pagada: !prev.pagada }))}
                      sx={{ color: formValues.pagada ? 'success.main' : 'text.disabled' }}
                    >
                      {formValues.pagada ? <CheckSquare size={24} /> : <Square size={24} />}
                    </IconButton>
                    <Typography variant="body1" sx={{ fontWeight: 600 }}>
                      Marcar como Pagada
                    </Typography>
                  </Box>
                </Grid>
              </>
            )}
            <Grid size={{ xs: 12, md: 4 }}>
              <TextField 
                fullWidth 
                select 
                name="medioPago"
                label="Medio de Pago" 
                defaultValue={editingPolicy?.medioPago || 'Cupon'}
              >
                <MenuItem value="Cupon">Cupon</MenuItem>
                <MenuItem value="Tarjeta de credito">Tarjeta de credito</MenuItem>
                <MenuItem value="Debito por CBU">Debito por CBU</MenuItem>
              </TextField>
            </Grid>
            {currentType === 'Retiro' && (
              <>
                <Grid size={{ xs: 12, md: 4 }}>
                  <TextField fullWidth name="edad" label="Edad" type="number" defaultValue={editingPolicy?.edad} />
                </Grid>
                <Grid size={{ xs: 12, md: 4 }}>
                  <TextField fullWidth name="edadRetiro" label="Edad Retiro" type="number" defaultValue={editingPolicy?.edadRetiro} />
                </Grid>
                <Grid size={{ xs: 12, md: 4 }}>
                  <Autocomplete
                    freeSolo
                    options={retirementOptions}
                    defaultValue={editingPolicy?.subtipo}
                    renderInput={(params) => (
                      <TextField {...params} fullWidth name="subtipo" label="Tipo de Retiro" placeholder="Individual, Colectivo, Planes de ahorro" />
                    )}
                  />
                </Grid>
                <Grid size={{ xs: 12, md: 4 }}>
                  <TextField 
                    fullWidth 
                    name="fechaInicio" 
                    label="Fecha de Inicio" 
                    type="date" 
                    InputLabelProps={{ shrink: true }} 
                    value={formValues.fechaInicio} 
                    onChange={handleDateChange}
                  />
                </Grid>
                <Grid size={{ xs: 12, md: 4 }}>
                  <TextField 
                    fullWidth 
                    name="vencimiento" 
                    label="Vencimiento" 
                    type="date" 
                    InputLabelProps={{ shrink: true }} 
                    value={formValues.vencimiento} 
                    onChange={handleDateChange}
                  />
                </Grid>
                <Grid size={{ xs: 12 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <IconButton 
                      onClick={() => setFormValues(prev => ({ ...prev, pagada: !prev.pagada }))}
                      sx={{ color: formValues.pagada ? 'success.main' : 'text.disabled' }}
                    >
                      {formValues.pagada ? <CheckSquare size={24} /> : <Square size={24} />}
                    </IconButton>
                    <Typography variant="body1" sx={{ fontWeight: 600 }}>
                      Marcar como Pagada
                    </Typography>
                  </Box>
                </Grid>
                <Grid size={{ xs: 12, md: 4 }}>
                  <TextField fullWidth name="ultimoAporte" label="Último Aporte" type="date" InputLabelProps={{ shrink: true }} defaultValue={editingPolicy?.ultimoAporte} />
                </Grid>
                <Grid size={{ xs: 12, md: 4 }}>
                  <TextField 
                    fullWidth 
                    name="aporteMensual"
                    label="Aporte Mensual" 
                    value={formValues.aporteMensual}
                    onChange={handleNumberChange}
                    InputProps={{
                      startAdornment: <InputAdornment position="start">$</InputAdornment>,
                    }}
                  />
                </Grid>
                <Grid size={{ xs: 12, md: 6 }}>
                  <TextField 
                    fullWidth 
                    name="fondoAcumulado"
                    label="Fondo Acumulado" 
                    value={formValues.fondoAcumulado}
                    onChange={handleNumberChange}
                    InputProps={{
                      startAdornment: <InputAdornment position="start">$</InputAdornment>,
                    }}
                  />
                </Grid>
              </>
            )}
            <Grid size={{ xs: 12, md: 3 }}>
              <TextField fullWidth name="cp" label="Código Postal" defaultValue={editingPolicy?.cp} />
            </Grid>
            <Grid size={{ xs: 12, md: 3 }}>
              <TextField 
                fullWidth 
                select 
                name="prioridad" 
                label="Prioridad" 
                defaultValue={editingPolicy?.prioridad || 'Baja'}
              >
                <MenuItem value="Alta">Alta</MenuItem>
                <MenuItem value="Media">Media</MenuItem>
                <MenuItem value="Baja">Baja</MenuItem>
              </TextField>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ p: 3 }}>
          <Button onClick={handleClose}>Cancelar</Button>
          <Button variant="contained" color="error" type="submit">Guardar Póliza</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
