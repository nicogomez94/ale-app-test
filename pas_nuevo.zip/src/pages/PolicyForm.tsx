import React, { useState } from 'react';
import { 
  Box, 
  Card, 
  CardContent, 
  Typography, 
  TextField, 
  Button, 
  Grid, 
  InputAdornment,
  Autocomplete,
  Divider,
  Alert,
  Snackbar,
  MenuItem
} from '@mui/material';
import { 
  User, 
  CreditCard, 
  Calendar, 
  Briefcase, 
  Shield, 
  Phone, 
  Hash,
  Save,
  Wallet
} from 'lucide-react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';

import { format, addDays, parseISO, addMonths, addYears, differenceInMonths, differenceInYears } from 'date-fns';
import { useNavigate } from 'react-router-dom';

import { PROVINCIAS_ARGENTINA, POLICY_CATEGORIES, ASEGURADORAS } from '../constants';

const schema = z.object({
  clienteNombre: z.string().min(3, 'Nombre requerido'),
  clienteDni: z.string().min(7, 'DNI inválido'),
  clienteTelefono: z.string().min(8, 'Teléfono requerido'),
  clienteEmail: z.string().email('Email inválido').optional().or(z.literal('')),
  clienteCalle: z.string().optional(),
  clienteNumero: z.string().optional(),
  clienteCp: z.string().optional(),
  clienteProvincia: z.string().optional(),
  clienteLocalidad: z.string().optional(),
  aseguradora: z.string().min(1, 'Aseguradora requerida'),
  rubro: z.string().min(1, 'Rubro requerido'),
  numeroPoliza: z.string().min(1, 'Número de póliza requerido'),
  fechaInicio: z.string(),
  fechaVencimiento: z.string(),
  prima: z.number().min(0, 'Prima debe ser mayor o igual a 0'),
  sumaAsegurada: z.number().optional(),
  fondoAcumulado: z.number().optional(),
  porcentajeComision: z.number().min(0).max(100),
  moneda: z.enum(['ARS', 'USD', 'EUR', 'BRL']),
  medioPago: z.enum(['Cupon', 'Tarjeta de credito', 'Debito por CBU']),
  vigencia: z.enum(['Mensual', 'Bimestral', 'Trimestral', 'Semestral', 'Anual']),
  edad: z.number().optional(),
  fuma: z.boolean().optional(),
  edadRetiro: z.number().optional(),
});

type FormData = z.infer<typeof schema>;

const COMMISSION_CONFIGS = [
  { aseguradora: 'Federación Patronal Seguros', rubro: 'Automotores', porcentaje: 15 },
  { aseguradora: 'Federación Patronal Seguros', rubro: 'Hogar', porcentaje: 20 },
  { aseguradora: 'Sancor Seguros', rubro: 'Automotores', porcentaje: 12 },
  { aseguradora: 'Sancor Seguros', rubro: 'Vida', porcentaje: 25 },
  { aseguradora: 'Zurich Argentina', rubro: 'Vida', porcentaje: 30 },
];

export const PolicyForm: React.FC<{ 
  policies: any[], 
  setPolicies: React.Dispatch<React.SetStateAction<any[]>>,
  clients: any[],
  setClients: React.Dispatch<React.SetStateAction<any[]>>
}> = ({ policies, setPolicies, clients, setClients }) => {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  
  const { control, handleSubmit, watch, setValue, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      prima: undefined as any,
      sumaAsegurada: undefined as any,
      fondoAcumulado: undefined as any,
      porcentajeComision: 15,
      moneda: 'ARS',
      medioPago: 'Cupon',
      vigencia: 'Mensual',
      clienteEmail: '',
      clienteCalle: '',
      clienteNumero: '',
      clienteCp: '',
      clienteProvincia: '',
      clienteLocalidad: '',
      fechaInicio: new Date().toISOString().split('T')[0],
      fechaVencimiento: format(addDays(new Date(), 30), 'yyyy-MM-dd'),
    }
  });

  const prima = watch('prima');
  const rubro = watch('rubro');
  const aseguradora = watch('aseguradora');
  const porcentaje = watch('porcentajeComision');
  const comisionCalculada = (prima * (porcentaje / 100)).toFixed(2);

  // Automatically update percentage based on config
  React.useEffect(() => {
    if (aseguradora && rubro) {
      const config = COMMISSION_CONFIGS.find(c => 
        c.aseguradora === aseguradora && c.rubro === rubro
      );
      if (config) {
        setValue('porcentajeComision', config.porcentaje);
      }
    }
  }, [aseguradora, rubro, setValue]);
  
  // Determine policy type based on category reactively
  const categoryObj = POLICY_CATEGORIES.find(cat => cat.items.includes(rubro));
  const categoryName = categoryObj?.category || '';
  let tipo = 'Individual';
  if (categoryName.includes('SEGUROS DE PERSONAS')) {
    tipo = 'Vida';
  } else if (categoryName.includes('SEGUROS DE RETIRO')) {
    tipo = 'Retiro';
  } else if (
    categoryName.includes('SEGUROS EMPRESARIALES') || 
    categoryName.includes('SEGUROS TÉCNICOS') || 
    categoryName.includes('RIESGOS DEL TRABAJO') ||
    categoryName.includes('SEGUROS FINANCIEROS') ||
    rubro === 'Flotas vehiculares'
  ) {
    tipo = 'Empresa';
  }

  const fechaInicio = watch('fechaInicio');
  const [manualVencimiento, setManualVencimiento] = useState(false);

  const capitalizeWords = (str: string) => {
    return str.toLowerCase().replace(/\b\w/g, (char) => char.toUpperCase());
  };

  const formatDNIorCUIT = (value: string) => {
    const digits = value.replace(/\D/g, '');
    if (digits.length <= 8) {
      return digits.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    }
    if (digits.length <= 10) return `${digits.slice(0, 2)}-${digits.slice(2)}`;
    return `${digits.slice(0, 2)}-${digits.slice(2, 10)}-${digits.slice(10)}`;
  };

  const formatWithDots = (val: string) => {
    const clean = val.replace(/\D/g, '');
    if (!clean) return '';
    const stripped = clean.replace(/^0+(?!$)/, '');
    return stripped.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  };

  const unformat = (val: string) => {
    if (typeof val !== 'string') return val;
    return Number(val.replace(/\./g, '') || 0);
  };

  // Automatically update vencimiento when inicio changes, unless manually overridden
  React.useEffect(() => {
    if (!manualVencimiento && fechaInicio) {
      const newVenc = format(addDays(parseISO(fechaInicio), 30), 'yyyy-MM-dd');
      setValue('fechaVencimiento', newVenc);
    }
  }, [fechaInicio, setValue, manualVencimiento]);

  const onSubmit = (data: FormData) => {
    const countMap: { [key: string]: number } = {
      'Mensual': 1,
      'Bimestral': 2,
      'Trimestral': 3,
      'Semestral': 6,
      'Anual': 12
    };
    const count = countMap[data.vigencia] || 1;
    const groupId = Math.random().toString(36).substr(2, 9);
    
    // Check if client exists, if not add to clients list
    const existingClient = clients.find(c => c.nombre === data.clienteNombre);
    if (!existingClient) {
      const newClient = {
        id: Math.random().toString(36).substr(2, 9),
        nombre: data.clienteNombre,
        dni: data.clienteDni,
        telefono: data.clienteTelefono,
        email: data.clienteEmail || '',
        direccion: data.clienteCalle || '',
        altura: data.clienteNumero || '',
        cp: data.clienteCp || '',
        provincia: data.clienteProvincia || '',
        localidad: data.clienteLocalidad || ''
      };
      setClients(prev => [newClient, ...prev]);
    }

    const id = Math.random().toString(36).substr(2, 9);
    
    const firstPolicy = {
      id,
      cliente: data.clienteNombre,
      cuit: data.clienteDni,
      telefono: data.clienteTelefono,
      email: data.clienteEmail,
      aseguradora: data.aseguradora,
      rubro: data.rubro,
      poliza: data.numeroPoliza,
      fechaInicio: data.fechaInicio,
      vencimiento: data.fechaVencimiento,
      prima: data.prima || 0,
      sumaAsegurada: data.sumaAsegurada || 0,
      fondoAcumulado: data.fondoAcumulado || 0,
      aporteMensual: data.prima || 0, // For Retiro, prima acts as aporteMensual
      moneda: data.moneda,
      comisionPorcentaje: data.porcentajeComision,
      medioPago: data.medioPago,
      vigencia: data.vigencia,
      tipo,
      estado: 'Activa',
      pagada: false,
      cuota: `1/${count}`,
      groupId: groupId,
      edad: data.edad,
      fuma: data.fuma,
      edadRetiro: data.edadRetiro,
    };

    setPolicies(prev => [firstPolicy, ...prev]);
    setOpen(true);
    setTimeout(() => navigate('/'), 1500);
  };

  // Mock for autocomplete
  const aseguradoras = ASEGURADORAS;
  const rubroOptions = POLICY_CATEGORIES.flatMap(cat => cat.items.map(item => ({
    label: item,
    category: cat.category
  })));

  return (
    <Box>
      <Typography variant="h4" sx={{ fontWeight: 800, mb: 4 }}>Nueva Póliza</Typography>
      
      <form onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={3}>
          <Grid size={{ xs: 12, md: 8 }}>
            <Card sx={{ mb: 3 }}>
              <CardContent>
                <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <User size={20} /> Datos del Cliente
                </Typography>
                <Divider sx={{ mb: 3 }} />
                <Grid container spacing={2}>
                  <Grid size={{ xs: 12, md: 6 }}>
                    <Controller
                      name="clienteNombre"
                      control={control}
                      render={({ field }) => (
                        <Autocomplete
                          freeSolo
                          options={clients.map(c => c.nombre)}
                          value={field.value}
                          onChange={(_, value) => {
                            const selectedClient = clients.find(c => c.nombre === value);
                            if (selectedClient) {
                              setValue('clienteNombre', selectedClient.nombre);
                              setValue('clienteDni', selectedClient.dni);
                              setValue('clienteTelefono', selectedClient.telefono);
                              setValue('clienteEmail', selectedClient.email || '');
                              
                              // Handle address splitting if it's stored as a single string in some cases, 
                              // but here we assume the client object has the fields
                              setValue('clienteCalle', selectedClient.direccion || '');
                              setValue('clienteNumero', selectedClient.altura || '');
                              setValue('clienteCp', selectedClient.cp || '');
                              setValue('clienteProvincia', selectedClient.provincia || '');
                              setValue('clienteLocalidad', selectedClient.localidad || '');
                            } else {
                              field.onChange(capitalizeWords(value || ''));
                            }
                          }}
                          onInputChange={(_, value) => field.onChange(capitalizeWords(value || ''))}
                          renderInput={(params) => (
                            <TextField
                              {...params}
                              fullWidth
                              label="Nombre Completo"
                              error={!!errors.clienteNombre}
                              helperText={errors.clienteNombre?.message}
                            />
                          )}
                        />
                      )}
                    />
                  </Grid>
                  <Grid size={{ xs: 12, md: 3 }}>
                    <Controller
                      name="clienteDni"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          fullWidth
                          label="DNI / CUIT"
                          onChange={(e) => {
                            field.onChange(formatDNIorCUIT(e.target.value));
                          }}
                          error={!!errors.clienteDni}
                          helperText={errors.clienteDni?.message}
                        />
                      )}
                    />
                  </Grid>
                  <Grid size={{ xs: 12, md: 3 }}>
                    <Controller
                      name="clienteTelefono"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          fullWidth
                          label="Teléfono"
                          InputProps={{ startAdornment: <InputAdornment position="start"><Phone size={16} /></InputAdornment> }}
                          error={!!errors.clienteTelefono}
                          helperText={errors.clienteTelefono?.message}
                        />
                      )}
                    />
                  </Grid>
                  <Grid size={{ xs: 12, md: 6 }}>
                    <Controller
                      name="clienteEmail"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          fullWidth
                          label="Email"
                          error={!!errors.clienteEmail}
                          helperText={errors.clienteEmail?.message}
                        />
                      )}
                    />
                  </Grid>
                  <Grid size={{ xs: 12, md: 6 }}>
                    <Controller
                      name="clienteCalle"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          fullWidth
                          label="Calle"
                          onChange={(e) => field.onChange(capitalizeWords(e.target.value))}
                        />
                      )}
                    />
                  </Grid>
                  <Grid size={{ xs: 12, md: 2 }}>
                    <Controller
                      name="clienteNumero"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          fullWidth
                          label="N°"
                        />
                      )}
                    />
                  </Grid>
                  <Grid size={{ xs: 12, md: 4 }}>
                    <Controller
                      name="clienteCp"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          fullWidth
                          label="C.P."
                        />
                      )}
                    />
                  </Grid>
                  <Grid size={{ xs: 12, md: 6 }}>
                    <Controller
                      name="clienteProvincia"
                      control={control}
                      render={({ field }) => (
                        <Autocomplete
                          options={PROVINCIAS_ARGENTINA}
                          value={field.value}
                          onChange={(_, value) => field.onChange(value)}
                          renderInput={(params) => (
                            <TextField
                              {...params}
                              fullWidth
                              label="Provincia"
                            />
                          )}
                        />
                      )}
                    />
                  </Grid>
                  <Grid size={{ xs: 12, md: 6 }}>
                    <Controller
                      name="clienteLocalidad"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          fullWidth
                          label="Localidad"
                          onChange={(e) => field.onChange(capitalizeWords(e.target.value))}
                        />
                      )}
                    />
                  </Grid>
                </Grid>
              </CardContent>
            </Card>

            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Shield size={20} /> Detalles de la Póliza
                </Typography>
                <Divider sx={{ mb: 3 }} />
                <Grid container spacing={2}>
                  <Grid size={{ xs: 12, md: 6 }}>
                    <Controller
                      name="aseguradora"
                      control={control}
                      render={({ field }) => (
                        <Autocomplete
                          freeSolo
                          options={aseguradoras}
                          value={field.value}
                          onChange={(_, value) => field.onChange(capitalizeWords(value || ''))}
                          onInputChange={(_, value) => field.onChange(capitalizeWords(value || ''))}
                          renderInput={(params) => (
                            <TextField {...params} label="Aseguradora" error={!!errors.aseguradora} helperText={errors.aseguradora?.message} />
                          )}
                        />
                      )}
                    />
                  </Grid>
                  <Grid size={{ xs: 12, md: 6 }}>
                    <Controller
                      name="rubro"
                      control={control}
                      render={({ field }) => (
                        <Autocomplete
                          freeSolo
                          options={rubroOptions}
                          groupBy={(option) => (typeof option === 'string' ? 'Otros' : option.category)}
                          getOptionLabel={(option) => (typeof option === 'string' ? option : option.label)}
                          value={rubroOptions.find(r => r.label === field.value) || field.value}
                          onChange={(_, value) => {
                            const label = typeof value === 'string' ? value : value?.label;
                            field.onChange(label || '');
                          }}
                          onInputChange={(_, value) => field.onChange(value)}
                          renderInput={(params) => (
                            <TextField {...params} label="Rubro" error={!!errors.rubro} helperText={errors.rubro?.message} />
                          )}
                        />
                      )}
                    />
                  </Grid>
                  {(tipo === 'Vida' || tipo === 'Retiro') && (
                    <Grid size={{ xs: 12, md: 3 }}>
                      <Controller
                        name="edad"
                        control={control}
                        render={({ field }) => (
                          <TextField
                            {...field}
                            fullWidth
                            label="Edad"
                            type="number"
                            onChange={(e) => field.onChange(parseInt(e.target.value) || undefined)}
                          />
                        )}
                      />
                    </Grid>
                  )}
                  {tipo === 'Vida' && (
                    <Grid size={{ xs: 12, md: 3 }}>
                      <Controller
                        name="fuma"
                        control={control}
                        render={({ field }) => (
                          <TextField
                            {...field}
                            fullWidth
                            select
                            label="¿Fuma?"
                          >
                            <MenuItem value={true as any}>Sí</MenuItem>
                            <MenuItem value={false as any}>No</MenuItem>
                          </TextField>
                        )}
                      />
                    </Grid>
                  )}
                  {tipo === 'Retiro' && (
                    <Grid size={{ xs: 12, md: 3 }}>
                      <Controller
                        name="edadRetiro"
                        control={control}
                        render={({ field }) => (
                          <TextField
                            {...field}
                            fullWidth
                            label="Edad de Retiro"
                            type="number"
                            onChange={(e) => field.onChange(parseInt(e.target.value) || undefined)}
                          />
                        )}
                      />
                    </Grid>
                  )}
                  <Grid size={{ xs: 12, md: 6 }}>
                    <Controller
                      name="numeroPoliza"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          fullWidth
                          label="Número de Póliza"
                          InputProps={{ startAdornment: <InputAdornment position="start"><Hash size={16} /></InputAdornment> }}
                          error={!!errors.numeroPoliza}
                          helperText={errors.numeroPoliza?.message}
                        />
                      )}
                    />
                  </Grid>
                  <Grid size={{ xs: 12, md: 3 }}>
                    <Controller
                      name="fechaInicio"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          fullWidth
                          type="date"
                          label="Fecha Inicio"
                          InputLabelProps={{ shrink: true }}
                        />
                      )}
                    />
                  </Grid>
                  <Grid size={{ xs: 12, md: 3 }}>
                    <Controller
                      name="fechaVencimiento"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          fullWidth
                          type="date"
                          label="Fecha Vencimiento"
                          InputLabelProps={{ shrink: true }}
                          onChange={(e) => {
                            setManualVencimiento(true);
                            field.onChange(e);
                          }}
                        />
                      )}
                    />
                  </Grid>
                  <Grid size={{ xs: 12, md: 6 }}>
                    <Controller
                      name="medioPago"
                      control={control}
                      render={({ field }) => (
                        <Autocomplete
                          options={['Cupon', 'Tarjeta de credito', 'Debito por CBU']}
                          value={field.value}
                          onChange={(_, value) => field.onChange(value)}
                          renderInput={(params) => (
                            <TextField 
                              {...params} 
                              label="Medio de Pago" 
                              error={!!errors.medioPago} 
                              helperText={errors.medioPago?.message}
                              InputProps={{
                                ...params.InputProps,
                                startAdornment: (
                                  <>
                                    <InputAdornment position="start">
                                      <Wallet size={16} />
                                    </InputAdornment>
                                    {params.InputProps.startAdornment}
                                  </>
                                )
                              }}
                            />
                          )}
                        />
                      )}
                    />
                  </Grid>
                  <Grid size={{ xs: 12, md: 6 }}>
                    <Controller
                      name="vigencia"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          fullWidth
                          select
                          label="Vigencia"
                          error={!!errors.vigencia}
                          helperText={errors.vigencia?.message}
                        >
                          <MenuItem value="Mensual">Mensual</MenuItem>
                          <MenuItem value="Bimestral">Bimestral</MenuItem>
                          <MenuItem value="Trimestral">Trimestral</MenuItem>
                          <MenuItem value="Semestral">Semestral</MenuItem>
                          <MenuItem value="Anual">Anual</MenuItem>
                        </TextField>
                      )}
                    />
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>

          <Grid size={{ xs: 12, md: 4 }}>
            <Card sx={{ bgcolor: 'primary.main', color: 'white', mb: 3 }}>
              <CardContent>
                <Typography variant="h6" gutterBottom>Resumen Económico</Typography>
                <Divider sx={{ mb: 2, bgcolor: 'rgba(255,255,255,0.2)' }} />
                
                <Box sx={{ mb: 3 }}>
                  <Controller
                    name="moneda"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        fullWidth
                        select
                        label="Moneda"
                        sx={{ 
                          '& .MuiOutlinedInput-root': { color: 'white' },
                          '& .MuiInputLabel-root': { color: 'rgba(255,255,255,0.7)' },
                          '& .MuiOutlinedInput-notchedOutline': { borderColor: 'rgba(255,255,255,0.3)' },
                          '& .MuiSvgIcon-root': { color: 'white' }
                        }}
                      >
                        <MenuItem value="ARS">Pesos (ARS)</MenuItem>
                        <MenuItem value="USD">Dólares (USD)</MenuItem>
                        <MenuItem value="EUR">Euros (EUR)</MenuItem>
                        <MenuItem value="BRL">Reales (BRL)</MenuItem>
                      </TextField>
                    )}
                  />
                </Box>

                <Box sx={{ mb: 3 }}>
                  <Controller
                    name="prima"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        fullWidth
                        label={tipo === 'Retiro' ? 'Aporte Mensual' : 'Prima'}
                        value={formatWithDots(field.value?.toString() || '')}
                        onChange={(e) => {
                          const val = e.target.value;
                          field.onChange(unformat(val));
                        }}
                        sx={{ 
                          '& .MuiOutlinedInput-root': { color: 'white' },
                          '& .MuiInputLabel-root': { color: 'rgba(255,255,255,0.7)' },
                          '& .MuiOutlinedInput-notchedOutline': { borderColor: 'rgba(255,255,255,0.3)' }
                        }}
                      />
                    )}
                  />
                </Box>

                {tipo === 'Vida' && (
                  <Box sx={{ mb: 3 }}>
                    <Controller
                      name="sumaAsegurada"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          fullWidth
                          label="Suma Asegurada"
                          value={formatWithDots(field.value?.toString() || '')}
                          onChange={(e) => {
                            const val = e.target.value;
                            field.onChange(unformat(val));
                          }}
                          sx={{ 
                            '& .MuiOutlinedInput-root': { color: 'white' },
                            '& .MuiInputLabel-root': { color: 'rgba(255,255,255,0.7)' },
                            '& .MuiOutlinedInput-notchedOutline': { borderColor: 'rgba(255,255,255,0.3)' }
                          }}
                        />
                      )}
                    />
                  </Box>
                )}

                {tipo === 'Retiro' && (
                  <Box sx={{ mb: 3 }}>
                    <Controller
                      name="fondoAcumulado"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          fullWidth
                          label="Fondo Acumulado"
                          value={formatWithDots(field.value?.toString() || '')}
                          onChange={(e) => {
                            const val = e.target.value;
                            field.onChange(unformat(val));
                          }}
                          sx={{ 
                            '& .MuiOutlinedInput-root': { color: 'white' },
                            '& .MuiInputLabel-root': { color: 'rgba(255,255,255,0.7)' },
                            '& .MuiOutlinedInput-notchedOutline': { borderColor: 'rgba(255,255,255,0.3)' }
                          }}
                        />
                      )}
                    />
                  </Box>
                )}

                <Box sx={{ mb: 3 }}>
                  <Controller
                    name="porcentajeComision"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        fullWidth
                        label="Porcentaje Comisión (%)"
                        type="number"
                        onChange={(e) => field.onChange(parseFloat(e.target.value))}
                        sx={{ 
                          '& .MuiOutlinedInput-root': { color: 'white' },
                          '& .MuiInputLabel-root': { color: 'rgba(255,255,255,0.7)' },
                          '& .MuiOutlinedInput-notchedOutline': { borderColor: 'rgba(255,255,255,0.3)' }
                        }}
                      />
                    )}
                  />
                </Box>

                <Box sx={{ p: 2, bgcolor: 'rgba(255,255,255,0.1)', borderRadius: 2 }}>
                  <Typography variant="body2" sx={{ opacity: 0.8 }}>Comisión Estimada</Typography>
                  <Typography variant="h4" sx={{ fontWeight: 700 }}>$ {comisionCalculada}</Typography>
                </Box>
              </CardContent>
            </Card>

            <Button 
              type="submit"
              variant="contained" 
              color="secondary" 
              fullWidth 
              size="large"
              startIcon={<Save size={20} />}
              sx={{ py: 2, borderRadius: 3, fontWeight: 700 }}
            >
              Guardar Póliza
            </Button>
          </Grid>
        </Grid>
      </form>

      <Snackbar open={open} autoHideDuration={6000} onClose={() => setOpen(false)}>
        <Alert onClose={() => setOpen(false)} severity="success" sx={{ width: '100%' }}>
          Póliza guardada exitosamente.
        </Alert>
      </Snackbar>
    </Box>
  );
};
