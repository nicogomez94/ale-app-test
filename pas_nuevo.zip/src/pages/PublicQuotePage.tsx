import React, { useState } from 'react';
import { 
  Box, 
  Typography, 
  Card, 
  CardContent, 
  Button, 
  TextField, 
  Grid, 
  MenuItem, 
  FormControl, 
  FormLabel, 
  RadioGroup, 
  FormControlLabel, 
  Radio,
  Container,
  Paper,
  Divider,
  Alert
} from '@mui/material';
import { 
  User, 
  Car, 
  Bike, 
  Home, 
  FileText, 
  CreditCard, 
  Send,
  CheckCircle2,
  Bell
} from 'lucide-react';
import { useParams } from 'react-router-dom';
import { PROVINCIAS_ARGENTINA } from '../constants';

export const PublicQuotePage: React.FC = () => {
  const { userId, type } = useParams<{ userId: string; type: string }>();
  const [submitted, setSubmitted] = useState(false);
  const [formValues, setFormValues] = useState<any>({
    tipoSeguro: type ? type.charAt(0).toUpperCase() + type.slice(1) : 'Auto',
    nombreApellido: '',
    cuitCuil: '',
    fechaNacimiento: '',
    email: '',
    celular: '',
    marca: '',
    modelo: '',
    anio: '',
    patente: '',
    tipoUso: 'Particular',
    tieneGNC: 'No',
    tieneRastreador: 'No',
    tipoVivienda: '',
    superficieCubierta: '',
    detalleOtros: '',
    formaPago: 'Débito por CBU',
    direccion: '',
    cp: '',
    localidad: '',
    provincia: ''
  });

  const handleInputChange = (field: string, value: any) => {
    setFormValues(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const quoteData = {
      ...formValues,
      id: Math.random().toString(36).substr(2, 9),
      fechaRegistro: new Date().toISOString(),
      source: 'Public Link',
      userId: userId
    };

    // Save to localStorage (simulating shared DB)
    const savedQuotes = localStorage.getItem('pas_alert_quotes');
    const quotes = savedQuotes ? JSON.parse(savedQuotes) : [];
    const updatedQuotes = [quoteData, ...quotes];
    localStorage.setItem('pas_alert_quotes', JSON.stringify(updatedQuotes));

    setSubmitted(true);
  };

  if (submitted) {
    return (
      <Container maxWidth="sm" sx={{ py: 8 }}>
        <Paper elevation={3} sx={{ p: 4, textAlign: 'center', borderRadius: 4 }}>
          <CheckCircle2 size={64} color="#10b981" style={{ marginBottom: 24 }} />
          <Typography variant="h4" gutterBottom sx={{ fontWeight: 800 }}>¡Solicitud Enviada!</Typography>
          <Typography variant="body1" color="text.secondary" paragraph>
            Gracias por confiar en nosotros. Tu solicitud de cotización ha sido recibida correctamente.
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 4 }}>
            Un productor de seguros se pondrá en contacto contigo a la brevedad.
          </Typography>
          <Button variant="contained" fullWidth onClick={() => window.location.reload()}>
            Solicitar otra cotización
          </Button>
        </Paper>
      </Container>
    );
  }

  return (
    <Box sx={{ bgcolor: 'grey.50', minHeight: '100vh', py: 4 }}>
      <Container maxWidth="md">
        <Box sx={{ mb: 4, textAlign: 'center' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 1.5, mb: 2 }}>
            <Box sx={{ 
              width: 40, 
              height: 40, 
              bgcolor: 'primary.main', 
              borderRadius: 2.5, 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center'
            }}>
              <Bell size={24} color="white" />
            </Box>
            <Typography variant="h5" sx={{ fontWeight: 900, letterSpacing: -1, color: 'primary.main' }}>
              PAS ALERT
            </Typography>
          </Box>
          <Typography variant="h4" sx={{ fontWeight: 800, mb: 1 }}>Solicitud de Cotización</Typography>
          <Typography variant="body1" color="text.secondary">
            Completa el siguiente formulario para recibir una propuesta personalizada.
          </Typography>
        </Box>

        <Paper elevation={2} sx={{ borderRadius: 4, overflow: 'hidden' }}>
          <Box sx={{ bgcolor: 'primary.main', py: 2, px: 3 }}>
            <Typography variant="subtitle1" sx={{ color: 'white', fontWeight: 700, display: 'flex', alignItems: 'center', gap: 1 }}>
              {formValues.tipoSeguro === 'Auto' ? <Car size={20} /> : 
               formValues.tipoSeguro === 'Moto' ? <Bike size={20} /> : 
               formValues.tipoSeguro === 'Hogar' ? <Home size={20} /> : <FileText size={20} />}
              Seguro de {formValues.tipoSeguro}
            </Typography>
          </Box>
          
          <Box component="form" onSubmit={handleSubmit} sx={{ p: 4 }}>
            <Grid container spacing={3}>
              {/* Datos Personales */}
              <Grid size={{ xs: 12 }}>
                <Typography variant="subtitle2" sx={{ mb: 1, display: 'flex', alignItems: 'center', gap: 1, color: 'primary.main' }}>
                  <User size={18} /> Datos Personales
                </Typography>
                <Divider sx={{ mb: 2 }} />
              </Grid>
              <Grid size={{ xs: 12, md: 6 }}>
                <TextField 
                  fullWidth required
                  label="Nombre y Apellido" 
                  value={formValues.nombreApellido}
                  onChange={(e) => handleInputChange('nombreApellido', e.target.value)}
                />
              </Grid>
              <Grid size={{ xs: 12, md: 6 }}>
                <TextField 
                  fullWidth required
                  label="CUIL / CUIT" 
                  value={formValues.cuitCuil}
                  onChange={(e) => handleInputChange('cuitCuil', e.target.value)}
                />
              </Grid>
              <Grid size={{ xs: 12, md: 4 }}>
                <TextField 
                  fullWidth required
                  label="Fecha de Nacimiento" 
                  type="date"
                  InputLabelProps={{ shrink: true }}
                  value={formValues.fechaNacimiento}
                  onChange={(e) => handleInputChange('fechaNacimiento', e.target.value)}
                />
              </Grid>
              <Grid size={{ xs: 12, md: 4 }}>
                <TextField 
                  fullWidth required
                  label="Número de Celular" 
                  value={formValues.celular}
                  onChange={(e) => handleInputChange('celular', e.target.value)}
                />
              </Grid>
              <Grid size={{ xs: 12, md: 4 }}>
                <TextField 
                  fullWidth required
                  label="Email" 
                  type="email"
                  value={formValues.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                />
              </Grid>

              {/* Datos Específicos */}
              {(formValues.tipoSeguro === 'Auto' || formValues.tipoSeguro === 'Moto') && (
                <>
                  <Grid size={{ xs: 12 }}>
                    <Typography variant="subtitle2" sx={{ mt: 2, mb: 1, display: 'flex', alignItems: 'center', gap: 1, color: 'primary.main' }}>
                      {formValues.tipoSeguro === 'Auto' ? <Car size={18} /> : <Bike size={18} />} Datos del Vehículo
                    </Typography>
                    <Divider sx={{ mb: 2 }} />
                  </Grid>
                  <Grid size={{ xs: 12, md: 4 }}>
                    <TextField 
                      fullWidth required
                      label="Marca" 
                      value={formValues.marca}
                      onChange={(e) => handleInputChange('marca', e.target.value)}
                    />
                  </Grid>
                  <Grid size={{ xs: 12, md: 4 }}>
                    <TextField 
                      fullWidth required
                      label="Modelo" 
                      value={formValues.modelo}
                      onChange={(e) => handleInputChange('modelo', e.target.value)}
                    />
                  </Grid>
                  <Grid size={{ xs: 12, md: 2 }}>
                    <TextField 
                      fullWidth required
                      label="Año" 
                      type="number"
                      value={formValues.anio}
                      onChange={(e) => handleInputChange('anio', e.target.value)}
                    />
                  </Grid>
                  <Grid size={{ xs: 12, md: 2 }}>
                    <TextField 
                      fullWidth required
                      label="Patente" 
                      value={formValues.patente}
                      onChange={(e) => handleInputChange('patente', e.target.value)}
                    />
                  </Grid>

                  <Grid size={{ xs: 12, md: 4 }}>
                    <FormControl component="fieldset">
                      <FormLabel component="legend">Tipo de Uso</FormLabel>
                      <RadioGroup 
                        row 
                        value={formValues.tipoUso}
                        onChange={(e) => handleInputChange('tipoUso', e.target.value)}
                      >
                        <FormControlLabel value="Particular" control={<Radio />} label="Particular" />
                        <FormControlLabel value="Comercial" control={<Radio />} label="Comercial" />
                      </RadioGroup>
                    </FormControl>
                  </Grid>
                  {formValues.tipoSeguro === 'Auto' && (
                    <Grid size={{ xs: 12, md: 4 }}>
                      <FormControl component="fieldset">
                        <FormLabel component="legend">¿Tiene GNC?</FormLabel>
                        <RadioGroup 
                          row 
                          value={formValues.tieneGNC}
                          onChange={(e) => handleInputChange('tieneGNC', e.target.value)}
                        >
                          <FormControlLabel value="Si" control={<Radio />} label="Si" />
                          <FormControlLabel value="No" control={<Radio />} label="No" />
                        </RadioGroup>
                      </FormControl>
                    </Grid>
                  )}
                  <Grid size={{ xs: 12, md: 4 }}>
                    <FormControl component="fieldset">
                      <FormLabel component="legend">¿Rastreador Satelital?</FormLabel>
                      <RadioGroup 
                        row 
                        value={formValues.tieneRastreador}
                        onChange={(e) => handleInputChange('tieneRastreador', e.target.value)}
                      >
                        <FormControlLabel value="Si" control={<Radio />} label="Si" />
                        <FormControlLabel value="No" control={<Radio />} label="No" />
                      </RadioGroup>
                    </FormControl>
                  </Grid>
                </>
              )}

              {formValues.tipoSeguro === 'Hogar' && (
                <>
                  <Grid size={{ xs: 12 }}>
                    <Typography variant="subtitle2" sx={{ mt: 2, mb: 1, display: 'flex', alignItems: 'center', gap: 1, color: 'primary.main' }}>
                      <Home size={18} /> Datos de la Vivienda
                    </Typography>
                    <Divider sx={{ mb: 2 }} />
                  </Grid>
                  <Grid size={{ xs: 12, md: 6 }}>
                    <TextField 
                      fullWidth required
                      label="Tipo de Vivienda (Casa, Depto, etc.)" 
                      value={formValues.tipoVivienda}
                      onChange={(e) => handleInputChange('tipoVivienda', e.target.value)}
                    />
                  </Grid>
                  <Grid size={{ xs: 12, md: 6 }}>
                    <TextField 
                      fullWidth required
                      label="Superficie Cubierta (m²)" 
                      type="number"
                      value={formValues.superficieCubierta}
                      onChange={(e) => handleInputChange('superficieCubierta', e.target.value)}
                    />
                  </Grid>
                </>
              )}

              {formValues.tipoSeguro === 'Otros' && (
                <>
                  <Grid size={{ xs: 12 }}>
                    <Typography variant="subtitle2" sx={{ mt: 2, mb: 1, display: 'flex', alignItems: 'center', gap: 1, color: 'primary.main' }}>
                      <FileText size={18} /> Otros Seguros
                    </Typography>
                    <Divider sx={{ mb: 2 }} />
                  </Grid>
                  <Grid size={{ xs: 12 }}>
                    <TextField 
                      fullWidth required
                      multiline
                      rows={3}
                      label="Detalle del seguro solicitado" 
                      value={formValues.detalleOtros}
                      onChange={(e) => handleInputChange('detalleOtros', e.target.value)}
                    />
                  </Grid>
                </>
              )}

              {/* Pago y Domicilio */}
              <Grid size={{ xs: 12 }}>
                <Typography variant="subtitle2" sx={{ mt: 2, mb: 1, display: 'flex', alignItems: 'center', gap: 1, color: 'primary.main' }}>
                  <CreditCard size={18} /> Pago y Domicilio
                </Typography>
                <Divider sx={{ mb: 2 }} />
              </Grid>
              <Grid size={{ xs: 12, md: 6 }}>
                <TextField 
                  fullWidth select required
                  label="Forma de Pago Preferida" 
                  value={formValues.formaPago}
                  onChange={(e) => handleInputChange('formaPago', e.target.value)}
                >
                  <MenuItem value="Débito por CBU">Débito por CBU</MenuItem>
                  <MenuItem value="Tarjeta de Crédito">Tarjeta de Crédito</MenuItem>
                  <MenuItem value="Cupón">Cupón</MenuItem>
                </TextField>
              </Grid>
              <Grid size={{ xs: 12, md: 6 }}>
                <TextField 
                  fullWidth required
                  label="Dirección" 
                  value={formValues.direccion}
                  onChange={(e) => handleInputChange('direccion', e.target.value)}
                />
              </Grid>
              <Grid size={{ xs: 12, md: 3 }}>
                <TextField 
                  fullWidth required
                  label="Código Postal" 
                  value={formValues.cp}
                  onChange={(e) => handleInputChange('cp', e.target.value)}
                />
              </Grid>
              <Grid size={{ xs: 12, md: 4 }}>
                <TextField 
                  fullWidth required
                  label="Localidad" 
                  value={formValues.localidad}
                  onChange={(e) => handleInputChange('localidad', e.target.value)}
                />
              </Grid>
              <Grid size={{ xs: 12, md: 5 }}>
                <TextField 
                  fullWidth select required
                  label="Provincia" 
                  value={formValues.provincia}
                  onChange={(e) => handleInputChange('provincia', e.target.value)}
                >
                  {PROVINCIAS_ARGENTINA.map((prov) => (
                    <MenuItem key={prov} value={prov}>{prov}</MenuItem>
                  ))}
                </TextField>
              </Grid>

              <Grid size={{ xs: 12 }} sx={{ mt: 4 }}>
                <Button 
                  type="submit" 
                  variant="contained" 
                  fullWidth 
                  size="large"
                  startIcon={<Send size={20} />}
                  sx={{ py: 1.5, borderRadius: 3, fontWeight: 700 }}
                >
                  Enviar Solicitud de Cotización
                </Button>
              </Grid>
            </Grid>
          </Box>
        </Paper>
        
        <Box sx={{ mt: 4, textAlign: 'center' }}>
          <Typography variant="caption" color="text.secondary">
            © 2026 PAS ALERT - Todos los derechos reservados.
          </Typography>
        </Box>
      </Container>
    </Box>
  );
};
