import React, { useState } from 'react';
import { 
  Box, 
  Typography, 
  Card, 
  CardContent, 
  Grid, 
  TextField, 
  Button, 
  IconButton,
  Tooltip,
  Divider,
  Chip,
  InputAdornment
} from '@mui/material';
import { 
  StickyNote, 
  Plus, 
  Trash2, 
  Search,
  Tag,
  Calendar as CalendarIcon,
  Clock,
  Filter
} from 'lucide-react';
import { format, parseISO, isToday, isFuture, isPast } from 'date-fns';
import { es } from 'date-fns/locale';

interface Note {
  id: string;
  text: string;
  date: Date;
  color: string;
  tags: string[];
}

interface QuickNotesPageProps {
  notes: any[];
  setNotes: (notes: any[]) => void;
}

export const QuickNotesPage: React.FC<QuickNotesPageProps> = ({ notes, setNotes }) => {
  const [newNoteText, setNewNoteText] = useState('');
  const [newNoteDate, setNewNoteDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedColor, setSelectedColor] = useState('#4f46e5');

  const colors = [
    { name: 'Indigo', value: '#4f46e5' },
    { name: 'Esmeralda', value: '#10b981' },
    { name: 'Rosa', value: '#ec4899' },
    { name: 'Ámbar', value: '#f59e0b' },
    { name: 'Cian', value: '#06b6d4' },
    { name: 'Rojo', value: '#ef4444' },
  ];

  const handleAddNote = () => {
    if (!newNoteText.trim()) return;
    
    const newNote = {
      id: Math.random().toString(36).substr(2, 9),
      text: newNoteText,
      date: newNoteDate,
      color: selectedColor,
      isRead: true
    };

    setNotes([...notes, newNote]);
    setNewNoteText('');
  };

  const handleDeleteNote = (id: string) => {
    setNotes(notes.filter(n => n.id !== id));
  };

  const filteredNotes = notes.filter(n => 
    n.text.toLowerCase().includes(searchTerm.toLowerCase())
  ).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <Box sx={{ p: 4, maxWidth: 1000, mx: 'auto' }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 4 }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 900, display: 'flex', alignItems: 'center', gap: 2, color: 'primary.main' }}>
            <StickyNote size={36} /> Notas Rápidas
          </Typography>
          <Typography variant="body1" color="text.secondary" sx={{ fontWeight: 500 }}>Captura ideas y recordatorios al instante.</Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <TextField
            size="small"
            placeholder="Buscar notas..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            InputProps={{
              startAdornment: <Search size={18} style={{ marginRight: 8, color: '#64748b' }} />,
              sx: { borderRadius: 3, bgcolor: 'background.paper' }
            }}
          />
        </Box>
      </Box>

      <Card sx={{ 
        mb: 4, 
        borderRadius: 4, 
        boxShadow: '0 10px 30px rgba(0,0,0,0.08)', 
        border: '1px solid', 
        borderColor: 'divider',
        overflow: 'visible'
      }}>
        <CardContent sx={{ p: 3 }}>
          <Grid container spacing={2} alignItems="flex-start">
            <Grid size={{ xs: 12, md: 7 }}>
              <TextField
                fullWidth
                multiline
                rows={3}
                placeholder="¿Qué tienes en mente?"
                value={newNoteText}
                onChange={(e) => setNewNoteText(e.target.value)}
                sx={{ 
                  '& .MuiOutlinedInput-root': { 
                    borderRadius: 3,
                    bgcolor: 'grey.50'
                  } 
                }}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 5 }}>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <TextField
                  fullWidth
                  type="date"
                  label="Fecha para el calendario"
                  value={newNoteDate}
                  onChange={(e) => setNewNoteDate(e.target.value)}
                  InputLabelProps={{ shrink: true }}
                  sx={{ '& .MuiOutlinedInput-root': { borderRadius: 3 } }}
                />
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Box sx={{ display: 'flex', gap: 1 }}>
                    {colors.map((c) => (
                      <Tooltip key={c.value} title={c.name}>
                        <Box 
                          onClick={() => setSelectedColor(c.value)}
                          sx={{ 
                            width: 24, 
                            height: 24, 
                            borderRadius: '50%', 
                            bgcolor: c.value,
                            cursor: 'pointer',
                            border: '2px solid',
                            borderColor: selectedColor === c.value ? 'white' : 'transparent',
                            boxShadow: selectedColor === c.value ? `0 0 0 2px ${c.value}` : 'none',
                            transition: 'all 0.2s'
                          }} 
                        />
                      </Tooltip>
                    ))}
                  </Box>
                  <Button 
                    variant="contained" 
                    onClick={handleAddNote}
                    disabled={!newNoteText.trim()}
                    startIcon={<Plus size={20} />}
                    sx={{ 
                      borderRadius: 3, 
                      px: 3, 
                      py: 1,
                      fontWeight: 700,
                      boxShadow: `0 4px 14px ${selectedColor}40`,
                      bgcolor: selectedColor,
                      '&:hover': { bgcolor: selectedColor, filter: 'brightness(0.9)' }
                    }}
                  >
                    Guardar
                  </Button>
                </Box>
              </Box>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      <Grid container spacing={3}>
        {filteredNotes.map((note) => {
          const noteDate = parseISO(note.date);
          const isNoteToday = isToday(noteDate);
          
          return (
            <Grid size={{ xs: 12, sm: 6, md: 4 }} key={note.id}>
              <Card sx={{ 
                height: '100%', 
                borderRadius: 4, 
                border: '1px solid', 
                borderColor: 'divider',
                transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                position: 'relative',
                '&:hover': { 
                  transform: 'translateY(-8px)', 
                  boxShadow: `0 20px 40px ${note.color}15`,
                  borderColor: note.color
                }
              }}>
                <Box sx={{ height: 6, bgcolor: note.color }} />
                <CardContent sx={{ p: 3 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Chip 
                        size="small"
                        icon={<CalendarIcon size={12} />}
                        label={format(noteDate, "d 'de' MMM", { locale: es })}
                        sx={{ 
                          fontWeight: 700, 
                          fontSize: '0.7rem',
                          bgcolor: isNoteToday ? `${note.color}20` : 'grey.100',
                          color: isNoteToday ? note.color : 'text.secondary',
                          border: isNoteToday ? `1px solid ${note.color}40` : 'none'
                        }}
                      />
                    </Box>
                    <IconButton size="small" color="error" onClick={() => handleDeleteNote(note.id)} sx={{ opacity: 0.6, '&:hover': { opacity: 1 } }}>
                      <Trash2 size={16} />
                    </IconButton>
                  </Box>
                  <Typography variant="body1" sx={{ 
                    fontWeight: 600, 
                    mb: 2, 
                    whiteSpace: 'pre-wrap',
                    color: 'text.primary',
                    lineHeight: 1.5
                  }}>
                    {note.text}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          );
        })}
      </Grid>

      {filteredNotes.length === 0 && (
        <Box sx={{ textAlign: 'center', py: 10 }}>
          <StickyNote size={64} color="#cbd5e1" style={{ marginBottom: 16 }} />
          <Typography variant="h6" color="text.secondary">No se encontraron notas.</Typography>
        </Box>
      )}
    </Box>
  );
};
