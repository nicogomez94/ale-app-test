import React, { useState } from 'react';
import { 
  Box, 
  Typography, 
  Card, 
  CardContent, 
  Button, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow, 
  Paper, 
  IconButton, 
  TextField, 
  InputAdornment,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  MenuItem,
  Chip,
  FormControl,
  FormLabel,
  RadioGroup,
  FormControlLabel,
  Radio
} from '@mui/material';
import { 
  Plus, 
  Search, 
  Edit2, 
  Trash2, 
  FileText, 
  Download,
  Phone,
  User,
  Car,
  CreditCard,
  MapPin,
  Mail,
  Home,
  Bike,
  Share2,
  QrCode,
  Copy,
  ExternalLink
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import * as XLSX from 'xlsx';
import { PROVINCIAS_ARGENTINA } from '../constants';

export const QuotesPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [open, setOpen] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [selectedType, setSelectedType] = useState<string>('Todos');
  const [editingQuote, setEditingQuote] = useState<any>(null);
  const [quotes, setQuotes] = useState<any[]>(() => {
    const saved = localStorage.getItem('pas_alert_quotes');
    return saved ? JSON.parse(saved) : [];
  });

  const [formValues, setFormValues] = useState<any>({
    tipoSeguro: 'Auto',
    nombreApellido: '',
    cuitCuil: '',
    fechaNacimiento: '',
    email: '',
    celular: '',
    // Auto/Moto
    marca: '',
    modelo: '',
    anio: '',
    patente: '',
    tipoUso: 'Particular',
    tieneGNC: 'No',
    tieneRastreador: 'No',
    // Hogar
    tipoVivienda: '',
    superficieCubierta: '',
    // Otros
    detalleOtros: '',
    // Común
    formaPago: 'Débito por CBU',
    direccion: '',
    cp: '',
    localidad: '',
    provincia: ''
  });

  const handleInputChange = (field: string, value: any) => {
    setFormValues(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleOpen = (quote?: any) => {
    if (quote) {
      setEditingQuote(quote);
      setFormValues(quote);
    } else {
      setEditingQuote(null);
      setFormValues({
        tipoSeguro: 'Auto',
        nombreApellido: '',
        cuitCuil: '',
        fechaNacimiento: '',
        email: '',
        celular: '',
        marca: '',
        modelo: '',
        anio: '',
        patente: '',
        tipoUso: 'Particular',
        tieneGNC: 'No',
        tieneRastreador: 'No',
        tipoVivienda: '',
        superficieCubierta: '',
        detalleOtros: '',
        formaPago: 'Débito por CBU',
        direccion: '',
        cp: '',
        localidad: '',
        provincia: ''
      });
    }
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setEditingQuote(null);
  };

  const handleSave = () => {
    const quoteData = {
      ...formValues,
      id: editingQuote?.id || Math.random().toString(36).substr(2, 9),
      fechaRegistro: new Date().toISOString()
    };

    let updatedQuotes;
    if (editingQuote) {
      updatedQuotes = quotes.map(q => q.id === editingQuote.id ? quoteData : q);
    } else {
      updatedQuotes = [quoteData, ...quotes];
    }
    setQuotes(updatedQuotes);
    localStorage.setItem('pas_alert_quotes', JSON.stringify(updatedQuotes));
    handleClose();
  };

  const handleDelete = (id: string) => {
    if (window.confirm('¿Estás seguro de eliminar esta cotización?')) {
      const updatedQuotes = quotes.filter(q => q.id !== id);
      setQuotes(updatedQuotes);
      localStorage.setItem('pas_alert_quotes', JSON.stringify(updatedQuotes));
    }
  };

  const handleExport = () => {
    const ws = XLSX.utils.json_to_sheet(quotes);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Cotizaciones');
    XLSX.writeFile(wb, `Cotizaciones_PAS_Alert.xlsx`);
  };

  const getPublicLink = (type: string) => {
    const baseUrl = window.location.origin;
    const userId = 'alejandro-diaz'; // Mock user ID
    return `${baseUrl}/cotizar/${userId}/${type.toLowerCase()}`;
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Link copiado al portapapeles');
  };

  const filteredQuotes = quotes.filter(q => {
    const matchesSearch = q.nombreApellido.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         q.cuitCuil.includes(searchTerm) ||
                         (q.patente && q.patente.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesType = selectedType === 'Todos' || q.tipoSeguro === selectedType;
    return matchesSearch && matchesType;
  });

  const insuranceTypes = ['Todos', 'Auto', 'Moto', 'Hogar', 'Otros'];

  return (
    <Box>
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 2 }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 800 }}>Cotizaciones</Typography>
          <Typography variant="body1" color="text.secondary">Registro de solicitudes de cotización de seguros.</Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <Button 
            variant="outlined" 
            startIcon={<Share2 size={20} />}
            onClick={() => setShareOpen(true)}
            color="secondary"
          >
            Compartir Links
          </Button>
          <Button 
            variant="outlined" 
            startIcon={<Download size={20} />}
            onClick={handleExport}
          >
            Exportar Excel
          </Button>
          <Button 
            variant="contained" 
            startIcon={<Plus size={20} />}
            onClick={() => handleOpen()}
            sx={{ borderRadius: 3 }}
          >
            Nueva Cotización
          </Button>
        </Box>
      </Box>

      <Box sx={{ mb: 3, display: 'flex', gap: 1, overflowX: 'auto', pb: 1 }}>
        {insuranceTypes.map(type => (
          <Chip
            key={type}
            label={type}
            onClick={() => setSelectedType(type)}
            color={selectedType === type ? 'primary' : 'default'}
            variant={selectedType === type ? 'filled' : 'outlined'}
            sx={{ fontWeight: 600, px: 1 }}
          />
        ))}
      </Box>

      <Card sx={{ mb: 4 }}>
        <CardContent>
          <TextField
            fullWidth
            placeholder="Buscar por nombre, CUIT o patente..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search size={20} />
                </InputAdornment>
              ),
            }}
          />
        </CardContent>
      </Card>

      <TableContainer component={Paper}>
        <Table>
          <TableHead sx={{ bgcolor: 'primary.main' }}>
            <TableRow>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Tipo</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Cliente</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Detalle</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Contacto</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Localidad</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700, textAlign: 'right' }}>Acciones</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredQuotes.length > 0 ? (
              filteredQuotes.map((quote) => (
                <TableRow key={quote.id} hover>
                  <TableCell>
                    <Chip 
                      label={quote.tipoSeguro} 
                      size="small" 
                      color={
                        quote.tipoSeguro === 'Auto' ? 'primary' : 
                        quote.tipoSeguro === 'Moto' ? 'secondary' : 
                        quote.tipoSeguro === 'Hogar' ? 'success' : 'warning'
                      }
                      sx={{ fontWeight: 700 }}
                    />
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2" sx={{ fontWeight: 700 }}>{quote.nombreApellido}</Typography>
                    <Typography variant="caption" color="text.secondary">{quote.cuitCuil}</Typography>
                  </TableCell>
                  <TableCell>
                    {quote.tipoSeguro === 'Auto' || quote.tipoSeguro === 'Moto' ? (
                      <>
                        <Typography variant="body2">{quote.marca} {quote.modelo}</Typography>
                        <Typography variant="caption" color="text.secondary">Año: {quote.anio} | Patente: {quote.patente}</Typography>
                      </>
                    ) : quote.tipoSeguro === 'Hogar' ? (
                      <>
                        <Typography variant="body2">{quote.tipoVivienda}</Typography>
                        <Typography variant="caption" color="text.secondary">{quote.superficieCubierta} m² cubiertos</Typography>
                      </>
                    ) : (
                      <Typography variant="body2">{quote.detalleOtros}</Typography>
                    )}
                  </TableCell>
                  <TableCell>
                    <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                        <Phone size={14} />
                        <Typography variant="caption">{quote.celular}</Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                        <Mail size={14} />
                        <Typography variant="caption">{quote.email}</Typography>
                      </Box>
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2">{quote.localidad}</Typography>
                    <Typography variant="caption" color="text.secondary">{quote.provincia}</Typography>
                  </TableCell>
                  <TableCell sx={{ textAlign: 'right' }}>
                    <IconButton size="small" color="primary" onClick={() => handleOpen(quote)}>
                      <Edit2 size={18} />
                    </IconButton>
                    <IconButton size="small" color="error" onClick={() => handleDelete(quote.id)}>
                      <Trash2 size={18} />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={6} sx={{ textAlign: 'center', py: 4 }}>
                  <Typography variant="body2" color="text.secondary">No se encontraron cotizaciones.</Typography>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Dialog Nueva/Editar Cotización */}
      <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
        <DialogTitle sx={{ fontWeight: 700 }}>
          {editingQuote ? 'Editar Cotización' : 'Nueva Cotización'}
        </DialogTitle>
        <DialogContent dividers>
          <Grid container spacing={3}>
            <Grid size={{ xs: 12 }}>
              <FormControl fullWidth>
                <FormLabel sx={{ mb: 1, fontWeight: 600 }}>Tipo de Seguro</FormLabel>
                <RadioGroup 
                  row 
                  value={formValues.tipoSeguro}
                  onChange={(e) => handleInputChange('tipoSeguro', e.target.value)}
                >
                  <FormControlLabel value="Auto" control={<Radio />} label="Auto" />
                  <FormControlLabel value="Moto" control={<Radio />} label="Moto" />
                  <FormControlLabel value="Hogar" control={<Radio />} label="Hogar" />
                  <FormControlLabel value="Otros" control={<Radio />} label="Otros" />
                </RadioGroup>
              </FormControl>
            </Grid>

            {/* Datos Personales */}
            <Grid size={{ xs: 12 }}>
              <Typography variant="subtitle2" sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 1, color: 'primary.main' }}>
                <User size={18} /> Datos Personales
              </Typography>
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <TextField 
                fullWidth 
                label="Nombre y Apellido" 
                value={formValues.nombreApellido}
                onChange={(e) => handleInputChange('nombreApellido', e.target.value)}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <TextField 
                fullWidth 
                label="CUIL / CUIT" 
                value={formValues.cuitCuil}
                onChange={(e) => handleInputChange('cuitCuil', e.target.value)}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 4 }}>
              <TextField 
                fullWidth 
                label="Fecha de Nacimiento" 
                type="date"
                InputLabelProps={{ shrink: true }}
                value={formValues.fechaNacimiento}
                onChange={(e) => handleInputChange('fechaNacimiento', e.target.value)}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 4 }}>
              <TextField 
                fullWidth 
                label="Número de Celular" 
                value={formValues.celular}
                onChange={(e) => handleInputChange('celular', e.target.value)}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 4 }}>
              <TextField 
                fullWidth 
                label="Email" 
                type="email"
                value={formValues.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
              />
            </Grid>

            {/* Datos Específicos */}
            {(formValues.tipoSeguro === 'Auto' || formValues.tipoSeguro === 'Moto') && (
              <>
                <Grid size={{ xs: 12 }}>
                  <Typography variant="subtitle2" sx={{ mt: 2, mb: 2, display: 'flex', alignItems: 'center', gap: 1, color: 'primary.main' }}>
                    {formValues.tipoSeguro === 'Auto' ? <Car size={18} /> : <Bike size={18} />} Datos del Vehículo
                  </Typography>
                </Grid>
                <Grid size={{ xs: 12, md: 4 }}>
                  <TextField 
                    fullWidth 
                    label="Marca" 
                    value={formValues.marca}
                    onChange={(e) => handleInputChange('marca', e.target.value)}
                  />
                </Grid>
                <Grid size={{ xs: 12, md: 4 }}>
                  <TextField 
                    fullWidth 
                    label="Modelo" 
                    value={formValues.modelo}
                    onChange={(e) => handleInputChange('modelo', e.target.value)}
                  />
                </Grid>
                <Grid size={{ xs: 12, md: 2 }}>
                  <TextField 
                    fullWidth 
                    label="Año" 
                    type="number"
                    value={formValues.anio}
                    onChange={(e) => handleInputChange('anio', e.target.value)}
                  />
                </Grid>
                <Grid size={{ xs: 12, md: 2 }}>
                  <TextField 
                    fullWidth 
                    label="Patente" 
                    value={formValues.patente}
                    onChange={(e) => handleInputChange('patente', e.target.value)}
                  />
                </Grid>

                <Grid size={{ xs: 12, md: 4 }}>
                  <FormControl component="fieldset">
                    <FormLabel component="legend">Tipo de Uso</FormLabel>
                    <RadioGroup 
                      row 
                      value={formValues.tipoUso}
                      onChange={(e) => handleInputChange('tipoUso', e.target.value)}
                    >
                      <FormControlLabel value="Particular" control={<Radio />} label="Particular" />
                      <FormControlLabel value="Comercial" control={<Radio />} label="Comercial" />
                    </RadioGroup>
                  </FormControl>
                </Grid>
                {formValues.tipoSeguro === 'Auto' && (
                  <Grid size={{ xs: 12, md: 4 }}>
                    <FormControl component="fieldset">
                      <FormLabel component="legend">¿Tiene GNC?</FormLabel>
                      <RadioGroup 
                        row 
                        value={formValues.tieneGNC}
                        onChange={(e) => handleInputChange('tieneGNC', e.target.value)}
                      >
                        <FormControlLabel value="Si" control={<Radio />} label="Si" />
                        <FormControlLabel value="No" control={<Radio />} label="No" />
                      </RadioGroup>
                    </FormControl>
                  </Grid>
                )}
                <Grid size={{ xs: 12, md: 4 }}>
                  <FormControl component="fieldset">
                    <FormLabel component="legend">¿Rastreador Satelital?</FormLabel>
                    <RadioGroup 
                      row 
                      value={formValues.tieneRastreador}
                      onChange={(e) => handleInputChange('tieneRastreador', e.target.value)}
                    >
                      <FormControlLabel value="Si" control={<Radio />} label="Si" />
                      <FormControlLabel value="No" control={<Radio />} label="No" />
                    </RadioGroup>
                  </FormControl>
                </Grid>
              </>
            )}

            {formValues.tipoSeguro === 'Hogar' && (
              <>
                <Grid size={{ xs: 12 }}>
                  <Typography variant="subtitle2" sx={{ mt: 2, mb: 2, display: 'flex', alignItems: 'center', gap: 1, color: 'primary.main' }}>
                    <Home size={18} /> Datos de la Vivienda
                  </Typography>
                </Grid>
                <Grid size={{ xs: 12, md: 6 }}>
                  <TextField 
                    fullWidth 
                    label="Tipo de Vivienda (Casa, Depto, etc.)" 
                    value={formValues.tipoVivienda}
                    onChange={(e) => handleInputChange('tipoVivienda', e.target.value)}
                  />
                </Grid>
                <Grid size={{ xs: 12, md: 6 }}>
                  <TextField 
                    fullWidth 
                    label="Superficie Cubierta (m²)" 
                    type="number"
                    value={formValues.superficieCubierta}
                    onChange={(e) => handleInputChange('superficieCubierta', e.target.value)}
                  />
                </Grid>
              </>
            )}

            {formValues.tipoSeguro === 'Otros' && (
              <>
                <Grid size={{ xs: 12 }}>
                  <Typography variant="subtitle2" sx={{ mt: 2, mb: 2, display: 'flex', alignItems: 'center', gap: 1, color: 'primary.main' }}>
                    <FileText size={18} /> Otros Seguros
                  </Typography>
                </Grid>
                <Grid size={{ xs: 12 }}>
                  <TextField 
                    fullWidth 
                    multiline
                    rows={3}
                    label="Detalle del seguro solicitado" 
                    value={formValues.detalleOtros}
                    onChange={(e) => handleInputChange('detalleOtros', e.target.value)}
                  />
                </Grid>
              </>
            )}

            {/* Pago y Domicilio */}
            <Grid size={{ xs: 12 }}>
              <Typography variant="subtitle2" sx={{ mt: 2, mb: 2, display: 'flex', alignItems: 'center', gap: 1, color: 'primary.main' }}>
                <CreditCard size={18} /> Pago y Domicilio
              </Typography>
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <TextField 
                fullWidth 
                select 
                label="Forma de Pago Preferida" 
                value={formValues.formaPago}
                onChange={(e) => handleInputChange('formaPago', e.target.value)}
              >
                <MenuItem value="Débito por CBU">Débito por CBU</MenuItem>
                <MenuItem value="Tarjeta de Crédito">Tarjeta de Crédito</MenuItem>
                <MenuItem value="Cupón">Cupón</MenuItem>
              </TextField>
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <TextField 
                fullWidth 
                label="Dirección" 
                value={formValues.direccion}
                onChange={(e) => handleInputChange('direccion', e.target.value)}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 3 }}>
              <TextField 
                fullWidth 
                label="Código Postal" 
                value={formValues.cp}
                onChange={(e) => handleInputChange('cp', e.target.value)}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 4 }}>
              <TextField 
                fullWidth 
                label="Localidad" 
                value={formValues.localidad}
                onChange={(e) => handleInputChange('localidad', e.target.value)}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 5 }}>
              <TextField 
                fullWidth 
                select 
                label="Provincia" 
                value={formValues.provincia}
                onChange={(e) => handleInputChange('provincia', e.target.value)}
              >
                {PROVINCIAS_ARGENTINA.map((prov) => (
                  <MenuItem key={prov} value={prov}>{prov}</MenuItem>
                ))}
              </TextField>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ p: 3 }}>
          <Button onClick={handleClose}>Cancelar</Button>
          <Button variant="contained" onClick={handleSave}>Guardar Cotización</Button>
        </DialogActions>
      </Dialog>

      {/* Dialog Compartir Links */}
      <Dialog open={shareOpen} onClose={() => setShareOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ fontWeight: 700 }}>Compartir Links de Cotización</DialogTitle>
        <DialogContent dividers>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
            Envía estos links a tus clientes para que ellos mismos completen sus datos. 
            Cada link generará una cotización en tu base de datos.
          </Typography>
          
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
            {['Auto', 'Moto', 'Hogar', 'Otros'].map(type => {
              const link = getPublicLink(type);
              return (
                <Card key={type} variant="outlined" sx={{ p: 2, borderRadius: 2 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      {type === 'Auto' ? <Car size={20} /> : type === 'Moto' ? <Bike size={20} /> : type === 'Hogar' ? <Home size={20} /> : <FileText size={20} />}
                      <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>Cotización {type}</Typography>
                    </Box>
                    <Box sx={{ display: 'flex', gap: 1 }}>
                      <IconButton size="small" onClick={() => copyToClipboard(link)} title="Copiar Link">
                        <Copy size={18} />
                      </IconButton>
                      <IconButton size="small" onClick={() => window.open(link, '_blank')} title="Abrir Link">
                        <ExternalLink size={18} />
                      </IconButton>
                    </Box>
                  </Box>
                  
                  <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
                    <Box sx={{ p: 1, bgcolor: 'white', borderRadius: 1, border: '1px solid', borderColor: 'divider' }}>
                      <QRCodeSVG value={link} size={80} />
                    </Box>
                    <Box sx={{ flexGrow: 1 }}>
                      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1, wordBreak: 'break-all' }}>
                        {link}
                      </Typography>
                      <Button 
                        size="small" 
                        variant="contained" 
                        startIcon={<QrCode size={14} />}
                        onClick={() => {
                          const svg = document.querySelector(`svg[value="${link}"]`);
                          if (svg) {
                            // Logic to download QR could go here
                            alert('Funcionalidad de descarga de QR próximamente');
                          }
                        }}
                      >
                        Descargar QR
                      </Button>
                    </Box>
                  </Box>
                </Card>
              );
            })}
          </Box>
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button onClick={() => setShareOpen(false)}>Cerrar</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
