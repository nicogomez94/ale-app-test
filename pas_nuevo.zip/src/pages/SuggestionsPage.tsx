import React, { useState } from 'react';
import { 
  Box, 
  Typography, 
  Card, 
  CardContent, 
  TextField, 
  Button, 
  Grid, 
  MenuItem, 
  Rating,
  Divider,
  Alert,
  Snackbar,
  Paper
} from '@mui/material';
import { 
  MessageSquare, 
  Send, 
  Lightbulb, 
  ThumbsUp, 
  Star,
  Sparkles
} from 'lucide-react';
import { motion } from 'motion/react';

const categories = [
  { value: 'interfaz', label: 'Interfaz y Diseño' },
  { value: 'funcionalidad', label: 'Nuevas Funcionalidades' },
  { value: 'errores', label: 'Reporte de Errores' },
  { value: 'rendimiento', label: 'Rendimiento y Velocidad' },
  { value: 'otros', label: 'Otros Comentarios' },
];

export const SuggestionsPage: React.FC = () => {
  const [formData, setFormData] = useState({
    category: '',
    subject: '',
    description: '',
    rating: 5
  });
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simular envío
    console.log('Sugerencia enviada:', formData);
    setShowSuccess(true);
    setFormData({
      category: '',
      subject: '',
      description: '',
      rating: 5
    });
  };

  return (
    <Box sx={{ width: '100%', mx: 'auto', p: 2, bgcolor: '#f8fafc', borderRadius: 6, minHeight: 'auto' }}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Box sx={{ mb: 3, textAlign: 'center' }}>
          <Box sx={{ 
            display: 'inline-flex', 
            p: 1.5, 
            bgcolor: 'primary.main', 
            color: 'white', 
            borderRadius: 3, 
            mb: 2,
            boxShadow: '0 10px 25px -5px rgba(79, 70, 229, 0.4)'
          }}>
            <Lightbulb size={32} strokeWidth={2.5} />
          </Box>
          <Typography variant="h4" sx={{ fontWeight: 900, color: 'text.primary', mb: 0.5, letterSpacing: -1 }}>
            Tu Voz Importa, PAS
          </Typography>
          <Typography variant="body1" color="text.secondary" sx={{ fontWeight: 500, maxWidth: 800, mx: 'auto' }}>
            Ayúdanos a construir la plataforma de gestión de seguros más potente del mercado. Tus sugerencias impulsan nuestra innovación.
          </Typography>
        </Box>

        <Grid container spacing={2}>
          <Grid size={{ xs: 12, md: 9 }}>
            <Card sx={{ borderRadius: 4, boxShadow: '0 4px 20px rgba(0,0,0,0.05)', border: '1px solid', borderColor: 'divider' }}>
              <CardContent sx={{ p: 3 }}>
                <Typography variant="h6" sx={{ fontWeight: 800, mb: 2, display: 'flex', alignItems: 'center', gap: 1.5 }}>
                  <MessageSquare size={20} color="#4f46e5" /> Enviar Sugerencia
                </Typography>
                
                <form onSubmit={handleSubmit}>
                  <Grid container spacing={2}>
                    <Grid size={{ xs: 12, sm: 6 }}>
                      <TextField
                        select
                        fullWidth
                        label="Categoría"
                        required
                        value={formData.category}
                        onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                        sx={{ '& .MuiOutlinedInput-root': { borderRadius: 3 } }}
                      >
                        {categories.map((option) => (
                          <MenuItem key={option.value} value={option.value}>
                            {option.label}
                          </MenuItem>
                        ))}
                      </TextField>
                    </Grid>
                    <Grid size={{ xs: 12, sm: 6 }}>
                      <TextField
                        fullWidth
                        label="Asunto"
                        required
                        placeholder="Ej: Mejora en carga de pólizas"
                        value={formData.subject}
                        onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                        sx={{ '& .MuiOutlinedInput-root': { borderRadius: 3 } }}
                      />
                    </Grid>
                    <Grid size={12}>
                      <TextField
                        fullWidth
                        multiline
                        rows={6}
                        label="Descripción Detallada"
                        required
                        placeholder="Describe tu idea, recomendación o el problema que encontraste..."
                        value={formData.description}
                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                        sx={{ '& .MuiOutlinedInput-root': { borderRadius: 3 } }}
                      />
                    </Grid>
                    <Grid size={12}>
                      <Box sx={{ p: 2, bgcolor: 'grey.50', borderRadius: 3, border: '1px dashed', borderColor: 'divider' }}>
                        <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1, color: 'text.secondary' }}>
                          ¿Qué tan satisfecho estás con la plataforma actual?
                        </Typography>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                          <Rating 
                            value={formData.rating} 
                            onChange={(_, newValue) => setFormData({ ...formData, rating: newValue || 5 })}
                            size="large"
                          />
                          <Typography variant="body2" sx={{ fontWeight: 600, color: 'primary.main' }}>
                            {formData.rating}/5 Estrellas
                          </Typography>
                        </Box>
                      </Box>
                    </Grid>
                    <Grid size={12}>
                      <Button 
                        type="submit" 
                        variant="contained" 
                        size="large" 
                        fullWidth
                        startIcon={<Send size={20} />}
                        sx={{ 
                          py: 2, 
                          borderRadius: 3, 
                          fontWeight: 800, 
                          fontSize: '1.1rem',
                          boxShadow: '0 10px 15px -3px rgba(79, 70, 229, 0.3)',
                          textTransform: 'none'
                        }}
                      >
                        Enviar Feedback Profesional
                      </Button>
                    </Grid>
                  </Grid>
                </form>
              </CardContent>
            </Card>
          </Grid>

          <Grid size={{ xs: 12, md: 3 }}>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <Paper sx={{ p: 2, borderRadius: 4, bgcolor: 'primary.dark', color: 'white' }}>
                <Typography variant="subtitle1" sx={{ fontWeight: 800, mb: 1, display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Sparkles size={18} /> Compromiso PAS
                </Typography>
                <Typography variant="caption" sx={{ opacity: 0.9, lineHeight: 1.4 }}>
                  Revisamos cada sugerencia personalmente. Las mejores ideas son implementadas en nuestras actualizaciones mensuales.
                </Typography>
              </Paper>

              <Card sx={{ borderRadius: 4, border: '1px solid', borderColor: 'divider' }}>
                <CardContent sx={{ p: 2 }}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 800, mb: 1.5 }}>
                    Impacto de tus ideas
                  </Typography>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                    <Box sx={{ display: 'flex', gap: 2 }}>
                      <Box sx={{ color: 'success.main' }}><ThumbsUp size={20} /></Box>
                      <Box>
                        <Typography variant="body2" sx={{ fontWeight: 700 }}>Optimización de Carga</Typography>
                        <Typography variant="caption" color="text.secondary">Sugerido por Juan M. - Implementado</Typography>
                      </Box>
                    </Box>
                    <Divider />
                    <Box sx={{ display: 'flex', gap: 2 }}>
                      <Box sx={{ color: 'warning.main' }}><Star size={20} /></Box>
                      <Box>
                        <Typography variant="body2" sx={{ fontWeight: 700 }}>Módulo de Siniestros</Typography>
                        <Typography variant="caption" color="text.secondary">Sugerido por Elena R. - En Desarrollo</Typography>
                      </Box>
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            </Box>
          </Grid>
        </Grid>
      </motion.div>

      <Snackbar 
        open={showSuccess} 
        autoHideDuration={6000} 
        onClose={() => setShowSuccess(false)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert onClose={() => setShowSuccess(false)} severity="success" sx={{ width: '100%', borderRadius: 3, fontWeight: 700 }}>
          ¡Gracias! Tu sugerencia ha sido recibida y será analizada por nuestro equipo técnico.
        </Alert>
      </Snackbar>
    </Box>
  );
};
