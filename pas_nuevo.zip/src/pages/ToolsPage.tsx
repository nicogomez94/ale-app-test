import React, { useState, useEffect, useCallback } from 'react';
import { 
  Box, 
  Typography, 
  Card, 
  CardContent, 
  Grid, 
  TextField, 
  Button, 
  List, 
  ListItem, 
  ListItemText, 
  ListItemIcon,
  IconButton,
  Tooltip,
  Paper,
  InputAdornment,
  Divider,
  Tabs,
  Tab
} from '@mui/material';
import { 
  Calculator, 
  Send, 
  BookOpen, 
  Copy, 
  Check,
  MessageSquare,
  Phone,
  ExternalLink,
  Delete,
  Plus,
  X as CloseIcon
} from 'lucide-react';

// --- CALCULADORA ---
export const CalculatorPage: React.FC = () => {
  const [display, setDisplay] = useState('0');
  const [lastResult, setLastResult] = useState<string | null>(null);
  
  const handleButtonClick = useCallback((value: string) => {
    setDisplay(prev => {
      if (prev === '0' || prev === 'Error') return value;
      return prev + value;
    });
  }, []);

  const calculate = useCallback(() => {
    try {
      // eslint-disable-next-line no-eval
      const result = eval(display).toString();
      setDisplay(result);
      setLastResult(result);
    } catch (e) {
      setDisplay('Error');
    }
  }, [display]);

  const clear = useCallback(() => {
    setDisplay('0');
    setLastResult(null);
  }, []);

  const backspace = useCallback(() => {
    setDisplay(prev => {
      if (prev.length <= 1 || prev === 'Error') return '0';
      return prev.slice(0, -1);
    });
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key >= '0' && e.key <= '9') handleButtonClick(e.key);
      if (['+', '-', '*', '/'].includes(e.key)) handleButtonClick(e.key);
      if (e.key === 'Enter' || e.key === '=') {
        e.preventDefault();
        calculate();
      }
      if (e.key === 'Escape' || e.key === 'c' || e.key === 'C') clear();
      if (e.key === 'Backspace') backspace();
      if (e.key === '.') handleButtonClick('.');
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleButtonClick, calculate, clear, backspace]);

  const buttons = [
    { label: 'C', action: clear, color: 'error.main' },
    { label: '⌫', action: backspace, color: 'warning.main' },
    { label: '/', action: () => handleButtonClick('/'), color: 'primary.main' },
    { label: '*', action: () => handleButtonClick('*'), color: 'primary.main' },
    { label: '7', action: () => handleButtonClick('7') },
    { label: '8', action: () => handleButtonClick('8') },
    { label: '9', action: () => handleButtonClick('9') },
    { label: '-', action: () => handleButtonClick('-'), color: 'primary.main' },
    { label: '4', action: () => handleButtonClick('4') },
    { label: '5', action: () => handleButtonClick('5') },
    { label: '6', action: () => handleButtonClick('6') },
    { label: '+', action: () => handleButtonClick('+'), color: 'primary.main' },
    { label: '1', action: () => handleButtonClick('1') },
    { label: '2', action: () => handleButtonClick('2') },
    { label: '3', action: () => handleButtonClick('3') },
    { label: '=', action: calculate, color: 'success.main', rowSpan: 2 },
    { label: '0', action: () => handleButtonClick('0'), colSpan: 2 },
    { label: '.', action: () => handleButtonClick('.') },
  ];

  return (
    <Box sx={{ p: 4, maxWidth: 450, mx: 'auto' }}>
      <Typography variant="h4" sx={{ fontWeight: 900, mb: 4, display: 'flex', alignItems: 'center', gap: 2, color: 'primary.main' }}>
        <Calculator size={36} strokeWidth={2.5} /> Calculadora Inteligente
      </Typography>
      
      <Card sx={{ 
        borderRadius: 6, 
        boxShadow: '0 20px 60px rgba(0,0,0,0.15)',
        border: '1px solid',
        borderColor: 'divider',
        overflow: 'hidden'
      }}>
        <Box sx={{ p: 3, bgcolor: 'grey.900', color: 'white' }}>
          <Typography variant="caption" sx={{ opacity: 0.5, display: 'block', mb: 1, textAlign: 'right', minHeight: 20 }}>
            {lastResult && `Último resultado: ${lastResult}`}
          </Typography>
          <Typography variant="h3" sx={{ 
            fontWeight: 700, 
            fontFamily: 'monospace', 
            textAlign: 'right',
            wordBreak: 'break-all',
            lineHeight: 1.2
          }}>
            {display}
          </Typography>
        </Box>
        
        <CardContent sx={{ p: 3, bgcolor: 'background.paper' }}>
          <Grid container spacing={1.5}>
            {buttons.map((btn, idx) => (
              <Grid size={btn.colSpan ? btn.colSpan * 3 : 3} key={idx}>
                <Button 
                  fullWidth 
                  variant={btn.color ? "contained" : "outlined"}
                  onClick={btn.action}
                  sx={{ 
                    borderRadius: 3, 
                    height: 60, 
                    fontSize: '1.25rem',
                    fontWeight: 800,
                    bgcolor: btn.color || 'transparent',
                    color: btn.color ? 'white' : 'text.primary',
                    borderColor: btn.color ? 'transparent' : 'divider',
                    '&:hover': {
                      bgcolor: btn.color || 'action.hover',
                      filter: btn.color ? 'brightness(0.9)' : 'none'
                    }
                  }}
                >
                  {btn.label}
                </Button>
              </Grid>
            ))}
          </Grid>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 3, textAlign: 'center', fontWeight: 600 }}>
            Usa tu teclado para operar más rápido (Enter para =, Esc para C)
          </Typography>
        </CardContent>
      </Card>
    </Box>
  );
};

// --- LANZADOR DE CHATS + BIBLIOTECA ---
export const ChatLauncherPage: React.FC<{ user?: any }> = ({ user }) => {
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [tabValue, setTabValue] = useState(0);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isAddingScript, setIsAddingScript] = useState(false);
  const [newScriptTitle, setNewScriptTitle] = useState('');
  const [newScriptContent, setNewScriptContent] = useState('');

  const WHATSAPP_GREEN = '#25D366';
  const WHATSAPP_DARK = '#075E54';

  const [scripts, setScripts] = useState(() => {
    const saved = localStorage.getItem('pas_alert_custom_scripts');
    const initialScripts = [
      {
        id: '1',
        title: 'Saludo Inicial',
        content: 'Hola [Nombre], te saluda [Nombre Usuario] de [Nombre Comercial]. Te contacto para informarte sobre el vencimiento de tu póliza.'
      },
      {
        id: '2',
        title: 'Recordatorio de Pago',
        content: 'Estimado [Nombre], te recordamos desde [Nombre Comercial] que tu cuota de seguro vence el día [Fecha]. Quedo a disposición por cualquier duda.'
      },
      {
        id: '3',
        title: 'Solicitud de Documentación',
        content: 'Hola [Nombre], te habla [Nombre Usuario]. Para avanzar con el trámite en [Nombre Comercial] necesito que me envíes una foto de [Documento]. Muchas gracias.'
      },
      {
        id: '4',
        title: 'Aviso de Renovación',
        content: 'Buenas tardes [Nombre], tu póliza se renovará automáticamente el próximo mes. Desde [Nombre Comercial] te enviamos la nueva propuesta.'
      },
      {
        id: '5',
        title: 'Bienvenida Nuevo Cliente',
        content: '¡Bienvenido a [Nombre Comercial]! Es un gusto tenerte con nosotros. Te saluda [Nombre Usuario], adjunto envío tu póliza digital.'
      },
      {
        id: '6',
        title: 'Seguimiento de Siniestro',
        content: 'Hola [Nombre], te contacto desde [Nombre Comercial] para informarte que el siniestro N° [Número] ya se encuentra en etapa de [Estado].'
      },
      {
        id: '7',
        title: 'Aviso de Inspección',
        content: 'Estimado [Nombre], la compañía ha solicitado una inspección. Desde [Nombre Comercial] te informamos que el inspector se comunicará en breve.'
      },
      {
        id: '8',
        title: 'Promoción Referidos',
        content: 'Hola [Nombre], ¿sabías que en [Nombre Comercial] si nos recomendas a un amigo ambos obtienen un descuento especial?'
      }
    ];
    return saved ? JSON.parse(saved) : initialScripts;
  });

  useEffect(() => {
    localStorage.setItem('pas_alert_custom_scripts', JSON.stringify(scripts));
  }, [scripts]);

  const replacePlaceholders = (text: string) => {
    return text
      .replace(/\[Nombre Usuario\]/g, user?.nombre || 'Alejandro Díaz')
      .replace(/\[Nombre Comercial\]/g, user?.nombreComercial || 'PAS ALERT');
  };

  const launchWhatsApp = () => {
    const cleanPhone = phone.replace(/\D/g, '');
    const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  const useScript = (content: string) => {
    setMessage(replacePlaceholders(content));
    setTabValue(0); // Switch to launcher tab
  };

  const copyToClipboard = (id: string, text: string) => {
    navigator.clipboard.writeText(replacePlaceholders(text));
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleAddScript = () => {
    if (!newScriptTitle.trim() || !newScriptContent.trim()) return;
    const newScript = {
      id: Math.random().toString(36).substr(2, 9),
      title: newScriptTitle,
      content: newScriptContent
    };
    setScripts([newScript, ...scripts]);
    setNewScriptTitle('');
    setNewScriptContent('');
    setIsAddingScript(false);
  };

  const deleteScript = (id: string) => {
    if (window.confirm('¿Estás seguro de que deseas eliminar este script?')) {
      setScripts(scripts.filter(s => s.id !== id));
    }
  };

  return (
    <Box sx={{ p: 4, maxWidth: 800, mx: 'auto' }}>
      <Typography variant="h4" sx={{ fontWeight: 900, mb: 4, display: 'flex', alignItems: 'center', gap: 2, color: WHATSAPP_DARK }}>
        <MessageSquare size={36} strokeWidth={2.5} /> Lanzador de Chats
      </Typography>
      
      <Card sx={{ borderRadius: 6, border: '1px solid', borderColor: 'divider', overflow: 'hidden', boxShadow: '0 10px 40px rgba(0,0,0,0.05)' }}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider', bgcolor: 'grey.50' }}>
          <Tabs 
            value={tabValue} 
            onChange={(_, v) => setTabValue(v)} 
            variant="fullWidth"
            sx={{
              '& .MuiTabs-indicator': { bgcolor: WHATSAPP_GREEN, height: 3 }
            }}
          >
            <Tab 
              icon={<Send size={20} />} 
              label="Lanzador" 
              sx={{ fontWeight: 700, py: 2, color: tabValue === 0 ? WHATSAPP_GREEN : 'text.secondary' }} 
            />
            <Tab 
              icon={<BookOpen size={20} />} 
              label="Biblioteca de Scripts" 
              sx={{ fontWeight: 700, py: 2, color: tabValue === 1 ? WHATSAPP_GREEN : 'text.secondary' }} 
            />
          </Tabs>
        </Box>

        <CardContent sx={{ p: 4 }}>
          {tabValue === 0 ? (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
              <Box>
                <Typography variant="h6" sx={{ fontWeight: 800, mb: 1 }}>Enviar Mensaje Directo</Typography>
                <Typography variant="body2" color="text.secondary">Inicia chats sin agendar contactos.</Typography>
              </Box>
              
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
                <TextField
                  fullWidth
                  label="Número de Teléfono"
                  placeholder="Ej: 5491112345678"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <Phone size={20} color={WHATSAPP_GREEN} />
                      </InputAdornment>
                    ),
                    sx: { borderRadius: 3, fontSize: '1.1rem', fontWeight: 600 }
                  }}
                />
                <TextField
                  fullWidth
                  multiline
                  rows={5}
                  label="Mensaje"
                  placeholder="Escribe tu mensaje aquí o selecciona uno de la biblioteca..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  sx={{ '& .MuiOutlinedInput-root': { borderRadius: 3 } }}
                />
                <Button 
                  variant="contained" 
                  size="large" 
                  onClick={launchWhatsApp}
                  disabled={!phone}
                  startIcon={<MessageSquare size={24} />}
                  sx={{ 
                    borderRadius: 4, 
                    py: 2, 
                    fontWeight: 800, 
                    fontSize: '1.1rem',
                    bgcolor: WHATSAPP_GREEN,
                    boxShadow: `0 8px 20px ${WHATSAPP_GREEN}40`,
                    '&:hover': { bgcolor: WHATSAPP_GREEN, filter: 'brightness(0.9)' }
                  }}
                >
                  Enviar por WhatsApp
                </Button>
              </Box>
            </Box>
          ) : (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Typography variant="h6" sx={{ fontWeight: 800 }}>Scripts de Respuesta Rápida</Typography>
                <Button 
                  startIcon={isAddingScript ? <CloseIcon size={18} /> : <Plus size={18} />} 
                  variant="outlined" 
                  size="small"
                  onClick={() => setIsAddingScript(!isAddingScript)}
                  sx={{ borderRadius: 2, fontWeight: 700 }}
                >
                  {isAddingScript ? 'Cancelar' : 'Nuevo Script'}
                </Button>
              </Box>

              {isAddingScript && (
                <Paper sx={{ p: 3, borderRadius: 4, bgcolor: 'grey.50', border: '1px dashed', borderColor: 'divider' }}>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    <TextField
                      fullWidth
                      size="small"
                      label="Título del Script"
                      value={newScriptTitle}
                      onChange={(e) => setNewScriptTitle(e.target.value)}
                    />
                    <TextField
                      fullWidth
                      multiline
                      rows={3}
                      label="Contenido del Mensaje"
                      value={newScriptContent}
                      onChange={(e) => setNewScriptContent(e.target.value)}
                    />
                    <Button 
                      variant="contained" 
                      onClick={handleAddScript}
                      sx={{ alignSelf: 'flex-end', borderRadius: 2, fontWeight: 700, bgcolor: WHATSAPP_DARK }}
                    >
                      Guardar Script
                    </Button>
                  </Box>
                </Paper>
              )}

              <Grid container spacing={2}>
                {scripts.map((script) => (
                  <Grid size={12} key={script.id}>
                    <Card variant="outlined" sx={{ borderRadius: 4, borderLeft: `6px solid ${WHATSAPP_GREEN}`, '&:hover': { bgcolor: 'grey.50' } }}>
                      <CardContent sx={{ p: 2.5 }}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1.5 }}>
                          <Typography variant="subtitle1" sx={{ fontWeight: 800, color: WHATSAPP_DARK }}>{script.title}</Typography>
                          <Box sx={{ display: 'flex', gap: 1 }}>
                            <Tooltip title="Usar en lanzador">
                              <IconButton size="small" onClick={() => useScript(script.content)} sx={{ color: WHATSAPP_GREEN }}>
                                <Send size={18} />
                              </IconButton>
                            </Tooltip>
                            <Tooltip title={copiedId === script.id ? "Copiado!" : "Copiar"}>
                              <IconButton size="small" onClick={() => copyToClipboard(script.id, script.content)}>
                                {copiedId === script.id ? <Check size={18} color={WHATSAPP_GREEN} /> : <Copy size={18} />}
                              </IconButton>
                            </Tooltip>
                            <Tooltip title="Eliminar">
                              <IconButton size="small" onClick={() => deleteScript(script.id)} color="error">
                                <Delete size={18} />
                              </IconButton>
                            </Tooltip>
                          </Box>
                        </Box>
                        <Typography variant="body2" sx={{ color: 'text.secondary', fontStyle: 'italic' }}>
                          "{script.content}"
                        </Typography>
                      </CardContent>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            </Box>
          )}
        </CardContent>
      </Card>
    </Box>
  );
};

// --- BIBLIOTECA DE SCRIPTS (Standalone if needed, but now integrated) ---
export const ScriptsLibraryPage: React.FC<{ user?: any }> = ({ user }) => {
  return <ChatLauncherPage user={user} />; // Redirect to integrated view
};
