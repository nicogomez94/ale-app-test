import { Timestamp } from "firebase/firestore";

export type PlanStatus = 'trial' | 'activo' | 'vencido';

export interface UserProfile {
  userId: string;
  email: string;
  nombre: string;
  fechaRegistro: Timestamp;
  plan: PlanStatus;
  trialInicio: Timestamp;
  trialFin: Timestamp;
  estado: 'activo' | 'inactivo';
  referidosMes: number;
  referidosTotales: number;
  referralCode: string;
}

export interface Cliente {
  id?: string;
  userId: string;
  nombre: string;
  dni: string;
  telefono: string;
  email: string;
  direccion?: string;
  createdAt: Timestamp;
}

export type PolizaStatus = 'Activa' | 'Vence pronto' | 'Vencida';

export interface Poliza {
  id?: string;
  userId: string;
  clienteNombre: string;
  clienteDni: string;
  clienteTelefono: string;
  aseguradora: string;
  rubro: string;
  numeroPoliza: string;
  fechaInicio: Timestamp;
  fechaVencimiento: Timestamp;
  prima: number;
  porcentajeComision: number;
  comisionCalculada: number;
  estado: PolizaStatus;
  medioPago?: 'Cupon' | 'Tarjeta de credito' | 'Debito por CBU';
  pagada?: boolean;
  ultimaGestion?: {
    tipo: 'Whatsapp' | 'Mail';
    fecha: string;
    whatsappCount: number;
    mailCount: number;
  };
  createdAt: Timestamp;
}

export interface CommissionConfig {
  id: string;
  userId: string;
  aseguradoraId: string;
  rubro: string;
  porcentaje: number;
}

export type InvoiceStatus = 'Pendiente' | 'Facturada' | 'Cobrada' | 'Parcial' | 'Vencida';

export interface CommissionPayment {
  id: string;
  fecha: string;
  monto: number;
  medioPago: string;
  comprobanteUrl?: string;
}

export interface CommissionInvoice {
  id: string;
  periodo: string;
  aseguradoraId: string;
  numeroFactura: string;
  fechaEmision: string;
  montoEsperado: number;
  montoFacturado: number;
  montoCobrado: number;
  moneda: 'ARS' | 'USD';
  estado: InvoiceStatus;
  vencimiento: string;
  documentoUrl?: string;
  liquidacionesUrls?: string[];
  pagos: CommissionPayment[];
  polizasIds: string[];
  diferenciaDetectada: boolean;
  notas?: string;
}

export interface InsuranceCompany {
  id: string;
  razonSocial: string;
  domicilioComercial: string;
  cuit: string;
  condicionIva: 'Responsable Inscripto' | 'Monotributo' | 'Consumidor Final' | 'Exento';
  mail: string;
  telefono: string;
  urlWeb: string;
  usuario?: string;
  password?: string;
  codigoCliente?: string;
  notas?: string;
  facturacionComisiones?: CommissionInvoice[];
}

export type ClaimStatus = 'Denunciado' | 'En gestión' | 'En inspección' | 'En análisis' | 'Aprobado' | 'Rechazado' | 'Pagado';
export type ClaimPriority = 'Alta' | 'Media' | 'Baja';

export interface ClaimNote {
  id: string;
  date: string;
  text: string;
  author: string;
}

export interface ClaimDocument {
  id: string;
  name: string;
  type: string;
  url: string;
  uploadDate: string;
}

export interface Claim {
  id?: string;
  userId: string;
  claimNumber: string;
  policyNumber: string;
  insuranceCompany: string;
  insuranceType: string;
  clientName: string;
  clientDni: string;
  accidentDate: string;
  accidentTime: string;
  location: string;
  description: string;
  dynamicFields: {
    [key: string]: any;
  };
  status: ClaimStatus;
  priority: ClaimPriority;
  denunciationDate: string;
  lastContactCompany?: string;
  lastContactClient?: string;
  responsible: string;
  notes: ClaimNote[];
  claimedAmount: number;
  deductible: number;
  approvedAmount: number;
  paidAmount: number;
  documents: ClaimDocument[];
  createdAt: Timestamp;
  updatedAt: Timestamp;
}
